from pathlib import Path
from uuid import uuid4

import pytest
from fastapi.testclient import TestClient

from app.core.config import settings
from app.main import app
from app.services import confirmation_service, event_service, recommendation_service


@pytest.fixture()
def client():
    suffix = uuid4().hex
    event_service.EVENTS_FILE = Path(f".pytest_events_{suffix}.json")
    confirmation_service.CONFIRMATIONS_FILE = Path(f".pytest_confirmations_{suffix}.json")
    recommendation_service.PREFERENCE_EVENTS_FILE = Path(f".pytest_preferences_{suffix}.json")
    settings.llm_mode = "mock"
    with TestClient(app) as test_client:
        yield test_client


def test_health(client):
    response = client.get("/health")

    assert response.status_code == 200
    assert response.json() == {
        "status": "ok",
        "service": "nail-ai-backend",
    }


def test_styles_list(client):
    response = client.get("/api/styles")
    data = response.json()

    assert response.status_code == 200
    assert "items" in data
    assert len(data["items"]) >= 25
    assert set(data["items"][0]).issuperset(
        {
        "id",
        "name",
        "image_url",
        "style_id",
        "style_name",
        "original_url",
        "enhanced_url",
        "image_path",
        "tags",
        "scene",
        "color",
        "reason",
        "is_new",
        }
    )


def test_style_detail(client):
    response = client.get("/api/styles/style_001")

    assert response.status_code == 200
    assert response.json()["id"] == "style_001"


def test_create_event(client):
    response = client.post(
        "/api/events",
        json={
            "user_id": "demo_user",
            "style_id": "style_001",
            "event_type": "tryon",
        },
    )
    data = response.json()

    assert response.status_code == 200
    assert data["success"] is True
    assert data["event_id"].startswith("event_")


def test_analytics_dashboard(client):
    response = client.get("/api/analytics/dashboard")
    data = response.json()

    assert response.status_code == 200
    assert set(data) == {
        "today_tryon_count",
        "today_user_count",
        "top_styles",
        "hot_tags",
        "cold_styles",
        "recommendation",
    }
    assert len(data["top_styles"]) <= 5
    assert len(data["cold_styles"]) <= 5


def test_ai_report(client):
    response = client.post("/api/ai/report", json={"date": "2026-06-02"})
    data = response.json()

    assert response.status_code == 200
    assert data["mock"] is True
    assert set(data) == {
        "summary",
        "hot_trend",
        "risk",
        "suggestion",
        "mock",
    }


def test_hands(client):
    response = client.get("/api/hands")
    data = response.json()

    assert response.status_code == 200
    assert len(data["items"]) >= 6

    detail = client.get("/api/hands/hand_001")
    assert detail.status_code == 200
    assert detail.json()["hand_id"] == "hand_001"

    missing = client.get("/api/hands/missing")
    assert missing.status_code == 404


def test_merchants(client):
    response = client.get("/api/merchants")
    data = response.json()

    assert response.status_code == 200
    assert len(data["items"]) >= 6
    assert "restore_score" in data["items"][0]

    detail = client.get("/api/merchants/merchant_001")
    assert detail.status_code == 200
    assert detail.json()["merchant_id"] == "merchant_001"


def test_recommend_merchants(client):
    response = client.post(
        "/api/recommend/merchants",
        json={
            "user_id": "demo_user",
            "hand_id": "hand_001",
            "style_id": "style_001",
            "preferences": ["还原度", "性价比"],
        },
    )
    data = response.json()

    assert response.status_code == 200
    assert data["mock"] is True
    assert data["style_id"] == "style_001"
    assert len(data["items"]) <= 5
    assert "match_score" in data["items"][0]

    missing = client.post(
        "/api/recommend/merchants",
        json={"style_id": "missing", "preferences": []},
    )
    assert missing.status_code == 404


def test_confirmation(client):
    response = client.post(
        "/api/confirmation",
        json={
            "user_id": "demo_user",
            "hand_id": "hand_001",
            "style_id": "style_001",
            "merchant_id": "merchant_001",
            "preferences": ["还原度", "性价比"],
            "tryon_result_url": "/outputs/result_001.png",
        },
    )
    data = response.json()

    assert response.status_code == 200
    assert data["mock"] is True
    assert data["confirmation_id"].startswith("confirm_")
    assert data["expected_price"] == "128-268"


def test_platform_dashboard(client):
    response = client.get("/api/analytics/platform-dashboard")
    data = response.json()

    assert response.status_code == 200
    assert data["mock"] is True
    assert data["overview"]["total_exposure"] > 0
    assert data["overview"]["total_tryon_count"] > 0
    assert data["overview"]["total_favorite_count"] > 0
    assert data["overview"]["total_appointment_count"] > 0
    assert data["overview"]["overall_conversion_rate"] > 0
    assert len(data["style_heat_ranking"]) <= 10
    assert len(data["style_heat_ranking"]) >= 1
    assert data["style_heat_ranking"][0]["image_url"]
    assert data["style_heat_ranking"][0]["tags"]
    heat_scores = [item["heat_score"] for item in data["style_heat_ranking"]]
    assert heat_scores == sorted(heat_scores, reverse=True)
    assert len(data["preference_trends"]) >= 1
    assert "preference" in data["preference_trends"][0]
    assert 0.99 <= sum(item["ratio"] for item in data["preference_trends"]) <= 1.01
    assert len(data["merchant_capabilities"]) <= 10
    assert len(data["merchant_capabilities"]) >= 1
    assert "skill_tags" in data["merchant_capabilities"][0]
    assert "price_stability_score" in data["merchant_capabilities"][0]
    assert len(data["supply_demand_alerts"]) >= 1
    assert "priority" in data["supply_demand_alerts"][0]
    high_priority_count = sum(
        1 for item in data["supply_demand_alerts"] if item["priority"] == "high"
    )
    assert data["overview"]["high_priority_alert_count"] == high_priority_count
