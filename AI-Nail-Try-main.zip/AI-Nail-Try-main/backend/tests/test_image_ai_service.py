from pathlib import Path

import pytest
from PIL import Image

from app.core.config import settings
from app.services.image_ai_service import edit_image


@pytest.mark.parametrize("provider", ["qwen", "openai", "doubao"])
def test_real_image_provider_without_key_falls_back_to_mock(provider: str, tmp_path: Path):
    old_mode = settings.image_ai_mode
    old_qwen_key = settings.qwen_api_key
    old_openai_key = settings.openai_api_key
    old_image_key = settings.image_ai_api_key
    old_ark_key = settings.ark_api_key

    settings.image_ai_mode = "real"
    settings.qwen_api_key = ""
    settings.openai_api_key = ""
    settings.image_ai_api_key = ""
    settings.ark_api_key = ""

    target_path = tmp_path / "target.png"
    mask_path = tmp_path / "mask.png"
    reference_path = tmp_path / "reference.png"
    output_path = tmp_path / "result.png"
    Image.new("RGB", (80, 80), (230, 210, 200)).save(target_path)
    Image.new("L", (80, 80), 255).save(mask_path)
    Image.new("RGBA", (80, 80), (180, 60, 140, 255)).save(reference_path)

    try:
        result = edit_image(
            target_image_path=str(target_path),
            mask_path=str(mask_path),
            reference_image_paths=[str(reference_path)],
            prompt="test prompt",
            output_path=str(output_path),
            provider=provider,
            model_name=None,
        )
    finally:
        settings.image_ai_mode = old_mode
        settings.qwen_api_key = old_qwen_key
        settings.openai_api_key = old_openai_key
        settings.image_ai_api_key = old_image_key
        settings.ark_api_key = old_ark_key

    assert result == str(output_path)
    assert output_path.exists()
