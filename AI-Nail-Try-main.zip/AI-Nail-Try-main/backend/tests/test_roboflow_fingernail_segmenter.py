from pathlib import Path

import pytest
from PIL import Image

from app.services.segmentation.roboflow_fingernail import (
    MockFingernailSegmenter,
    RoboflowFingernailSegmenter,
)


def test_mock_fingernail_segmenter_returns_polygons(tmp_path: Path):
    image_path = tmp_path / "hand.png"
    Image.new("RGB", (120, 100), "white").save(image_path)

    result = MockFingernailSegmenter().infer(str(image_path))

    assert result["mock"] is True
    assert len(result["predictions"]) == 5
    assert result["predictions"][0]["class"] == "Fingernail"


def test_roboflow_segmenter_requires_api_key():
    with pytest.raises(ValueError, match="ROBOFLOW_API_KEY"):
        RoboflowFingernailSegmenter(
            api_key="",
            model_id="fingernail-segmentation-yy1l7/3",
            api_url="https://serverless.roboflow.com",
        )
