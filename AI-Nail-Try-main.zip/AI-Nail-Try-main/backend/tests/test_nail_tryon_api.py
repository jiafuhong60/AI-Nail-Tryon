from pathlib import Path

from fastapi.testclient import TestClient
from PIL import Image

from app.core.config import settings
from app.main import app
from app.routers import nail_tryon


def test_nail_tryon_api_returns_urls(tmp_path: Path):
    old_upload_dir = settings.upload_dir
    old_nail_tryon_upload_dir = settings.nail_tryon_upload_dir
    old_segmentation_provider = settings.nail_tryon_segmentation_provider
    settings.upload_dir = tmp_path / "uploads"
    settings.nail_tryon_upload_dir = settings.upload_dir / "nail_tryon"
    settings.nail_tryon_segmentation_provider = "mock"
    settings.ensure_directories()

    target_path = tmp_path / "target.png"
    style_path = tmp_path / "style.png"
    Image.new("RGB", (120, 100), (240, 220, 210)).save(target_path)
    Image.new("RGB", (120, 100), (180, 40, 120)).save(style_path)

    try:
        with TestClient(app) as client:
            with target_path.open("rb") as target_file, style_path.open("rb") as style_file:
                response = client.post(
                    "/api/nail-tryon",
                    files={
                        "target_hand_image": ("target.png", target_file, "image/png"),
                        "style_hand_image": ("style.png", style_file, "image/png"),
                    },
                    data={"provider": "openai"},
                )
    finally:
        settings.upload_dir = old_upload_dir
        settings.nail_tryon_upload_dir = old_nail_tryon_upload_dir
        settings.nail_tryon_segmentation_provider = old_segmentation_provider

    data = response.json()
    assert response.status_code == 200
    assert data["success"] is True
    assert data["message"] == "nail try-on generated successfully"
    assert data["data"]["result_image_url"].endswith("final_tryon_result.png")
    assert data["data"]["target_mask_url"].endswith("target_nail_mask.png")
    assert data["data"]["style_mask_url"].endswith("style_nail_mask.png")
    assert data["data"]["style_reference_url"].endswith("style_nails_only.png")


def test_nail_tryon_api_accepts_style_id(monkeypatch, tmp_path: Path):
    old_upload_dir = settings.upload_dir
    old_nail_tryon_upload_dir = settings.nail_tryon_upload_dir
    old_segmentation_provider = settings.nail_tryon_segmentation_provider
    settings.upload_dir = tmp_path / "uploads"
    settings.nail_tryon_upload_dir = settings.upload_dir / "nail_tryon"
    settings.nail_tryon_segmentation_provider = "mock"
    settings.ensure_directories()

    target_path = tmp_path / "target.png"
    style_path = tmp_path / "style.png"
    Image.new("RGB", (120, 100), (240, 220, 210)).save(target_path)
    Image.new("RGB", (120, 100), (180, 40, 120)).save(style_path)

    class FakeStyle:
        enhanced_url = str(style_path)
        image_url = str(style_path)
        image_path = str(style_path)
        original_url = str(style_path)

    monkeypatch.setattr(nail_tryon, "get_style", lambda style_id: FakeStyle())

    try:
        with TestClient(app) as client:
            with target_path.open("rb") as target_file:
                response = client.post(
                    "/api/nail-tryon",
                    files={
                        "target_hand_image": ("target.png", target_file, "image/png"),
                    },
                    data={
                        "style_id": "style_001",
                        "provider": "doubao",
                    },
                )
    finally:
        settings.upload_dir = old_upload_dir
        settings.nail_tryon_upload_dir = old_nail_tryon_upload_dir
        settings.nail_tryon_segmentation_provider = old_segmentation_provider

    data = response.json()
    assert response.status_code == 200
    assert data["data"]["style_id"] == "style_001"
    assert data["data"]["provider"] == "doubao"
    assert data["data"]["model_name"] == settings.doubao_image_model
    assert data["data"]["result_image_url"].endswith("final_tryon_result.png")
