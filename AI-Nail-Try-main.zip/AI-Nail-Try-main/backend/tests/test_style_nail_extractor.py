from pathlib import Path

from PIL import Image, ImageDraw

from app.services.style.style_nail_extractor import StyleNailExtractor


def test_extract_nails_only_creates_transparent_background(tmp_path: Path):
    style_path = tmp_path / "style.png"
    mask_path = tmp_path / "style_mask.png"
    output_path = tmp_path / "style_nails_only.png"

    Image.new("RGB", (80, 80), (200, 40, 120)).save(style_path)
    mask = Image.new("L", (80, 80), 0)
    draw = ImageDraw.Draw(mask)
    draw.rectangle((20, 20, 60, 60), fill=255)
    mask.save(mask_path)

    result = StyleNailExtractor().extract_nails_only(
        style_image_path=str(style_path),
        style_mask_path=str(mask_path),
        output_path=str(output_path),
    )

    assert result == str(output_path)
    image = Image.open(output_path).convert("RGBA")
    assert image.getpixel((5, 5))[3] == 0
    assert image.getpixel((40, 40))[3] == 255


def test_build_style_reference_composite(tmp_path: Path):
    style_path = tmp_path / "style.png"
    output_path = tmp_path / "style_reference_composite.png"
    Image.new("RGB", (100, 80), (180, 80, 140)).save(style_path)

    result = StyleNailExtractor().build_style_reference_composite(
        style_image_path=str(style_path),
        segmentation_result={
            "predictions": [
                {
                    "class": "Fingernail",
                    "points": [
                        {"x": 10, "y": 10},
                        {"x": 30, "y": 10},
                        {"x": 30, "y": 40},
                        {"x": 10, "y": 40},
                    ],
                }
            ]
        },
        output_path=str(output_path),
    )

    assert result == str(output_path)
    assert Image.open(output_path).size == (96, 96)
