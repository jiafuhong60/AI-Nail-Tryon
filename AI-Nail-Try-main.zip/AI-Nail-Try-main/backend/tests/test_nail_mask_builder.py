from pathlib import Path

import pytest
from PIL import Image

from app.services.mask.nail_mask_builder import build_nail_mask


def test_build_nail_mask_from_polygon(tmp_path: Path):
    image_path = tmp_path / "hand.png"
    mask_path = tmp_path / "mask.png"
    Image.new("RGB", (100, 100), "white").save(image_path)

    result = build_nail_mask(
        image_path=str(image_path),
        segmentation_result={
            "predictions": [
                {
                    "class": "Fingernail",
                    "points": [
                        {"x": 20, "y": 20},
                        {"x": 50, "y": 10},
                        {"x": 80, "y": 20},
                        {"x": 70, "y": 70},
                        {"x": 30, "y": 70},
                    ],
                }
            ]
        },
        output_mask_path=str(mask_path),
        dilate_px=2,
        feather_px=1,
    )

    assert result == str(mask_path)
    mask = Image.open(mask_path).convert("L")
    assert mask.getbbox() is not None
    assert mask.getpixel((50, 40)) > 0
    assert mask.getpixel((5, 5)) == 0


def test_build_nail_mask_raises_for_empty_predictions(tmp_path: Path):
    image_path = tmp_path / "hand.png"
    Image.new("RGB", (100, 100), "white").save(image_path)

    with pytest.raises(ValueError, match="No fingernail polygons"):
        build_nail_mask(
            image_path=str(image_path),
            segmentation_result={"predictions": []},
            output_mask_path=str(tmp_path / "mask.png"),
        )
