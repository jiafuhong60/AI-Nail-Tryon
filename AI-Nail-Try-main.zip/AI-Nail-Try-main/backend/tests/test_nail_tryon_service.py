from pathlib import Path

from PIL import Image

from app.services.tryon.nail_tryon_service import NailTryOnService


class FakeSegmenter:
    def infer(self, image_path: str):
        with Image.open(image_path) as image:
            width, height = image.size
        return {
            "image": {"width": width, "height": height},
            "predictions": [
                {
                    "class": "Fingernail",
                    "points": [
                        {"x": width * 0.3, "y": height * 0.2},
                        {"x": width * 0.7, "y": height * 0.2},
                        {"x": width * 0.7, "y": height * 0.7},
                        {"x": width * 0.3, "y": height * 0.7},
                    ],
                }
            ],
        }


def fake_edit_image(
    target_image_path: str,
    mask_path: str,
    reference_image_paths: list[str],
    prompt: str,
    output_path: str,
    provider: str,
    model_name: str | None,
) -> str:
    Image.open(target_image_path).save(output_path)
    return output_path


def test_nail_tryon_pipeline_outputs_all_artifacts(tmp_path: Path):
    target_path = tmp_path / "target.png"
    style_path = tmp_path / "style.png"
    output_path = tmp_path / "final_tryon_result.png"
    Image.new("RGB", (120, 100), (240, 220, 210)).save(target_path)
    Image.new("RGB", (120, 100), (180, 40, 120)).save(style_path)

    result = NailTryOnService(
        segmenter=FakeSegmenter(),
        image_edit_func=fake_edit_image,
    ).run_tryon(
        target_hand_image_path=str(target_path),
        style_hand_image_path=str(style_path),
        output_path=str(output_path),
        model_provider="openai",
        model_name="gpt-image-2",
    )

    assert result["success"] is True
    for key in [
        "target_mask_path",
        "style_mask_path",
        "style_reference_path",
        "result_image_path",
    ]:
        assert Path(result[key]).exists()
    assert result["provider"] == "openai"
    assert result["model_name"] == "gpt-image-2"
