from __future__ import annotations

import argparse
from pathlib import Path
import sys


BACKEND_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BACKEND_ROOT))

from app.services.tryon.nail_tryon_service import NailTryOnService


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run dual-image nail try-on demo.")
    parser.add_argument("--target", required=True, help="Target hand image path.")
    parser.add_argument("--style", required=True, help="Style hand image path.")
    parser.add_argument("--provider", default="openai", help="Image edit provider.")
    parser.add_argument("--model-name", default=None, help="Optional edit model name.")
    parser.add_argument("--output", required=True, help="Final output image path.")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    result = NailTryOnService().run_tryon(
        target_hand_image_path=args.target,
        style_hand_image_path=args.style,
        output_path=str(output_path),
        model_provider=args.provider,
        model_name=args.model_name,
    )

    print("Nail try-on completed.")
    print(f"target_nail_mask.png: {result['target_mask_path']}")
    print(f"style_nail_mask.png: {result['style_mask_path']}")
    print(f"style_nails_only.png: {result['style_reference_path']}")
    print(f"final_tryon_result.png: {result['result_image_path']}")
    print(f"segmentation_provider: {result['segmentation_provider']}")
    print(f"edit_provider: {result['provider']}")
    print(f"model_name: {result['model_name']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
