from fastapi import APIRouter, HTTPException

from app.schemas.dto import Merchant, MerchantListResponse
from app.services.merchant_service import get_merchant, list_merchants


router = APIRouter(prefix="/api/merchants", tags=["merchants"])


@router.get("", response_model=MerchantListResponse)
def get_merchants() -> MerchantListResponse:
    return MerchantListResponse(items=list_merchants())


@router.get("/{merchant_id}", response_model=Merchant)
def get_merchant_detail(merchant_id: str) -> Merchant:
    merchant = get_merchant(merchant_id)
    if merchant is None:
        raise HTTPException(status_code=404, detail="Merchant not found")
    return merchant
