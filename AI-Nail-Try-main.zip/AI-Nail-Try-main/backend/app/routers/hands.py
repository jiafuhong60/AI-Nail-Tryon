from fastapi import APIRouter, HTTPException

from app.schemas.dto import (
    HandImage,
    HandImageListResponse,
    HandPreferenceRequest,
    HandPreferenceResponse,
)
from app.services.hand_service import get_hand, list_hands
from app.services.preference_service import get_preference, save_preference


router = APIRouter(prefix="/api/hands", tags=["hands"])


@router.get("", response_model=HandImageListResponse)
def get_hands() -> HandImageListResponse:
    return HandImageListResponse(items=list_hands())


@router.get("/{hand_id}", response_model=HandImage)
def get_hand_detail(hand_id: str) -> HandImage:
    hand = get_hand(hand_id)
    if hand is None:
        raise HTTPException(status_code=404, detail="Hand not found")
    return hand


@router.get("/preferences/{user_id}", response_model=HandPreferenceResponse)
def get_hand_preferences(user_id: str) -> HandPreferenceResponse:
    return get_preference(user_id)


@router.post("/preferences", response_model=HandPreferenceResponse)
def save_hand_preferences(
    payload: HandPreferenceRequest,
) -> HandPreferenceResponse:
    return save_preference(payload)
