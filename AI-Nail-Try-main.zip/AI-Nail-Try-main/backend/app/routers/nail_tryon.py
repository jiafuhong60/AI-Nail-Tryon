import shutil
from pathlib import Path
from uuid import uuid4
import urllib.error
import urllib.request

from fastapi import APIRouter, File, Form, HTTPException, UploadFile

from app.core.config import settings
from app.schemas.nail_tryon import NailTryOnResponse
from app.services.style_service import get_style
from app.services.tryon.nail_tryon_service import NailTryOnService


router = APIRouter(prefix="/api", tags=["nail-tryon"])


@router.post("/nail-tryon", response_model=NailTryOnResponse)
def create_nail_tryon(
    target_hand_image: UploadFile = File(...),
    style_hand_image: UploadFile | None = File(None),
    style_id: str | None = Form(None),
    provider: str = Form(settings.nail_tryon_default_edit_provider),
    model_name: str | None = Form(None),
) -> NailTryOnResponse:
    session_id = f"nail_tryon_{uuid4().hex[:12]}"
    session_dir = settings.nail_tryon_upload_dir / session_id
    session_dir.mkdir(parents=True, exist_ok=True)

    target_path = session_dir / f"target_hand{_safe_suffix(target_hand_image.filename)}"
    output_path = session_dir / "final_tryon_result.png"

    _save_upload(target_hand_image, target_path)
    style_path = _resolve_style_image(style_hand_image, style_id, session_dir)

    try:
        result = NailTryOnService().run_tryon(
            target_hand_image_path=str(target_path),
            style_hand_image_path=str(style_path),
            output_path=str(output_path),
            model_provider=provider,
            model_name=model_name,
        )
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc

    return NailTryOnResponse(
        success=True,
        message="nail try-on generated successfully",
        data={
            "session_id": session_id,
            "result_image_url": _upload_url(result["result_image_path"]),
            "target_mask_url": _upload_url(result["target_mask_path"]),
            "style_mask_url": _upload_url(result["style_mask_path"]),
            "style_reference_url": _upload_url(result["style_reference_path"]),
            "provider": result["provider"],
            "model_name": result["model_name"],
            "segmentation_provider": result["segmentation_provider"],
            "style_id": style_id,
        },
    )


def _save_upload(upload: UploadFile, path: Path) -> None:
    with path.open("wb") as output_file:
        shutil.copyfileobj(upload.file, output_file)


def _safe_suffix(filename: str | None) -> str:
    suffix = Path(filename or "").suffix.lower()
    if suffix in {".jpg", ".jpeg", ".png", ".webp"}:
        return suffix
    return ".png"


def _resolve_style_image(
    style_hand_image: UploadFile | None,
    style_id: str | None,
    session_dir: Path,
) -> Path:
    if style_hand_image is not None:
        style_path = session_dir / f"style_hand{_safe_suffix(style_hand_image.filename)}"
        _save_upload(style_hand_image, style_path)
        return style_path

    if not style_id:
        raise HTTPException(
            status_code=400,
            detail="Either style_hand_image or style_id is required",
        )

    style = get_style(style_id)
    if style is None:
        raise HTTPException(status_code=404, detail="Style not found")

    style_url = style.enhanced_url or style.image_url or style.image_path or style.original_url
    if not style_url:
        raise HTTPException(status_code=400, detail="Style image URL is empty")

    style_path = session_dir / f"style_hand{_suffix_from_url(style_url)}"
    if style_url.startswith(("http://", "https://")):
        try:
            with urllib.request.urlopen(style_url, timeout=30) as response:
                style_path.write_bytes(response.read())
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            raise HTTPException(
                status_code=400,
                detail=f"Failed to download style image: {exc}",
            ) from exc
    else:
        source = Path(style_url.lstrip("/"))
        if not source.is_absolute():
            source = settings.app_dir / source
        if not source.exists():
            raise HTTPException(status_code=400, detail="Style image file not found")
        shutil.copyfile(source, style_path)
    return style_path


def _suffix_from_url(url: str) -> str:
    suffix = Path(url.split("?", 1)[0]).suffix.lower()
    if suffix in {".jpg", ".jpeg", ".png", ".webp"}:
        return suffix
    return ".png"


def _upload_url(path: str) -> str:
    full_path = Path(path).resolve()
    upload_root = settings.upload_dir.resolve()
    relative_path = full_path.relative_to(upload_root).as_posix()
    return f"/uploads/{relative_path}"
