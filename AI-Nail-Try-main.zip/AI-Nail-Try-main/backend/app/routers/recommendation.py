from fastapi import APIRouter, HTTPException

from app.schemas.dto import (
    MerchantRecommendationRequest,
    MerchantRecommendationResponse,
)
from app.services.recommendation_service import recommend_merchants


router = APIRouter(prefix="/api/recommend", tags=["recommendation"])


@router.post("/merchants", response_model=MerchantRecommendationResponse)
def get_merchant_recommendations(
    payload: MerchantRecommendationRequest,
) -> MerchantRecommendationResponse:
    try:
        result = recommend_merchants(payload)
    except ValueError:
        raise HTTPException(status_code=404, detail="Hand not found")
    if result is None:
        raise HTTPException(status_code=404, detail="Style not found")
    return result
