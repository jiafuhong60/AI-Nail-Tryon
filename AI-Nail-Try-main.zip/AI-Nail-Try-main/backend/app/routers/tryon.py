from fastapi import APIRouter, File, Form, HTTPException, UploadFile

from app.schemas.dto import TryOnResult, UserEventCreate
from app.services.event_service import create_event
from app.services.image_ai_service import generate_tryon_image
from app.services.style_service import get_style


router = APIRouter(prefix="/api", tags=["tryon"])


@router.post("/tryon", response_model=TryOnResult)
def create_tryon(
    hand_image: UploadFile = File(...),
    style_id: str = Form(...),
    user_id: str = Form("demo_user"),
) -> TryOnResult:
    style = get_style(style_id)
    if style is None:
        raise HTTPException(status_code=404, detail="Style not found")

    image_result = generate_tryon_image(hand_image, style)

    create_event(
        UserEventCreate(
            user_id=user_id,
            style_id=style_id,
            event_type="tryon",
        )
    )

    return TryOnResult(
        task_id=image_result.task_id,
        status="success",
        style_id=style_id,
        original_image_url=image_result.original_image_url,
        result_image_url=image_result.result_image_url,
        ai_reason=image_result.ai_reason,
        mock=image_result.mock,
    )
