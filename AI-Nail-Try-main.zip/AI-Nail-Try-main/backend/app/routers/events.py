from fastapi import APIRouter

from app.schemas.dto import (
    UserEventCreate,
    UserEventCreateResponse,
    UserEventListResponse,
)
from app.services.event_service import create_event, list_events


router = APIRouter(prefix="/api/events", tags=["events"])


@router.post("", response_model=UserEventCreateResponse)
def record_event(payload: UserEventCreate) -> UserEventCreateResponse:
    event = create_event(payload)
    return UserEventCreateResponse(success=True, event_id=event.id)


@router.get("", response_model=UserEventListResponse)
def get_events() -> UserEventListResponse:
    return UserEventListResponse(items=list_events())
