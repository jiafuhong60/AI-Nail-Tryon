from fastapi import APIRouter, HTTPException

from app.schemas.dto import ConfirmationRequest, ConfirmationResponse
from app.services.confirmation_service import create_confirmation, get_confirmation


router = APIRouter(prefix="/api/confirmation", tags=["confirmation"])


@router.post("", response_model=ConfirmationResponse)
def create_service_confirmation(
    payload: ConfirmationRequest,
) -> ConfirmationResponse:
    try:
        return create_confirmation(payload)
    except ValueError:
        raise HTTPException(status_code=404, detail="Style not found")
    except LookupError:
        raise HTTPException(status_code=404, detail="Merchant not found")


@router.get("/{confirmation_id}", response_model=ConfirmationResponse)
def get_service_confirmation(confirmation_id: str) -> ConfirmationResponse:
    confirmation = get_confirmation(confirmation_id)
    if confirmation is None:
        raise HTTPException(status_code=404, detail="Confirmation not found")
    return confirmation
