from fastapi import APIRouter, HTTPException

from app.schemas.dto import (
    AdviceRequest,
    AdviceResponse,
    PromotionRequest,
    PromotionResponse,
    ReportRequest,
    ReportResponse,
)
from app.services.analytics_service import get_dashboard_data
from app.services.llm_service import (
    generate_advice_text,
    generate_promotion_text,
    generate_report_text,
)
from app.services.style_service import get_style


router = APIRouter(prefix="/api/ai", tags=["ai"])


@router.post("/report", response_model=ReportResponse)
def generate_report(payload: ReportRequest) -> ReportResponse:
    dashboard = get_dashboard_data()
    return generate_report_text(payload.date, dashboard)


@router.post("/promotion", response_model=PromotionResponse)
def generate_promotion(payload: PromotionRequest) -> PromotionResponse:
    style = get_style(payload.style_id)
    if style is None:
        raise HTTPException(status_code=404, detail="Style not found")

    return generate_promotion_text(style, payload.channel)


@router.post("/advice", response_model=AdviceResponse)
def generate_advice(payload: AdviceRequest) -> AdviceResponse:
    style = get_style(payload.style_id)
    if style is None:
        raise HTTPException(status_code=404, detail="Style not found")

    return generate_advice_text(style)
