from fastapi import APIRouter, HTTPException

from app.schemas.dto import NailStyle, NailStyleListResponse
from app.services.style_service import get_style, load_styles


router = APIRouter(prefix="/api/styles", tags=["styles"])


@router.get("", response_model=NailStyleListResponse)
def list_styles() -> NailStyleListResponse:
    return NailStyleListResponse(items=load_styles())


@router.get("/{style_id}", response_model=NailStyle)
def retrieve_style(style_id: str) -> NailStyle:
    style = get_style(style_id)
    if style is None:
        raise HTTPException(status_code=404, detail="Style not found")
    return style

