from fastapi import APIRouter

from app.schemas.dto import DashboardData, PlatformDashboard
from app.services.analytics_service import (
    get_dashboard_data,
    get_platform_dashboard_data,
)


router = APIRouter(prefix="/api/analytics", tags=["analytics"])


@router.get("/dashboard", response_model=DashboardData)
def get_dashboard() -> DashboardData:
    return get_dashboard_data()


@router.get("/platform-dashboard", response_model=PlatformDashboard)
def get_platform_dashboard() -> PlatformDashboard:
    return get_platform_dashboard_data()
