from collections import Counter, defaultdict
from datetime import date, datetime
import json

from app.core.config import settings
from app.schemas.dto import (
    ColdStyle,
    DashboardData,
    HotTag,
    PlatformDashboard,
    Recommendation,
    TopStyle,
    UserEvent,
)
from app.services.event_service import list_events
from app.services.merchant_service import list_merchants
from app.services.style_service import load_styles


def _is_today(event: UserEvent) -> bool:
    try:
        return datetime.fromisoformat(event.created_at).date() == date.today()
    except ValueError:
        return False


def _style_event_counts(events: list[UserEvent]) -> dict[str, Counter[str]]:
    counts: dict[str, Counter[str]] = defaultdict(Counter)
    for event in events:
        counts[event.style_id][event.event_type] += 1
    return counts


def get_dashboard_data() -> DashboardData:
    styles = load_styles()
    events = list_events()
    today_events = [event for event in events if _is_today(event)]
    counts_by_style = _style_event_counts(today_events)
    styles_by_id = {style.id: style for style in styles}

    today_tryon_count = sum(
        1 for event in today_events if event.event_type == "tryon"
    )
    today_user_count = len({event.user_id for event in today_events})

    top_styles = _build_top_styles(styles, counts_by_style)
    hot_tags = _build_hot_tags(top_styles, styles_by_id)
    cold_styles = _build_cold_styles(styles, counts_by_style)
    recommendation = _build_recommendation(top_styles)

    return DashboardData(
        today_tryon_count=today_tryon_count,
        today_user_count=today_user_count,
        top_styles=top_styles[:5],
        hot_tags=hot_tags,
        cold_styles=cold_styles[:5],
        recommendation=recommendation,
    )


def _build_top_styles(
    styles: list,
    counts_by_style: dict[str, Counter[str]],
) -> list[TopStyle]:
    items: list[TopStyle] = []
    for style in styles:
        counts = counts_by_style[style.id]
        tryon_count = counts["tryon"]
        favorite_count = counts["favorite"]
        book_count = counts["book"]
        hot_score = round(
            tryon_count * 0.5 + favorite_count * 0.3 + book_count * 0.2,
            2,
        )
        items.append(
            TopStyle(
                style_id=style.id,
                name=style.name,
                tryon_count=tryon_count,
                favorite_count=favorite_count,
                book_count=book_count,
                hot_score=hot_score,
            )
        )

    return sorted(
        items,
        key=lambda item: (
            item.hot_score,
            item.tryon_count,
            item.favorite_count,
            item.book_count,
        ),
        reverse=True,
    )


def _build_hot_tags(
    top_styles: list[TopStyle],
    styles_by_id: dict,
) -> list[HotTag]:
    tag_counts: Counter[str] = Counter()
    for top_style in top_styles[:5]:
        style = styles_by_id.get(top_style.style_id)
        if style is None:
            continue

        weight = (
            top_style.tryon_count
            + top_style.favorite_count
            + top_style.book_count
        )
        if weight == 0:
            continue

        for tag in style.tags:
            tag_counts[tag] += weight

    return [
        HotTag(tag=tag, count=count)
        for tag, count in tag_counts.most_common(10)
    ]


def _build_cold_styles(
    styles: list,
    counts_by_style: dict[str, Counter[str]],
) -> list[ColdStyle]:
    cold_styles: list[ColdStyle] = []
    for style in styles:
        counts = counts_by_style[style.id]
        view_count = counts["view_style"]
        tryon_count = counts["tryon"]
        favorite_count = counts["favorite"]
        book_count = counts["book"]

        reason = None
        if view_count >= 3 and tryon_count <= 1:
            reason = "曝光较高但试戴率较低"
        elif tryon_count == 0:
            reason = "暂无试戴记录"
        elif favorite_count == 0:
            reason = "试戴后收藏转化较低"
        elif book_count == 0:
            reason = "暂未产生预约行为"

        if reason:
            cold_styles.append(
                ColdStyle(
                    style_id=style.id,
                    name=style.name,
                    reason=reason,
                )
            )

    return cold_styles


def _build_recommendation(top_styles: list[TopStyle]) -> Recommendation:
    if not top_styles:
        return Recommendation(
            main_style_id="",
            main_style_name="",
            reason="暂无款式数据，建议先维护款式库",
        )

    main_style = top_styles[0]
    if main_style.hot_score == 0:
        reason = "暂无行为数据，建议先选择该款式作为默认展示款"
    else:
        reason = "试戴量和收藏率表现较好，适合明日首页主推"

    return Recommendation(
        main_style_id=main_style.style_id,
        main_style_name=main_style.name,
        reason=reason,
    )


def get_platform_dashboard_data() -> PlatformDashboard:
    style_heat_ranking = _style_heat_ranking()
    preference_trends = _preference_trends()
    merchant_capabilities = _merchant_capabilities()
    supply_demand_alerts = _supply_demand_alerts(
        style_heat_ranking,
        merchant_capabilities,
    )
    overview = _platform_overview(style_heat_ranking, supply_demand_alerts)
    top_style = style_heat_ranking[0]["style_name"] if style_heat_ranking else "Demo 款式"
    top_preference = (
        preference_trends[0]["preference"] if preference_trends else "还原度"
    )

    return PlatformDashboard(
        overview=overview,
        style_heat_ranking=style_heat_ranking[:10],
        preference_trends=preference_trends,
        merchant_capabilities=merchant_capabilities,
        supply_demand_alerts=supply_demand_alerts,
        ai_suggestion=(
            f"Demo 运营建议：当前热度最高的款式是 {top_style}，用户最关注 {top_preference}。"
            f"当前有 {overview['high_priority_alert_count']} 条高优先级供需提醒，"
            "建议优先提升匹配商家曝光，并把高转化款式放入首页推荐位。"
        ),
        mock=True,
    )


def _load_data_file(file_name: str) -> list[dict]:
    file_path = settings.app_dir / "data" / file_name
    if not file_path.exists():
        return []

    try:
        raw_items = json.loads(file_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return []

    if not isinstance(raw_items, list):
        return []

    return [item for item in raw_items if isinstance(item, dict)]


def _to_int(value, default: int = 0) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _style_heat_ranking() -> list[dict]:
    raw_items = _load_data_file("behavior_metrics.json")
    if raw_items:
        grouped: dict[str, dict] = {}
        for item in raw_items:
            style_id = str(item.get("style_id") or "")
            if not style_id:
                continue

            current = grouped.setdefault(
                style_id,
                {
                    "style_id": style_id,
                    "style_name": str(item.get("style_name") or style_id),
                    "image_url": str(item.get("image_url") or ""),
                    "tags": [],
                    "exposure": 0,
                    "tryon_count": 0,
                    "favorite_count": 0,
                    "appointment_count": 0,
                    "conversion_rate": 0,
                    "heat_score": 0,
                },
            )
            if item.get("style_name"):
                current["style_name"] = str(item["style_name"])
            if item.get("image_url") and not current["image_url"]:
                current["image_url"] = str(item["image_url"])

            for tag in item.get("tags") or []:
                if tag not in current["tags"]:
                    current["tags"].append(tag)

            current["exposure"] += _to_int(item.get("exposure"))
            current["tryon_count"] += _to_int(item.get("tryon_count"))
            current["favorite_count"] += _to_int(item.get("favorite_count"))
            current["appointment_count"] += _to_int(item.get("appointment_count"))

        items = []
        for current in grouped.values():
            tryon_count = current["tryon_count"]
            appointment_count = current["appointment_count"]
            current["conversion_rate"] = round(
                appointment_count / max(tryon_count, 1),
                3,
            )
            current["heat_score"] = round(
                tryon_count * 0.5
                + current["favorite_count"] * 0.3
                + appointment_count * 0.2,
                1,
            )
            items.append(current)

        return sorted(items, key=lambda item: item["heat_score"], reverse=True)

    styles = load_styles()
    events = list_events()
    counts_by_style = _style_event_counts(events)
    items = []
    for style in styles:
        counts = counts_by_style[style.style_id]
        tryon_count = counts["tryon"]
        favorite_count = counts["favorite"]
        appointment_count = counts["book"]
        exposure = counts["view_style"] or tryon_count
        conversion_rate = round(appointment_count / max(tryon_count, 1), 3)
        heat_score = round(
            tryon_count * 0.5 + favorite_count * 0.3 + appointment_count * 0.2,
            1,
        )
        items.append(
            {
                "style_id": style.style_id,
                "style_name": style.style_name,
                "image_url": style.image_url,
                "tags": style.tags,
                "exposure": exposure,
                "tryon_count": tryon_count,
                "favorite_count": favorite_count,
                "appointment_count": appointment_count,
                "conversion_rate": conversion_rate,
                "heat_score": heat_score,
            }
        )
    return sorted(items, key=lambda item: item["heat_score"], reverse=True)


def _preference_trends() -> list[dict]:
    raw_items = _load_data_file("preference_events.json")
    if not raw_items:
        raw_items = [
            {"preference": "还原度", "count": 1},
            {"preference": "性价比", "count": 1},
        ]

    counts: Counter[str] = Counter()
    for item in raw_items:
        if "preference" in item and "count" in item:
            counts[str(item["preference"])] += _to_int(item["count"])
            continue

        preferences = item.get("preferences") or []
        if isinstance(preferences, str):
            preferences = [preferences]
        for preference in preferences:
            if preference:
                counts[str(preference)] += 1

    total = sum(counts.values()) or 1
    return [
        {
            "preference": preference,
            "count": count,
            "ratio": round(count / total, 3),
        }
        for preference, count in counts.most_common()
    ]


def _merchant_capabilities() -> list[dict]:
    return [
        {
            "merchant_id": merchant.merchant_id,
            "merchant_name": merchant.merchant_name,
            "distance": merchant.distance,
            "price_min": merchant.price_min,
            "price_max": merchant.price_max,
            "rating": merchant.rating,
            "available_time": merchant.available_time,
            "restore_score": merchant.restore_score,
            "creative_score": merchant.creative_score,
            "speed_score": merchant.speed_score,
            "cost_score": merchant.cost_score,
            "environment_score": merchant.environment_score,
            "price_stability_score": merchant.price_stability_score,
            "similar_work_count": merchant.similar_work_count,
            "skill_tags": merchant.skill_tags,
        }
        for merchant in list_merchants()[:10]
    ]


def _supply_demand_alerts(
    style_heat_ranking: list[dict],
    merchant_capabilities: list[dict],
) -> list[dict]:
    alerts: list[dict] = []
    top_heat_score = style_heat_ranking[0]["heat_score"] if style_heat_ranking else 0

    for style in style_heat_ranking[:5]:
        tags = [str(tag) for tag in style.get("tags", []) if tag]
        tag_set = set(tags)
        capable_merchants = [
            merchant
            for merchant in merchant_capabilities
            if tag_set.intersection(set(merchant.get("skill_tags") or []))
        ]
        high_restore_merchants = [
            merchant
            for merchant in capable_merchants
            if _to_int(merchant.get("restore_score")) >= 90
        ]
        capable_count = len(capable_merchants)
        high_restore_count = len(high_restore_merchants)

        if style["heat_score"] >= top_heat_score * 0.8 and high_restore_count < 2:
            priority = "high"
        elif capable_count < 3:
            priority = "medium"
        else:
            priority = "low"

        primary_tag = tags[0] if tags else style["style_name"]
        if priority == "high":
            alert = (
                f"{style['style_name']} 热度较高，但仅有 {high_restore_count} 个高还原度商家匹配，"
                "建议提升相关商家曝光。"
            )
        elif priority == "medium":
            alert = (
                f"{style['style_name']} 需求上升，当前有 {capable_count} 个匹配商家，"
                "建议持续关注供给覆盖。"
            )
        else:
            alert = f"{style['style_name']} 当前需求已有匹配商家覆盖。"

        alerts.append(
            {
                "style_id": style["style_id"],
                "style_tag": primary_tag,
                "alert": alert,
                "priority": priority,
                "heat_score": style["heat_score"],
                "capable_merchant_count": capable_count,
                "high_restore_merchant_count": high_restore_count,
            }
        )

    if alerts:
        priority_order = {"high": 0, "medium": 1, "low": 2}
        return sorted(
            alerts,
            key=lambda item: (priority_order[item["priority"]], -item["heat_score"]),
        )

    return [
        {
            "style_id": "",
            "style_tag": "Demo 款式",
            "alert": "暂无热度数据，建议继续收集 Demo 用户行为。",
            "priority": "medium",
            "heat_score": 0,
            "capable_merchant_count": 0,
            "high_restore_merchant_count": 0,
        }
    ]


def _platform_overview(
    style_heat_ranking: list[dict],
    supply_demand_alerts: list[dict],
) -> dict:
    total_exposure = sum(_to_int(item.get("exposure")) for item in style_heat_ranking)
    total_tryon_count = sum(
        _to_int(item.get("tryon_count")) for item in style_heat_ranking
    )
    total_favorite_count = sum(
        _to_int(item.get("favorite_count")) for item in style_heat_ranking
    )
    total_appointment_count = sum(
        _to_int(item.get("appointment_count")) for item in style_heat_ranking
    )
    high_priority_alert_count = sum(
        1 for item in supply_demand_alerts if item.get("priority") == "high"
    )

    return {
        "total_exposure": total_exposure,
        "total_tryon_count": total_tryon_count,
        "total_favorite_count": total_favorite_count,
        "total_appointment_count": total_appointment_count,
        "overall_conversion_rate": round(
            total_appointment_count / max(total_tryon_count, 1),
            3,
        ),
        "high_priority_alert_count": high_priority_alert_count,
    }
