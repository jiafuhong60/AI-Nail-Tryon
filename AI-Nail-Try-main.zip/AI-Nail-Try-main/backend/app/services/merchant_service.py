import json

from app.core.config import settings
from app.schemas.dto import Merchant


MERCHANTS_FILE = settings.app_dir / "data" / "merchants.json"


def list_merchants() -> list[Merchant]:
    if not MERCHANTS_FILE.exists():
        return []

    raw_items = json.loads(MERCHANTS_FILE.read_text(encoding="utf-8"))
    return [Merchant.model_validate(item) for item in raw_items]


def get_merchant(merchant_id: str) -> Merchant | None:
    for merchant in list_merchants():
        if merchant.merchant_id == merchant_id:
            return merchant
    return None
