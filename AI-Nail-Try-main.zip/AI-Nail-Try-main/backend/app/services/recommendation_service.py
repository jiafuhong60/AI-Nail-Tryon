import json
from collections import Counter

from app.core.config import settings
from app.schemas.dto import MerchantRecommendationRequest, MerchantRecommendationResponse
from app.services.hand_service import get_hand
from app.services.merchant_service import list_merchants
from app.services.style_service import get_style


PREFERENCE_EVENTS_FILE = settings.app_dir / "data" / "preference_events.json"


def recommend_merchants(
    payload: MerchantRecommendationRequest,
) -> MerchantRecommendationResponse | None:
    style = get_style(payload.style_id)
    if style is None:
        return None

    if payload.hand_id and get_hand(payload.hand_id) is None:
        raise ValueError("Hand not found")

    _record_preferences(payload.preferences)
    merchants = list_merchants()
    ranked_items = []
    for merchant in merchants:
        score = _match_score(merchant, style, payload.preferences)
        ranked_items.append(
            {
                "merchant_id": merchant.merchant_id,
                "merchant_name": merchant.merchant_name,
                "distance": merchant.distance,
                "price_range": f"{merchant.price_min}-{merchant.price_max}",
                "rating": merchant.rating,
                "available_time": merchant.available_time,
                "similar_work_count": merchant.similar_work_count,
                "match_score": score,
                "match_reason": _match_reason(merchant, style, payload.preferences),
            }
        )

    ranked_items.sort(key=lambda item: item["match_score"], reverse=True)
    return MerchantRecommendationResponse(
        style_id=style.style_id,
        style_name=style.style_name,
        hand_id=payload.hand_id,
        preferences=payload.preferences,
        items=ranked_items[:5],
        mock=True,
    )


def _match_score(merchant, style, preferences: list[str]) -> float:
    style_terms = set(style.tags + [style.color, style.element, style.scene, style.style_tag])
    tag_matches = len(style_terms.intersection(set(merchant.skill_tags)))
    tag_match_score = min(tag_matches / max(len(style_terms), 1), 1) * 100
    distance_score = max(0, 100 - merchant.distance * 12)
    similar_work_score = min(merchant.similar_work_count * 3, 100)

    weighted = tag_match_score * 0.25
    weighted += merchant.restore_score * (0.18 if "还原度" in preferences else 0.10)
    weighted += merchant.cost_score * (0.16 if "性价比" in preferences else 0.08)
    weighted += merchant.price_stability_score * (0.12 if "价格透明" in preferences else 0.06)
    weighted += merchant.creative_score * (0.14 if "创意" in preferences else 0.06)
    weighted += merchant.speed_score * (0.12 if "服务速度" in preferences else 0.06)
    weighted += merchant.environment_score * (0.12 if "环境" in preferences else 0.06)
    weighted += distance_score * (0.16 if "距离" in preferences else 0.10)
    weighted += similar_work_score * 0.10
    return round(min(weighted, 100), 1)


def _match_reason(merchant, style, preferences: list[str]) -> str:
    matched_tags = [tag for tag in merchant.skill_tags if tag in style.tags or tag in [style.color, style.element, style.scene, style.style_tag]]
    matched_text = "、".join(matched_tags[:4]) or style.style_tag
    preference_text = "、".join(preferences) or "综合能力"
    return (
        f"该商家擅长{matched_text}，相似作品较多，"
        f"{preference_text}相关评分较高。"
    )


def _record_preferences(preferences: list[str]) -> None:
    if not preferences:
        return
    PREFERENCE_EVENTS_FILE.parent.mkdir(parents=True, exist_ok=True)
    if PREFERENCE_EVENTS_FILE.exists():
        raw_items = json.loads(PREFERENCE_EVENTS_FILE.read_text(encoding="utf-8"))
    else:
        raw_items = []
    counter = Counter({item["preference"]: item["count"] for item in raw_items})
    for preference in preferences:
        counter[preference] += 1
    items = [
        {"preference": preference, "count": count}
        for preference, count in counter.items()
    ]
    PREFERENCE_EVENTS_FILE.write_text(
        json.dumps(items, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
