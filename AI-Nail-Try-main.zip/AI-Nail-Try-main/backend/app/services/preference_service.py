import json

from app.core.config import settings
from app.schemas.dto import HandPreferenceRequest, HandPreferenceResponse


PREFERENCES_FILE = settings.app_dir / "data" / "preferences.json"


def _ensure_preferences_file() -> None:
    PREFERENCES_FILE.parent.mkdir(parents=True, exist_ok=True)
    if not PREFERENCES_FILE.exists():
        PREFERENCES_FILE.write_text("[]\n", encoding="utf-8")


def save_preference(payload: HandPreferenceRequest) -> HandPreferenceResponse:
    _ensure_preferences_file()
    items = json.loads(PREFERENCES_FILE.read_text(encoding="utf-8"))
    items = [item for item in items if item.get("user_id") != payload.user_id]
    items.append(payload.model_dump())
    PREFERENCES_FILE.write_text(
        json.dumps(items, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    return HandPreferenceResponse(**payload.model_dump(), mock=True)


def get_preference(user_id: str) -> HandPreferenceResponse:
    _ensure_preferences_file()
    items = json.loads(PREFERENCES_FILE.read_text(encoding="utf-8"))
    for item in items:
        if item.get("user_id") == user_id:
            return HandPreferenceResponse(**item, mock=True)
    return HandPreferenceResponse(user_id=user_id, mock=True)
