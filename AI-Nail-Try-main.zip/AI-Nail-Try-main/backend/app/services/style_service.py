import json

from app.core.config import settings
from app.schemas.dto import NailStyle


STYLES_FILE = settings.app_dir / "data" / "styles.json"


def load_styles() -> list[NailStyle]:
    if not STYLES_FILE.exists():
        return []

    raw_items = json.loads(STYLES_FILE.read_text(encoding="utf-8"))
    return [NailStyle.model_validate(_normalize_style(item)) for item in raw_items]


def get_style(style_id: str) -> NailStyle | None:
    for style in load_styles():
        if style.id == style_id or style.style_id == style_id:
            return style
    return None


def _normalize_style(item: dict) -> dict:
    normalized = dict(item)
    normalized["id"] = normalized.get("id") or normalized.get("style_id")
    normalized["name"] = normalized.get("name") or normalized.get("style_name")
    normalized["image_url"] = normalized.get("image_url") or normalized.get("image_path")
    normalized["style_id"] = normalized.get("style_id") or normalized.get("id")
    normalized["style_name"] = normalized.get("style_name") or normalized.get("name")
    normalized["image_path"] = normalized.get("image_path") or normalized.get("image_url")
    normalized["original_url"] = normalized.get("original_url", "")
    normalized["enhanced_url"] = normalized.get("enhanced_url") or normalized["image_url"]
    normalized["style_tag"] = normalized.get("style_tag") or (
        normalized.get("tags", [""])[0] if normalized.get("tags") else ""
    )
    normalized["element"] = normalized.get("element", "")
    normalized["complexity"] = normalized.get("complexity", "")
    return normalized
