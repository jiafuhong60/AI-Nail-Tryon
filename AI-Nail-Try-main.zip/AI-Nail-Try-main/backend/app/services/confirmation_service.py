import json
from uuid import uuid4

from app.core.config import settings
from app.schemas.dto import ConfirmationRequest, ConfirmationResponse
from app.services.merchant_service import get_merchant
from app.services.style_service import get_style


CONFIRMATIONS_FILE = settings.app_dir / "data" / "confirmations.json"


def _ensure_confirmations_file() -> None:
    CONFIRMATIONS_FILE.parent.mkdir(parents=True, exist_ok=True)
    if not CONFIRMATIONS_FILE.exists():
        CONFIRMATIONS_FILE.write_text("[]\n", encoding="utf-8")


def create_confirmation(payload: ConfirmationRequest) -> ConfirmationResponse:
    style = get_style(payload.style_id)
    if style is None:
        raise ValueError("Style not found")

    merchant = get_merchant(payload.merchant_id)
    if merchant is None:
        raise LookupError("Merchant not found")

    response = ConfirmationResponse(
        confirmation_id=f"confirm_{uuid4().hex[:12]}",
        style_id=style.style_id,
        style_name=style.style_name,
        merchant_id=merchant.merchant_id,
        merchant_name=merchant.merchant_name,
        tryon_result_url=payload.tryon_result_url,
        expected_price=f"{merchant.price_min}-{merchant.price_max}",
        user_preferences=payload.preferences,
        key_points=_key_points(payload.preferences),
        merchant_suggestion=_merchant_suggestion(style, merchant, payload.preferences),
        mock=True,
    )

    _ensure_confirmations_file()
    items = json.loads(CONFIRMATIONS_FILE.read_text(encoding="utf-8"))
    items.append(response.model_dump())
    CONFIRMATIONS_FILE.write_text(
        json.dumps(items, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    return response


def get_confirmation(confirmation_id: str) -> ConfirmationResponse | None:
    _ensure_confirmations_file()
    items = json.loads(CONFIRMATIONS_FILE.read_text(encoding="utf-8"))
    for item in items:
        if item.get("confirmation_id") == confirmation_id:
            return ConfirmationResponse.model_validate(item)
    return None


def list_confirmations() -> list[ConfirmationResponse]:
    _ensure_confirmations_file()
    items = json.loads(CONFIRMATIONS_FILE.read_text(encoding="utf-8"))
    return [ConfirmationResponse.model_validate(item) for item in items]


def _key_points(preferences: list[str]) -> list[str]:
    points = ["服务前建议展示相似作品给用户确认"]
    if "还原度" in preferences:
        points.append("重点确认颜色、图案和质感还原度")
    if "性价比" in preferences or "价格透明" in preferences:
        points.append("确认最终价格是否包含卸甲、延长和加固")
    if "服务速度" in preferences:
        points.append("提前确认预计服务时长")
    if "环境" in preferences:
        points.append("确认门店环境和座位安排")
    return points


def _merchant_suggestion(style, merchant, preferences: list[str]) -> str:
    preference_text = "、".join(preferences) or "还原度"
    return (
        f"建议商家优先展示相似{style.color}{style.element}作品，"
        f"并在服务前确认用户对{preference_text}的具体预期。"
    )
