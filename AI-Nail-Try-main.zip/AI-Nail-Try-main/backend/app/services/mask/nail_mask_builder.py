from pathlib import Path
from typing import Any

from PIL import Image, ImageDraw, ImageFilter


def build_nail_mask(
    image_path: str,
    segmentation_result: dict[str, Any],
    output_mask_path: str,
    dilate_px: int = 2,
    feather_px: int = 1,
) -> str:
    image = Image.open(image_path)
    width, height = image.size
    mask = Image.new("L", (width, height), 0)
    draw = ImageDraw.Draw(mask)

    polygons = _extract_fingernail_polygons(segmentation_result)
    if not polygons:
        raise ValueError("No fingernail polygons found in segmentation result")

    for polygon in polygons:
        draw.polygon(polygon, fill=255)

    if dilate_px > 0:
        size = dilate_px * 2 + 1
        mask = mask.filter(ImageFilter.MaxFilter(size=size))

    if feather_px > 0:
        mask = mask.filter(ImageFilter.GaussianBlur(radius=feather_px))

    output_path = Path(output_mask_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    mask.save(output_path)
    return str(output_path)


def _extract_fingernail_polygons(
    segmentation_result: dict[str, Any],
) -> list[list[tuple[int, int]]]:
    polygons: list[list[tuple[int, int]]] = []
    predictions = segmentation_result.get("predictions") or []

    for prediction in predictions:
        label = (
            prediction.get("class")
            or prediction.get("class_name")
            or prediction.get("name")
            or ""
        )
        if "nail" not in str(label).lower():
            continue

        points = prediction.get("points") or []
        polygon: list[tuple[int, int]] = []
        for point in points:
            if isinstance(point, dict):
                x = point.get("x")
                y = point.get("y")
            elif isinstance(point, (list, tuple)) and len(point) >= 2:
                x = point[0]
                y = point[1]
            else:
                continue

            if x is None or y is None:
                continue
            polygon.append((int(round(float(x))), int(round(float(y)))))

        if len(polygon) >= 3:
            polygons.append(polygon)

    return polygons
