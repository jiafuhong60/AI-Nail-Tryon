from pathlib import Path
from typing import Any

from PIL import Image, ImageOps

from app.services.mask.nail_mask_builder import _extract_fingernail_polygons


class StyleNailExtractor:
    def extract_nails_only(
        self,
        style_image_path: str,
        style_mask_path: str,
        output_path: str,
    ) -> str:
        image = Image.open(style_image_path).convert("RGBA")
        mask = Image.open(style_mask_path).convert("L")
        transparent = Image.new("RGBA", image.size, (0, 0, 0, 0))
        transparent.paste(image, (0, 0), mask)

        destination = Path(output_path)
        destination.parent.mkdir(parents=True, exist_ok=True)
        transparent.save(destination)
        return str(destination)

    def build_style_reference_composite(
        self,
        style_image_path: str,
        segmentation_result: dict[str, Any],
        output_path: str,
    ) -> str:
        image = Image.open(style_image_path).convert("RGBA")
        polygons = _extract_fingernail_polygons(segmentation_result)
        if not polygons:
            raise ValueError("No fingernail polygons found for style reference")

        crops: list[Image.Image] = []
        for polygon in polygons:
            xs = [point[0] for point in polygon]
            ys = [point[1] for point in polygon]
            box = (
                max(min(xs) - 4, 0),
                max(min(ys) - 4, 0),
                min(max(xs) + 4, image.width),
                min(max(ys) + 4, image.height),
            )
            crop = image.crop(box)
            crops.append(ImageOps.contain(crop, (96, 96)))

        tile_width = 96
        tile_height = 96
        composite = Image.new(
            "RGBA",
            (tile_width * len(crops), tile_height),
            (255, 255, 255, 0),
        )
        for index, crop in enumerate(crops):
            x = index * tile_width + (tile_width - crop.width) // 2
            y = (tile_height - crop.height) // 2
            composite.alpha_composite(crop, (x, y))

        destination = Path(output_path)
        destination.parent.mkdir(parents=True, exist_ok=True)
        composite.save(destination)
        return str(destination)
