from pathlib import Path
from typing import Any


class RoboflowFingernailSegmenter:
    def __init__(self, api_key: str, model_id: str, api_url: str) -> None:
        if not api_key:
            raise ValueError("ROBOFLOW_API_KEY is required for Roboflow segmentation")

        try:
            from inference_sdk import InferenceHTTPClient
        except ImportError as exc:
            raise RuntimeError(
                "inference-sdk is required for Roboflow segmentation"
            ) from exc

        self.model_id = model_id
        self.client = InferenceHTTPClient(api_url=api_url, api_key=api_key)

    def infer(self, image_path: str) -> dict[str, Any]:
        path = Path(image_path)
        if not path.exists():
            raise FileNotFoundError(f"Segmentation image not found: {path}")

        try:
            result = self.client.infer(str(path), model_id=self.model_id)
        except Exception as exc:
            raise RuntimeError(f"Roboflow fingernail segmentation failed: {exc}") from exc

        if not isinstance(result, dict):
            raise RuntimeError("Roboflow returned a non-JSON segmentation response")
        return result


class MockFingernailSegmenter:
    def infer(self, image_path: str) -> dict[str, Any]:
        from PIL import Image

        path = Path(image_path)
        if not path.exists():
            raise FileNotFoundError(f"Segmentation image not found: {path}")

        with Image.open(path) as image:
            width, height = image.size

        nail_width = max(width // 16, 8)
        nail_height = max(height // 11, 10)
        y = max(height // 4, 4)
        centers = [
            int(width * 0.25),
            int(width * 0.38),
            int(width * 0.50),
            int(width * 0.62),
            int(width * 0.75),
        ]

        predictions: list[dict[str, Any]] = []
        for center_x in centers:
            left = max(center_x - nail_width // 2, 0)
            right = min(center_x + nail_width // 2, width - 1)
            top = max(y, 0)
            bottom = min(y + nail_height, height - 1)
            predictions.append(
                {
                    "class": "Fingernail",
                    "points": [
                        {"x": left, "y": top + nail_height * 0.25},
                        {"x": center_x, "y": top},
                        {"x": right, "y": top + nail_height * 0.25},
                        {"x": right, "y": bottom - nail_height * 0.2},
                        {"x": center_x, "y": bottom},
                        {"x": left, "y": bottom - nail_height * 0.2},
                    ],
                }
            )

        return {
            "image": {"width": width, "height": height},
            "predictions": predictions,
            "mock": True,
        }
