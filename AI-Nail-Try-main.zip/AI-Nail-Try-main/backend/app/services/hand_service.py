import json

from app.core.config import settings
from app.schemas.dto import HandImage


HANDS_FILE = settings.app_dir / "data" / "hands.json"


def list_hands() -> list[HandImage]:
    if not HANDS_FILE.exists():
        return []
    raw_items = json.loads(HANDS_FILE.read_text(encoding="utf-8"))
    return [HandImage.model_validate(item) for item in raw_items]


def get_hand(hand_id: str) -> HandImage | None:
    for hand in list_hands():
        if hand.hand_id == hand_id:
            return hand
    return None
