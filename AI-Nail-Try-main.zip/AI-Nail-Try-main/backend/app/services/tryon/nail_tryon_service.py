import json
from pathlib import Path
from typing import Any, Callable

from app.core.config import settings
from app.prompts.nail_tryon_prompts import NAIL_TRYON_PROMPT_CN
from app.services.image_ai_service import edit_image
from app.services.mask.nail_mask_builder import build_nail_mask
from app.services.segmentation.roboflow_fingernail import (
    MockFingernailSegmenter,
    RoboflowFingernailSegmenter,
)
from app.services.style.style_nail_extractor import StyleNailExtractor


ImageEditFunc = Callable[
    [str, str, list[str], str, str, str, str | None],
    str,
]


class NailTryOnService:
    def __init__(
        self,
        segmenter: Any | None = None,
        image_edit_func: ImageEditFunc | None = None,
        style_extractor: StyleNailExtractor | None = None,
    ) -> None:
        self.segmenter = segmenter
        self.image_edit_func = image_edit_func or edit_image
        self.style_extractor = style_extractor or StyleNailExtractor()

    def run_tryon(
        self,
        target_hand_image_path: str,
        style_hand_image_path: str,
        output_path: str,
        model_provider: str = "openai",
        model_name: str | None = None,
    ) -> dict[str, Any]:
        resolved_model_name = model_name or _default_model_name(model_provider)
        output = Path(output_path)
        session_dir = output.parent
        session_dir.mkdir(parents=True, exist_ok=True)

        segmenter = self.segmenter or _build_segmenter()

        target_segmentation = segmenter.infer(target_hand_image_path)
        target_segmentation_path = session_dir / "target_segmentation_result.json"
        _write_json(target_segmentation_path, target_segmentation)

        target_mask_path = session_dir / "target_nail_mask.png"
        build_nail_mask(
            image_path=target_hand_image_path,
            segmentation_result=target_segmentation,
            output_mask_path=str(target_mask_path),
            dilate_px=settings.nail_tryon_mask_dilate_px,
            feather_px=settings.nail_tryon_mask_feather_px,
        )

        style_segmentation = segmenter.infer(style_hand_image_path)
        style_segmentation_path = session_dir / "style_segmentation_result.json"
        _write_json(style_segmentation_path, style_segmentation)

        style_mask_path = session_dir / "style_nail_mask.png"
        build_nail_mask(
            image_path=style_hand_image_path,
            segmentation_result=style_segmentation,
            output_mask_path=str(style_mask_path),
            dilate_px=settings.nail_tryon_mask_dilate_px,
            feather_px=settings.nail_tryon_mask_feather_px,
        )

        style_nails_only_path = session_dir / "style_nails_only.png"
        self.style_extractor.extract_nails_only(
            style_image_path=style_hand_image_path,
            style_mask_path=str(style_mask_path),
            output_path=str(style_nails_only_path),
        )

        style_reference_path = style_nails_only_path
        if settings.nail_tryon_debug_output:
            composite_path = session_dir / "style_reference_composite.png"
            try:
                self.style_extractor.build_style_reference_composite(
                    style_image_path=style_hand_image_path,
                    segmentation_result=style_segmentation,
                    output_path=str(composite_path),
                )
            except Exception:
                composite_path = style_nails_only_path

        result_image_path = self.image_edit_func(
            target_hand_image_path,
            str(target_mask_path),
            [str(style_reference_path), style_hand_image_path],
            NAIL_TRYON_PROMPT_CN,
            str(output),
            model_provider,
            resolved_model_name,
        )

        return {
            "success": True,
            "target_hand_image_path": target_hand_image_path,
            "style_hand_image_path": style_hand_image_path,
            "target_segmentation_result_path": str(target_segmentation_path),
            "style_segmentation_result_path": str(style_segmentation_path),
            "target_mask_path": str(target_mask_path),
            "style_mask_path": str(style_mask_path),
            "style_reference_path": str(style_reference_path),
            "result_image_path": result_image_path,
            "segmentation_provider": _segmenter_name(segmenter),
            "provider": model_provider,
            "model_name": resolved_model_name,
        }


def _build_segmenter() -> Any:
    provider = settings.nail_tryon_segmentation_provider.lower()
    if provider == "mock":
        return MockFingernailSegmenter()

    if provider == "roboflow" and settings.roboflow_api_key:
        return RoboflowFingernailSegmenter(
            api_key=settings.roboflow_api_key,
            model_id=settings.roboflow_model_id,
            api_url=settings.roboflow_api_url,
        )

    return MockFingernailSegmenter()


def _segmenter_name(segmenter: Any) -> str:
    if isinstance(segmenter, MockFingernailSegmenter):
        return "mock"
    if isinstance(segmenter, RoboflowFingernailSegmenter):
        return "roboflow"
    return segmenter.__class__.__name__


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def _default_model_name(provider: str) -> str | None:
    provider_name = provider.lower().strip()
    if provider_name == "qwen":
        return settings.qwen_image_model
    if provider_name == "openai":
        return settings.openai_image_model
    if provider_name == "doubao":
        return settings.doubao_image_model
    return None
