import shutil
import base64
import json
import mimetypes
from pathlib import Path
from uuid import uuid4
import urllib.error
import urllib.request

from fastapi import UploadFile
from PIL import Image, ImageStat

from app.core.config import settings
from app.schemas.dto import NailStyle


class ImageTryOnResult:
    def __init__(
        self,
        task_id: str,
        original_image_url: str,
        result_image_url: str,
        ai_reason: str,
        mock: bool,
    ) -> None:
        self.task_id = task_id
        self.original_image_url = original_image_url
        self.result_image_url = result_image_url
        self.ai_reason = ai_reason
        self.mock = mock


def generate_tryon_image(
    hand_image: UploadFile,
    style: NailStyle,
) -> ImageTryOnResult:
    task_id = f"tryon_{uuid4().hex[:12]}"
    suffix = Path(hand_image.filename or "").suffix or ".png"
    original_filename = f"{task_id}_original{suffix}"
    result_filename = f"{task_id}_result{suffix}"

    original_path = settings.upload_dir / original_filename
    result_path = settings.output_dir / result_filename

    with original_path.open("wb") as output_file:
        shutil.copyfileobj(hand_image.file, output_file)

    if settings.image_ai_mode.lower() == "real":
        return _generate_real_or_mock(
            task_id=task_id,
            original_path=original_path,
            result_path=result_path,
            original_filename=original_filename,
            result_filename=result_filename,
            style=style,
        )

    return _generate_mock(
        task_id=task_id,
        original_path=original_path,
        result_path=result_path,
        original_filename=original_filename,
        result_filename=result_filename,
        style=style,
    )


def _generate_real_or_mock(
    task_id: str,
    original_path: Path,
    result_path: Path,
    original_filename: str,
    result_filename: str,
    style: NailStyle,
) -> ImageTryOnResult:
    if not settings.image_ai_api_key:
        return _generate_mock(
            task_id,
            original_path,
            result_path,
            original_filename,
            result_filename,
            style,
        )

    try:
        raise NotImplementedError("Real image AI provider is not configured yet")
    except Exception:
        return _generate_mock(
            task_id,
            original_path,
            result_path,
            original_filename,
            result_filename,
            style,
        )


def _generate_mock(
    task_id: str,
    original_path: Path,
    result_path: Path,
    original_filename: str,
    result_filename: str,
    style: NailStyle,
) -> ImageTryOnResult:
    shutil.copyfile(original_path, result_path)
    return ImageTryOnResult(
        task_id=task_id,
        original_image_url=f"/uploads/{original_filename}",
        result_image_url=f"/outputs/{result_filename}",
        ai_reason=style.reason,
        mock=True,
    )


def edit_image(
    target_image_path: str,
    mask_path: str,
    reference_image_paths: list[str],
    prompt: str,
    output_path: str,
    provider: str = "openai",
    model_name: str | None = None,
) -> str:
    destination = Path(output_path)
    destination.parent.mkdir(parents=True, exist_ok=True)

    if settings.image_ai_mode.lower() == "real":
        try:
            provider_name = provider.lower().strip() or settings.nail_tryon_default_edit_provider
            if provider_name == "qwen":
                return _edit_with_qwen(
                    target_image_path,
                    mask_path,
                    reference_image_paths,
                    prompt,
                    str(destination),
                    model_name or settings.qwen_image_model,
                )
            if provider_name == "openai":
                return _edit_with_openai(
                    target_image_path,
                    mask_path,
                    reference_image_paths,
                    prompt,
                    str(destination),
                    model_name or settings.openai_image_model,
                )
            if provider_name == "doubao":
                return _edit_with_doubao(
                    target_image_path,
                    mask_path,
                    reference_image_paths,
                    prompt,
                    str(destination),
                    model_name or settings.doubao_image_model,
                )
        except Exception:
            pass

    return _mock_edit_image(
        target_image_path=target_image_path,
        mask_path=mask_path,
        reference_image_paths=reference_image_paths,
        output_path=str(destination),
    )


def _mock_edit_image(
    target_image_path: str,
    mask_path: str,
    reference_image_paths: list[str],
    output_path: str,
) -> str:
    try:
        target = Image.open(target_image_path).convert("RGBA")
        mask = Image.open(mask_path).convert("L").resize(target.size)
        color = _average_reference_color(reference_image_paths)
        overlay = Image.new("RGBA", target.size, color)
        softened_mask = mask.point(lambda value: int(value * 0.55))
        target.paste(overlay, (0, 0), softened_mask)
        target.convert("RGB").save(output_path)
    except Exception:
        shutil.copyfile(target_image_path, output_path)

    return output_path


def _edit_with_qwen(
    target_image_path: str,
    mask_path: str,
    reference_image_paths: list[str],
    prompt: str,
    output_path: str,
    model_name: str,
) -> str:
    if not settings.qwen_api_key:
        raise ValueError("QWEN_API_KEY is required for Qwen image edit")

    content = [
        {"image": _image_data_url(target_image_path)},
        {"image": _image_data_url(reference_image_paths[0])},
        {"image": _image_data_url(mask_path)},
        {"text": f"{prompt}\n请严格将第三张图作为第一张图的可编辑 mask。"},
    ]
    payload = {
        "model": model_name,
        "input": {"messages": [{"role": "user", "content": content}]},
        "parameters": {"n": 1, "prompt_extend": True, "watermark": False},
    }
    body = _post_json(settings.qwen_image_api_url, payload, settings.qwen_api_key)
    image_url = _find_first_image_url(body)
    if image_url:
        _download_url(image_url, output_path)
        return output_path
    image_b64 = _find_first_b64(body)
    if image_b64:
        Path(output_path).write_bytes(base64.b64decode(image_b64))
        return output_path
    raise RuntimeError("Qwen image edit response did not include an image")


def _edit_with_openai(
    target_image_path: str,
    mask_path: str,
    reference_image_paths: list[str],
    prompt: str,
    output_path: str,
    model_name: str,
) -> str:
    api_key = settings.openai_api_key or settings.image_ai_api_key
    if not api_key:
        raise ValueError("OPENAI_API_KEY is required for OpenAI image edit")

    fields = {
        "model": model_name,
        "prompt": (
            f"{prompt}\n参考款式图路径数量：{len(reference_image_paths)}。"
            "请只编辑 mask 覆盖的指甲区域。"
        ),
        "size": "1024x1024",
    }
    files = {
        "image": (Path(target_image_path).name, Path(target_image_path).read_bytes(), _mime_type(target_image_path)),
        "mask": (Path(mask_path).name, Path(mask_path).read_bytes(), "image/png"),
    }
    body = _post_multipart(
        "https://api.openai.com/v1/images/edits",
        fields,
        files,
        api_key,
    )
    image_url = _find_first_image_url(body)
    if image_url:
        _download_url(image_url, output_path)
        return output_path
    image_b64 = _find_first_b64(body)
    if image_b64:
        Path(output_path).write_bytes(base64.b64decode(image_b64))
        return output_path
    raise RuntimeError("OpenAI image edit response did not include an image")


def _edit_with_doubao(
    target_image_path: str,
    mask_path: str,
    reference_image_paths: list[str],
    prompt: str,
    output_path: str,
    model_name: str,
) -> str:
    if not settings.ark_api_key:
        raise ValueError("ARK_API_KEY is required for Doubao image edit")

    base_url = settings.ark_base_url.rstrip("/")
    payload = {
        "model": model_name,
        "prompt": (
            f"{prompt}\n请将参考款式自然应用到目标图指甲区域，"
            "不要迁移参考图的手型、肤色、背景。"
        ),
        "image": _image_data_url(target_image_path),
        "mask": _image_data_url(mask_path),
        "reference_images": [_image_data_url(path) for path in reference_image_paths[:2]],
        "response_format": "url",
    }
    body = _post_json(f"{base_url}/images/generations", payload, settings.ark_api_key)
    image_url = _find_first_image_url(body)
    if image_url:
        _download_url(image_url, output_path)
        return output_path
    image_b64 = _find_first_b64(body)
    if image_b64:
        Path(output_path).write_bytes(base64.b64decode(image_b64))
        return output_path
    raise RuntimeError("Doubao image edit response did not include an image")


def _average_reference_color(reference_image_paths: list[str]) -> tuple[int, int, int, int]:
    for reference_path in reference_image_paths:
        path = Path(reference_path)
        if not path.exists():
            continue

        image = Image.open(path).convert("RGBA")
        alpha = image.getchannel("A")
        bbox = alpha.getbbox()
        if bbox:
            image = image.crop(bbox)
            alpha = alpha.crop(bbox)

        stat = ImageStat.Stat(image, alpha)
        if stat.count[0] > 0:
            red, green, blue = [int(value) for value in stat.mean[:3]]
            return red, green, blue, 255

    return 180, 90, 130, 255


def _image_data_url(path: str) -> str:
    mime_type = _mime_type(path)
    encoded = base64.b64encode(Path(path).read_bytes()).decode("utf-8")
    return f"data:{mime_type};base64,{encoded}"


def _mime_type(path: str) -> str:
    mime_type, _ = mimetypes.guess_type(path)
    return mime_type or "image/png"


def _post_json(url: str, payload: dict, api_key: str) -> dict:
    request = urllib.request.Request(
        url,
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
        },
        method="POST",
    )
    return _read_json_response(request)


def _post_multipart(
    url: str,
    fields: dict[str, str],
    files: dict[str, tuple[str, bytes, str]],
    api_key: str,
) -> dict:
    boundary = f"----nailtryon{uuid4().hex}"
    body = bytearray()
    for name, value in fields.items():
        body.extend(f"--{boundary}\r\n".encode())
        body.extend(f'Content-Disposition: form-data; name="{name}"\r\n\r\n'.encode())
        body.extend(str(value).encode("utf-8"))
        body.extend(b"\r\n")
    for name, (filename, content, mime_type) in files.items():
        body.extend(f"--{boundary}\r\n".encode())
        body.extend(
            (
                f'Content-Disposition: form-data; name="{name}"; '
                f'filename="{filename}"\r\n'
            ).encode()
        )
        body.extend(f"Content-Type: {mime_type}\r\n\r\n".encode())
        body.extend(content)
        body.extend(b"\r\n")
    body.extend(f"--{boundary}--\r\n".encode())

    request = urllib.request.Request(
        url,
        data=bytes(body),
        headers={
            "Content-Type": f"multipart/form-data; boundary={boundary}",
            "Authorization": f"Bearer {api_key}",
        },
        method="POST",
    )
    return _read_json_response(request)


def _read_json_response(request: urllib.request.Request) -> dict:
    try:
        with urllib.request.urlopen(request, timeout=180) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"Image provider HTTP {exc.code}: {body}") from exc


def _find_first_image_url(value) -> str | None:
    if isinstance(value, dict):
        for key, item in value.items():
            if key in {"url", "image", "image_url"} and isinstance(item, str):
                if item.startswith(("http://", "https://")):
                    return item
            found = _find_first_image_url(item)
            if found:
                return found
    if isinstance(value, list):
        for item in value:
            found = _find_first_image_url(item)
            if found:
                return found
    return None


def _find_first_b64(value) -> str | None:
    if isinstance(value, dict):
        for key, item in value.items():
            if key in {"b64_json", "base64", "image_base64"} and isinstance(item, str):
                return item
            found = _find_first_b64(item)
            if found:
                return found
    if isinstance(value, list):
        for item in value:
            found = _find_first_b64(item)
            if found:
                return found
    return None


def _download_url(url: str, output_path: str) -> None:
    with urllib.request.urlopen(url, timeout=180) as response:
        Path(output_path).write_bytes(response.read())
