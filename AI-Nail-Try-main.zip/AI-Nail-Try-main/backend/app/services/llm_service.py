import json
import urllib.error
import urllib.request

from app.core.config import settings
from app.schemas.dto import (
    AdviceResponse,
    DashboardData,
    NailStyle,
    PromotionResponse,
    ReportResponse,
)


SUPPORTED_PROVIDERS = {"openai", "gemini", "qwen", "deepseek"}


def generate_report_text(report_date: str, dashboard: DashboardData) -> ReportResponse:
    if settings.llm_mode.lower() == "real":
        try:
            _validate_real_llm_config()
            if settings.llm_provider.lower().strip() == "qwen":
                return _qwen_report(report_date, dashboard)
        except Exception:
            pass
    return _mock_report(report_date, dashboard)


def generate_promotion_text(style: NailStyle, channel: str) -> PromotionResponse:
    if settings.llm_mode.lower() == "real":
        try:
            _validate_real_llm_config()
            if settings.llm_provider.lower().strip() == "qwen":
                return _qwen_promotion(style, channel)
        except Exception:
            pass
    return _mock_promotion(style, channel)


def generate_advice_text(style: NailStyle) -> AdviceResponse:
    if settings.llm_mode.lower() == "real":
        try:
            _validate_real_llm_config()
            if settings.llm_provider.lower().strip() == "qwen":
                return _qwen_advice(style)
        except Exception:
            pass
    return _mock_advice(style)


def _validate_real_llm_config() -> None:
    provider = settings.llm_provider.lower().strip()
    if provider not in SUPPORTED_PROVIDERS:
        raise ValueError("Unsupported LLM provider")
    if not settings.llm_model.strip():
        raise ValueError("LLM model is required")
    if not _provider_api_key(provider):
        raise ValueError("LLM API key is required")


def _provider_api_key(provider: str) -> str:
    keys = {
        "openai": settings.openai_api_key,
        "gemini": settings.gemini_api_key,
        "qwen": settings.qwen_api_key,
        "deepseek": settings.deepseek_api_key,
    }
    return keys.get(provider, "")


def _mock_report(report_date: str, dashboard: DashboardData) -> ReportResponse:
    top_names = "、".join(style.name for style in dashboard.top_styles[:3])
    hot_tags = "、".join(tag.tag for tag in dashboard.hot_tags[:3])
    cold_names = "、".join(style.name for style in dashboard.cold_styles[:3])
    return ReportResponse(
        summary=(
            f"{report_date} 总试戴次数为 {dashboard.today_tryon_count} 次，"
            f"活跃用户数为 {dashboard.today_user_count}。"
        ),
        hot_trend=(
            f"{hot_tags or '暂无明显热门标签'}表现较突出，"
            f"{top_names or '暂无热门款式'}可继续观察。"
        ),
        risk=f"{cold_names or '暂无明显风险款式'}需要关注曝光和试戴转化。",
        suggestion=dashboard.recommendation.reason,
        mock=True,
    )


def _mock_promotion(style: NailStyle, channel: str) -> PromotionResponse:
    return PromotionResponse(
        title=f"{style.name}，日常也能精致出片",
        content=(
            f"{style.name}主打{style.color}，适合{style.scene}。"
            f"{style.reason}，适合在{channel}渠道做轻量推广。"
        ),
        hashtags=["美甲", f"{style.tags[0]}美甲", f"{style.color}美甲", "显白美甲"],
        mock=True,
    )


def _mock_advice(style: NailStyle) -> AdviceResponse:
    return AdviceResponse(
        advice=(
            f"这款{style.name}颜色偏{style.color}，适合{style.scene}，"
            f"整体风格{style.tags[0]}，{style.reason}"
        ),
        mock=True,
    )


def _qwen_report(report_date: str, dashboard: DashboardData) -> ReportResponse:
    content = _qwen_chat(
        "你是美甲门店运营分析师，请输出 JSON。",
        (
            f"日期：{report_date}\n"
            f"今日试戴：{dashboard.today_tryon_count}\n"
            f"今日用户：{dashboard.today_user_count}\n"
            f"热门款式：{[style.name for style in dashboard.top_styles[:5]]}\n"
            "请返回 JSON 字段 summary, hot_trend, risk, suggestion。"
        ),
    )
    payload = _parse_json_object(content)
    return ReportResponse(
        summary=str(payload.get("summary", content)),
        hot_trend=str(payload.get("hot_trend", "")),
        risk=str(payload.get("risk", "")),
        suggestion=str(payload.get("suggestion", "")),
        mock=False,
    )


def _qwen_promotion(style: NailStyle, channel: str) -> PromotionResponse:
    content = _qwen_chat(
        "你是美甲推广文案助手，请输出 JSON。",
        (
            f"款式：{style.name}\n颜色：{style.color}\n场景：{style.scene}\n"
            f"标签：{style.tags}\n渠道：{channel}\n"
            "请返回 JSON 字段 title, content, hashtags，其中 hashtags 是字符串数组。"
        ),
    )
    payload = _parse_json_object(content)
    hashtags = payload.get("hashtags", [])
    if not isinstance(hashtags, list):
        hashtags = ["美甲", "AI试戴"]
    return PromotionResponse(
        title=str(payload.get("title", f"{style.name}推广文案")),
        content=str(payload.get("content", content)),
        hashtags=[str(tag) for tag in hashtags],
        mock=False,
    )


def _qwen_advice(style: NailStyle) -> AdviceResponse:
    content = _qwen_chat(
        "你是美甲试戴顾问。",
        (
            f"款式：{style.name}\n颜色：{style.color}\n场景：{style.scene}\n"
            f"标签：{style.tags}\n推荐理由：{style.reason}\n"
            "请给用户一段自然、简洁的试戴适配建议。"
        ),
    )
    return AdviceResponse(advice=content.strip(), mock=False)


def _qwen_chat(system_prompt: str, user_prompt: str) -> str:
    payload = {
        "model": settings.llm_model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        "temperature": 0.7,
        "stream": False,
    }
    request = urllib.request.Request(
        settings.qwen_text_api_url,
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {settings.qwen_api_key}",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=90) as response:
            body = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        error_body = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"Qwen LLM HTTP {exc.code}: {error_body}") from exc
    return body["choices"][0]["message"]["content"]


def _parse_json_object(text: str) -> dict:
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        start = text.find("{")
        end = text.rfind("}")
        if start >= 0 and end > start:
            try:
                return json.loads(text[start : end + 1])
            except json.JSONDecodeError:
                return {}
    return {}
