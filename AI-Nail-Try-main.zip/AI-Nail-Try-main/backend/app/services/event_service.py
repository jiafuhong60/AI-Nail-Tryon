import json
from datetime import datetime
from uuid import uuid4

from app.core.config import settings
from app.schemas.dto import UserEvent, UserEventCreate


EVENTS_FILE = settings.app_dir / "data" / "events.json"


def _ensure_events_file() -> None:
    EVENTS_FILE.parent.mkdir(parents=True, exist_ok=True)
    if not EVENTS_FILE.exists():
        EVENTS_FILE.write_text("[]\n", encoding="utf-8")


def list_events() -> list[UserEvent]:
    _ensure_events_file()
    raw_items = json.loads(EVENTS_FILE.read_text(encoding="utf-8"))
    return [UserEvent.model_validate(item) for item in raw_items]


def create_event(payload: UserEventCreate) -> UserEvent:
    events = list_events()
    event = UserEvent(
        id=f"event_{uuid4().hex[:12]}",
        user_id=payload.user_id,
        style_id=payload.style_id,
        event_type=payload.event_type,
        created_at=datetime.now().replace(microsecond=0).isoformat(),
    )
    events.append(event)
    EVENTS_FILE.write_text(
        json.dumps(
            [item.model_dump() for item in events],
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    return event
