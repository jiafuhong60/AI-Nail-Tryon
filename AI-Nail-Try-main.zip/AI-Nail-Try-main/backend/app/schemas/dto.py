from typing import Literal

from pydantic import BaseModel, Field


class NailStyle(BaseModel):
    id: str
    style_id: str
    name: str
    style_name: str
    original_url: str = ""
    enhanced_url: str = ""
    image_url: str
    image_path: str
    tags: list[str]
    style_tag: str = ""
    scene: str
    color: str
    element: str = ""
    complexity: str = ""
    reason: str
    is_new: bool


class NailStyleListResponse(BaseModel):
    items: list[NailStyle]


EventType = Literal[
    "view_style",
    "select_style",
    "tryon",
    "favorite",
    "save_result",
    "book",
]


class UserEventCreate(BaseModel):
    user_id: str
    style_id: str
    event_type: EventType


class UserEvent(BaseModel):
    id: str
    user_id: str
    style_id: str
    event_type: EventType
    created_at: str


class UserEventCreateResponse(BaseModel):
    success: bool
    event_id: str


class UserEventListResponse(BaseModel):
    items: list[UserEvent]


class TopStyle(BaseModel):
    style_id: str
    name: str
    tryon_count: int
    favorite_count: int
    book_count: int
    hot_score: float


class HotTag(BaseModel):
    tag: str
    count: int


class ColdStyle(BaseModel):
    style_id: str
    name: str
    reason: str


class Recommendation(BaseModel):
    main_style_id: str
    main_style_name: str
    reason: str


class DashboardData(BaseModel):
    today_tryon_count: int
    today_user_count: int
    top_styles: list[TopStyle]
    hot_tags: list[HotTag]
    cold_styles: list[ColdStyle]
    recommendation: Recommendation


class TryOnResult(BaseModel):
    task_id: str
    status: Literal["success", "failed"]
    style_id: str
    original_image_url: str
    result_image_url: str
    ai_reason: str
    mock: bool


class ReportRequest(BaseModel):
    date: str


class ReportResponse(BaseModel):
    summary: str
    hot_trend: str
    risk: str
    suggestion: str
    mock: bool


class PromotionRequest(BaseModel):
    style_id: str
    channel: str = "xiaohongshu"


class PromotionResponse(BaseModel):
    title: str
    content: str
    hashtags: list[str]
    mock: bool


class AdviceRequest(BaseModel):
    style_id: str


class AdviceResponse(BaseModel):
    advice: str
    mock: bool


class HandPreferenceRequest(BaseModel):
    user_id: str = "demo_user"
    skin_tone: str = "natural"
    hand_shape: str = "standard"
    preferred_colors: list[str] = Field(default_factory=list)
    preferred_tags: list[str] = Field(default_factory=list)
    occasion: str = "daily"
    budget_range: str = "100-300"


class HandPreferenceResponse(HandPreferenceRequest):
    mock: bool


class HandImage(BaseModel):
    hand_id: str
    hand_url: str
    local_path: str = ""
    skin_tone: str
    hand_shape: str


class HandImageListResponse(BaseModel):
    items: list[HandImage]


class Merchant(BaseModel):
    merchant_id: str
    merchant_name: str
    distance: float
    price_min: int
    price_max: int
    rating: float
    available_time: str
    restore_score: int
    creative_score: int
    speed_score: int
    cost_score: int
    environment_score: int
    price_stability_score: int
    similar_work_count: int
    skill_tags: list[str]


class MerchantListResponse(BaseModel):
    items: list[Merchant]


class StyleRecommendationRequest(BaseModel):
    user_id: str = "demo_user"
    preferred_tags: list[str] = Field(default_factory=list)
    preferred_colors: list[str] = Field(default_factory=list)
    occasion: str = "daily"


class StyleRecommendationResponse(BaseModel):
    items: list[NailStyle]
    reason: str
    mock: bool


class MerchantRecommendationResponse(BaseModel):
    style_id: str
    style_name: str
    hand_id: str | None
    preferences: list[str]
    items: list[dict]
    mock: bool


class MerchantRecommendationRequest(BaseModel):
    user_id: str = "demo_user"
    hand_id: str | None = None
    style_id: str
    preferences: list[str] = Field(default_factory=list)


class ConfirmationRequest(BaseModel):
    user_id: str = "demo_user"
    hand_id: str | None = None
    style_id: str
    merchant_id: str
    preferences: list[str] = Field(default_factory=list)
    tryon_result_url: str | None = None


class ConfirmationResponse(BaseModel):
    confirmation_id: str
    style_id: str
    style_name: str
    merchant_id: str
    merchant_name: str
    tryon_result_url: str | None
    expected_price: str
    user_preferences: list[str]
    key_points: list[str]
    merchant_suggestion: str
    mock: bool


class StyleHeatItem(BaseModel):
    style_id: str
    style_name: str
    image_url: str = ""
    tags: list[str] = Field(default_factory=list)
    exposure: int
    tryon_count: int
    favorite_count: int
    appointment_count: int
    conversion_rate: float
    heat_score: float


class PreferenceTrendItem(BaseModel):
    preference: str
    count: int
    ratio: float


class MerchantCapabilityItem(BaseModel):
    merchant_id: str
    merchant_name: str
    distance: float = 0
    price_min: int = 0
    price_max: int = 0
    rating: float = 0
    available_time: str = ""
    restore_score: int
    creative_score: int
    speed_score: int
    cost_score: int
    environment_score: int
    price_stability_score: int = 0
    similar_work_count: int
    skill_tags: list[str] = Field(default_factory=list)


class SupplyDemandAlert(BaseModel):
    style_id: str = ""
    style_tag: str
    alert: str
    priority: Literal["high", "medium", "low"] = "medium"
    heat_score: float = 0
    capable_merchant_count: int = 0
    high_restore_merchant_count: int = 0


class PlatformOverview(BaseModel):
    total_exposure: int
    total_tryon_count: int
    total_favorite_count: int
    total_appointment_count: int
    overall_conversion_rate: float
    high_priority_alert_count: int


class PlatformDashboard(BaseModel):
    overview: PlatformOverview
    style_heat_ranking: list[StyleHeatItem]
    preference_trends: list[PreferenceTrendItem]
    merchant_capabilities: list[MerchantCapabilityItem]
    supply_demand_alerts: list[SupplyDemandAlert]
    ai_suggestion: str
    mock: bool
