from pydantic import BaseModel


class NailTryOnResponse(BaseModel):
    success: bool
    message: str
    data: dict | None = None
