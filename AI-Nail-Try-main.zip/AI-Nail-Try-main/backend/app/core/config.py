import os
from pathlib import Path

try:
    from dotenv import load_dotenv
except ImportError:
    load_dotenv = None


if load_dotenv is not None:
    load_dotenv(Path(__file__).resolve().parents[2] / ".env")


class Settings:
    service_name: str = os.getenv("SERVICE_NAME", "nail-ai-backend")
    cors_origins: str = os.getenv("CORS_ORIGINS", "*")
    image_ai_mode: str = os.getenv("IMAGE_AI_MODE", "mock")
    image_ai_api_key: str = os.getenv("IMAGE_AI_API_KEY", "")
    openai_image_model: str = os.getenv("OPENAI_IMAGE_MODEL", "gpt-image-1")
    qwen_image_model: str = os.getenv("QWEN_IMAGE_MODEL", "qwen-image-edit-plus")
    qwen_image_api_url: str = os.getenv(
        "QWEN_IMAGE_API_URL",
        "https://dashscope.aliyuncs.com/api/v1/services/aigc/multimodal-generation/generation",
    )
    doubao_image_model: str = os.getenv(
        "DOUBAO_IMAGE_MODEL",
        "doubao-seededit-3-0-i2i-250628",
    )
    ark_api_key: str = os.getenv("ARK_API_KEY", "")
    ark_base_url: str = os.getenv(
        "ARK_BASE_URL",
        "https://ark.cn-beijing.volces.com/api/v3",
    )
    llm_mode: str = os.getenv("LLM_MODE", "mock")
    llm_provider: str = os.getenv("LLM_PROVIDER", "")
    llm_model: str = os.getenv("LLM_MODEL", "qwen3.7-plus")
    qwen_text_api_url: str = os.getenv(
        "QWEN_TEXT_API_URL",
        "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions",
    )
    openai_api_key: str = os.getenv("OPENAI_API_KEY", "")
    gemini_api_key: str = os.getenv("GEMINI_API_KEY", "")
    qwen_api_key: str = os.getenv("QWEN_API_KEY", "")
    deepseek_api_key: str = os.getenv("DEEPSEEK_API_KEY", "")
    roboflow_api_key: str = os.getenv("ROBOFLOW_API_KEY", "")
    roboflow_api_url: str = os.getenv(
        "ROBOFLOW_API_URL",
        "https://serverless.roboflow.com",
    )
    roboflow_model_id: str = os.getenv(
        "ROBOFLOW_MODEL_ID",
        "fingernail-segmentation-yy1l7/3",
    )
    nail_tryon_segmentation_provider: str = os.getenv(
        "NAIL_TRYON_SEGMENTATION_PROVIDER",
        "roboflow",
    )
    nail_tryon_default_edit_provider: str = os.getenv(
        "NAIL_TRYON_DEFAULT_EDIT_PROVIDER",
        "openai",
    )
    nail_tryon_mask_dilate_px: int = int(os.getenv("NAIL_TRYON_MASK_DILATE_PX", "2"))
    nail_tryon_mask_feather_px: int = int(os.getenv("NAIL_TRYON_MASK_FEATHER_PX", "1"))
    nail_tryon_debug_output: bool = (
        os.getenv("NAIL_TRYON_DEBUG_OUTPUT", "true").lower() == "true"
    )

    app_dir: Path = Path(__file__).resolve().parents[1]
    upload_dir: Path = app_dir / "uploads"
    output_dir: Path = app_dir / "outputs"
    static_dir: Path = app_dir / "static"
    style_static_dir: Path = static_dir / "styles"
    nail_tryon_upload_dir: Path = upload_dir / "nail_tryon"

    @property
    def allowed_origins(self) -> list[str]:
        if self.cors_origins.strip() == "*":
            return ["*"]
        return [
            origin.strip()
            for origin in self.cors_origins.split(",")
            if origin.strip()
        ]

    def ensure_directories(self) -> None:
        self.upload_dir.mkdir(parents=True, exist_ok=True)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.style_static_dir.mkdir(parents=True, exist_ok=True)
        self.nail_tryon_upload_dir.mkdir(parents=True, exist_ok=True)


settings = Settings()
