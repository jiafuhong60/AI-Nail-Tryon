import { useState, type ReactNode } from "react";
import { HomeScreen } from "./components/HomeScreen";
import { StyleLibraryScreen } from "./components/StyleLibraryScreen";
import { HandSelectionScreen } from "./components/HandSelectionScreen";
import { TryOnResultScreen } from "./components/TryOnResultScreen";
import { PreferenceScreen } from "./components/PreferenceScreen";
import { MerchantScreen } from "./components/MerchantScreen";
import { ConfirmationScreen } from "./components/ConfirmationScreen";
import { SuccessScreen } from "./components/SuccessScreen";
import { AdminDashboard } from "./components/admin/AdminDashboard";
import type {
  AdviceResponse,
  ConfirmationResponse,
  MerchantRecommendationItem,
  NailStyle,
  TryOnResult,
} from "./api";

export type Screen =
  | "home"
  | "library"
  | "hand"
  | "result"
  | "preference"
  | "merchant"
  | "confirm"
  | "success"
  | "admin";

export type {
  AdviceResponse,
  ConfirmationResponse,
  MerchantRecommendationItem,
  NailStyle,
  TryOnResult,
};

export default function App() {
  const [activeScreen, setActiveScreen] = useState<Screen>("home");
  const [selectedStyle, setSelectedStyle] = useState<NailStyle | null>(null);
  const [handPreviewUrl, setHandPreviewUrl] = useState<string | null>(null);
  const [tryOnResult, setTryOnResult] = useState<TryOnResult | null>(null);
  const [advice, setAdvice] = useState<AdviceResponse | null>(null);
  const [selectedPreferences, setSelectedPreferences] = useState<string[]>([]);
  const [selectedMerchant, setSelectedMerchant] =
    useState<MerchantRecommendationItem | null>(null);
  const [confirmation, setConfirmation] = useState<ConfirmationResponse | null>(null);

  const navigate = (screen: Screen) => setActiveScreen(screen);

  if (activeScreen === "admin") {
    return <AdminDashboard onExitAdmin={() => navigate("home")} />;
  }

  return (
    <div
      style={{
        minHeight: "100vh",
        minWidth: "100vw",
        background: "linear-gradient(135deg, #DDD8D2 0%, #ECE6DF 100%)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: 24,
        boxSizing: "border-box",
        fontFamily: "'DM Sans', sans-serif",
      }}
    >
      <PhoneFrame>
        {activeScreen === "home" && <HomeScreen onNavigate={navigate} />}
        {activeScreen === "library" && (
          <StyleLibraryScreen
            onNavigate={navigate}
            onSelectStyle={(style) => {
              setSelectedStyle(style);
              setTryOnResult(null);
              setAdvice(null);
              setSelectedMerchant(null);
              setConfirmation(null);
              navigate("hand");
            }}
          />
        )}
        {activeScreen === "hand" && (
          <HandSelectionScreen
            onNavigate={navigate}
            selectedStyle={selectedStyle}
            onTryOnComplete={(file, result) => {
              if (handPreviewUrl) URL.revokeObjectURL(handPreviewUrl);
              setHandPreviewUrl(URL.createObjectURL(file));
              setTryOnResult(result);
              navigate("result");
            }}
          />
        )}
        {activeScreen === "result" && (
          <TryOnResultScreen
            onNavigate={navigate}
            selectedStyle={selectedStyle}
            handPreviewUrl={handPreviewUrl}
            tryOnResult={tryOnResult}
            advice={advice}
            onAdviceLoaded={setAdvice}
          />
        )}
        {activeScreen === "preference" && (
          <PreferenceScreen
            onNavigate={navigate}
            onSelectPreferences={(prefs) => {
              setSelectedPreferences(prefs);
              setSelectedMerchant(null);
              setConfirmation(null);
              navigate("merchant");
            }}
          />
        )}
        {activeScreen === "merchant" && (
          <MerchantScreen
            onNavigate={navigate}
            selectedStyle={selectedStyle}
            selectedPreferences={selectedPreferences}
            onSelectMerchant={(merchant) => {
              setSelectedMerchant(merchant);
              setConfirmation(null);
              navigate("confirm");
            }}
          />
        )}
        {activeScreen === "confirm" && (
          <ConfirmationScreen
            onNavigate={navigate}
            selectedMerchant={selectedMerchant}
            selectedStyle={selectedStyle}
            selectedPreferences={selectedPreferences}
            handPreviewUrl={handPreviewUrl}
            tryOnResult={tryOnResult}
            onConfirmationCreated={(nextConfirmation) => {
              setConfirmation(nextConfirmation);
              navigate("success");
            }}
          />
        )}
        {activeScreen === "success" && (
          <SuccessScreen
            onNavigate={navigate}
            confirmation={confirmation}
            selectedMerchant={selectedMerchant}
          />
        )}
      </PhoneFrame>
    </div>
  );
}

function PhoneFrame({ children }: { children: ReactNode }) {
  return (
    <div
      style={{
        width: 390,
        height: 844,
        maxWidth: "calc(100vw - 32px)",
        maxHeight: "calc(100vh - 32px)",
        background: "#FAF7F3",
        borderRadius: 48,
        overflow: "hidden",
        boxShadow: "0 28px 72px rgba(0,0,0,0.22)",
        position: "relative",
        display: "flex",
        flexDirection: "column",
      }}
    >
      <div
        style={{
          position: "absolute",
          top: 14,
          left: "50%",
          transform: "translateX(-50%)",
          width: 126,
          height: 37,
          background: "#1A1A1A",
          borderRadius: 20,
          zIndex: 200,
        }}
      />
      <div style={{ flex: 1, overflow: "hidden" }}>{children}</div>
    </div>
  );
}
