export const API_BASE_URL = (
  import.meta.env.VITE_API_BASE_URL || "http://localhost:8000"
).replace(/\/$/, "");

export type NailStyle = {
  id: string;
  style_id: string;
  name: string;
  style_name: string;
  original_url?: string;
  enhanced_url?: string;
  image_url: string;
  image_path: string;
  tags: string[];
  style_tag?: string;
  scene: string;
  color: string;
  element?: string;
  complexity?: string;
  reason: string;
  is_new: boolean;
};

export type TryOnResult = {
  task_id: string;
  status: "success" | "failed";
  style_id: string;
  original_image_url?: string;
  result_image_url: string;
  ai_reason: string;
  mock: boolean;
  provider?: ImageEditProvider;
  model_name?: string | null;
  target_mask_url?: string;
  style_mask_url?: string;
  style_reference_url?: string;
  segmentation_provider?: string;
};

export type ImageEditProvider = "qwen" | "openai" | "doubao";

export type ImageModelOption = {
  provider: ImageEditProvider;
  modelName: string;
  label: string;
};

export const IMAGE_MODEL_OPTIONS: ImageModelOption[] = [
  {
    provider: "qwen",
    modelName: "qwen-image-edit-plus",
    label: "Qwen Image Edit Plus",
  },
  {
    provider: "openai",
    modelName: "gpt-image-1",
    label: "OpenAI GPT Image",
  },
  {
    provider: "doubao",
    modelName: "doubao-seededit-3-0-i2i-250628",
    label: "Doubao SeedEdit3.0",
  },
];

export type AdviceResponse = {
  advice: string;
  mock: boolean;
};

export type MerchantRecommendationItem = {
  merchant_id: string;
  merchant_name: string;
  distance: number;
  price_range: string;
  rating: number;
  available_time: string;
  similar_work_count: number;
  match_score: number;
  match_reason: string;
};

export type MerchantRecommendationResponse = {
  style_id: string;
  style_name: string;
  hand_id: string | null;
  preferences: string[];
  items: MerchantRecommendationItem[];
  mock: boolean;
};

export type ConfirmationResponse = {
  confirmation_id: string;
  style_id: string;
  style_name: string;
  merchant_id: string;
  merchant_name: string;
  tryon_result_url: string | null;
  expected_price: string;
  user_preferences: string[];
  key_points: string[];
  merchant_suggestion: string;
  mock: boolean;
};

export type StyleHeatItem = {
  style_id: string;
  style_name: string;
  image_url: string;
  tags: string[];
  exposure: number;
  tryon_count: number;
  favorite_count: number;
  appointment_count: number;
  conversion_rate: number;
  heat_score: number;
};

export type PreferenceTrendItem = {
  preference: string;
  count: number;
  ratio: number;
};

export type MerchantCapabilityItem = {
  merchant_id: string;
  merchant_name: string;
  distance: number;
  price_min: number;
  price_max: number;
  rating: number;
  available_time: string;
  restore_score: number;
  creative_score: number;
  speed_score: number;
  cost_score: number;
  environment_score: number;
  price_stability_score: number;
  similar_work_count: number;
  skill_tags: string[];
};

export type SupplyDemandAlert = {
  style_id: string;
  style_tag: string;
  alert: string;
  priority: "high" | "medium" | "low";
  heat_score: number;
  capable_merchant_count: number;
  high_restore_merchant_count: number;
};

export type PlatformOverview = {
  total_exposure: number;
  total_tryon_count: number;
  total_favorite_count: number;
  total_appointment_count: number;
  overall_conversion_rate: number;
  high_priority_alert_count: number;
};

export type PlatformDashboard = {
  overview: PlatformOverview;
  style_heat_ranking: StyleHeatItem[];
  preference_trends: PreferenceTrendItem[];
  merchant_capabilities: MerchantCapabilityItem[];
  supply_demand_alerts: SupplyDemandAlert[];
  ai_suggestion: string;
  mock: boolean;
};

export type ReportResponse = {
  summary: string;
  hot_trend: string;
  risk: string;
  suggestion: string;
  mock: boolean;
};

export type EventType =
  | "view_style"
  | "select_style"
  | "tryon"
  | "favorite"
  | "save_result"
  | "book";

async function requestJson<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    ...init,
    headers: {
      ...(init?.body instanceof FormData ? {} : { "Content-Type": "application/json" }),
      ...init?.headers,
    },
  });

  if (!response.ok) {
    let message = `Request failed: ${response.status}`;
    try {
      const payload = await response.json();
      message = payload.detail || message;
    } catch {
      message = response.statusText || message;
    }
    throw new Error(message);
  }

  return response.json() as Promise<T>;
}

export function resolveAssetUrl(url?: string | null): string {
  if (!url) return "";
  if (/^(https?:|blob:|data:)/.test(url)) return url;
  return `${API_BASE_URL}${url.startsWith("/") ? url : `/${url}`}`;
}

export function getStyleImage(style?: NailStyle | null): string {
  return resolveAssetUrl(
    style?.enhanced_url || style?.image_url || style?.image_path || style?.original_url,
  );
}

export function styleSwatch(style?: NailStyle | null, index = 0): string {
  const text = `${style?.color || ""}${style?.style_tag || ""}${style?.tags?.join("") || ""}`;
  if (text.includes("奶茶") || text.includes("裸") || text.includes("豆沙")) return "#E8D5C4";
  if (text.includes("粉") || text.includes("樱") || text.includes("玫")) return "#F2C6D4";
  if (text.includes("红") || text.includes("酒")) return "#A85C5C";
  if (text.includes("绿")) return "#BFDCCB";
  if (text.includes("蓝") || text.includes("灰")) return "#B8C8D8";
  if (text.includes("黑") || text.includes("猫眼")) return "#2A2A2A";
  const fallback = ["#E8D5C4", "#D4C5E8", "#C8E6D4", "#F2D7D5", "#E7D8BE"];
  return fallback[index % fallback.length];
}

export async function fetchStyles(): Promise<NailStyle[]> {
  const data = await requestJson<{ items: NailStyle[] }>("/api/styles");
  return data.items;
}

export async function createTryOn(
  handImage: File,
  styleId: string,
  userId = "demo_user",
): Promise<TryOnResult> {
  const formData = new FormData();
  formData.append("hand_image", handImage);
  formData.append("style_id", styleId);
  formData.append("user_id", userId);
  return requestJson<TryOnResult>("/api/tryon", {
    method: "POST",
    body: formData,
  });
}

export async function createNailTryOn(
  targetHandImage: File,
  styleId: string,
  provider: ImageEditProvider = "qwen",
  modelName?: string,
): Promise<TryOnResult> {
  const formData = new FormData();
  formData.append("target_hand_image", targetHandImage);
  formData.append("style_id", styleId);
  formData.append("provider", provider);
  if (modelName) formData.append("model_name", modelName);

  const response = await requestJson<{
    success: boolean;
    message: string;
    data: {
      session_id?: string;
      result_image_url: string;
      target_mask_url?: string;
      style_mask_url?: string;
      style_reference_url?: string;
      provider?: ImageEditProvider;
      model_name?: string | null;
      segmentation_provider?: string;
      style_id?: string | null;
    };
  }>("/api/nail-tryon", {
    method: "POST",
    body: formData,
  });

  return {
    task_id: response.data.session_id || `nail_tryon_${Date.now()}`,
    status: response.success ? "success" : "failed",
    style_id: styleId,
    result_image_url: response.data.result_image_url,
    ai_reason: response.message,
    mock: response.data.segmentation_provider === "mock",
    provider: response.data.provider,
    model_name: response.data.model_name,
    target_mask_url: response.data.target_mask_url,
    style_mask_url: response.data.style_mask_url,
    style_reference_url: response.data.style_reference_url,
    segmentation_provider: response.data.segmentation_provider,
  };
}

export function fetchAdvice(styleId: string): Promise<AdviceResponse> {
  return requestJson<AdviceResponse>("/api/ai/advice", {
    method: "POST",
    body: JSON.stringify({ style_id: styleId }),
  });
}

export function recommendMerchants(
  styleId: string,
  preferences: string[],
): Promise<MerchantRecommendationResponse> {
  return requestJson<MerchantRecommendationResponse>("/api/recommend/merchants", {
    method: "POST",
    body: JSON.stringify({
      user_id: "demo_user",
      hand_id: null,
      style_id: styleId,
      preferences,
    }),
  });
}

export function createConfirmation(params: {
  styleId: string;
  merchantId: string;
  preferences: string[];
  tryonResultUrl?: string | null;
}): Promise<ConfirmationResponse> {
  return requestJson<ConfirmationResponse>("/api/confirmation", {
    method: "POST",
    body: JSON.stringify({
      user_id: "demo_user",
      hand_id: null,
      style_id: params.styleId,
      merchant_id: params.merchantId,
      preferences: params.preferences,
      tryon_result_url: params.tryonResultUrl || null,
    }),
  });
}

export async function recordEvent(styleId: string, eventType: EventType): Promise<void> {
  try {
    await requestJson<{ success: boolean; event_id: string }>("/api/events", {
      method: "POST",
      body: JSON.stringify({
        user_id: "demo_user",
        style_id: styleId,
        event_type: eventType,
      }),
    });
  } catch {
    // Analytics should never interrupt the demo flow.
  }
}

export function fetchPlatformDashboard(): Promise<PlatformDashboard> {
  return requestJson<PlatformDashboard>("/api/analytics/platform-dashboard");
}

export function generateReport(date: string): Promise<ReportResponse> {
  return requestJson<ReportResponse>("/api/ai/report", {
    method: "POST",
    body: JSON.stringify({ date }),
  });
}
