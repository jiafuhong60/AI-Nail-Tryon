import { useEffect, useState } from "react";
import { Download, RotateCcw, Sparkles } from "lucide-react";
import { AdviceResponse, NailStyle, Screen, TryOnResult } from "../App";
import { fetchAdvice, getStyleImage, recordEvent, resolveAssetUrl, styleSwatch } from "../api";
import {
  BottomBar,
  Card,
  ErrorBlock,
  GhostButton,
  PrimaryButton,
  ScreenHeader,
  StatusBar,
} from "./shared";

export function TryOnResultScreen({
  onNavigate,
  selectedStyle,
  handPreviewUrl,
  tryOnResult,
  advice,
  onAdviceLoaded,
}: {
  onNavigate: (s: Screen) => void;
  selectedStyle: NailStyle | null;
  handPreviewUrl: string | null;
  tryOnResult: TryOnResult | null;
  advice: AdviceResponse | null;
  onAdviceLoaded: (advice: AdviceResponse) => void;
}) {
  const [error, setError] = useState("");

  useEffect(() => {
    if (!selectedStyle || advice) return;
    let active = true;
    fetchAdvice(selectedStyle.style_id)
      .then((nextAdvice) => active && onAdviceLoaded(nextAdvice))
      .catch((err: Error) => active && setError(err.message));
    return () => {
      active = false;
    };
  }, [advice, onAdviceLoaded, selectedStyle]);

  const resultUrl = resolveAssetUrl(tryOnResult?.result_image_url);
  const originalUrl = handPreviewUrl || resolveAssetUrl(tryOnResult?.original_image_url);

  const handleDownload = () => {
    if (!resultUrl) return;
    const link = document.createElement("a");
    link.href = resultUrl;
    link.download = "ai-nail-tryon-result.png";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    if (selectedStyle) recordEvent(selectedStyle.style_id, "save_result");
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", background: "#FAF7F3" }}>
      <StatusBar />
      <ScreenHeader
        title="AI 试戴结果"
        subtitle={tryOnResult?.mock ? "当前为 mock 模式，演示链路稳定可用" : undefined}
        backLabel="上传"
        onBack={() => onNavigate("hand")}
      />

      <div style={{ flex: 1, overflowY: "auto", padding: "12px 24px 0", scrollbarWidth: "none" }}>
        <div
          style={{
            borderRadius: 28,
            overflow: "hidden",
            height: 300,
            position: "relative",
            marginBottom: 20,
            boxShadow: "0 8px 32px rgba(0,0,0,0.12)",
            background: selectedStyle ? styleSwatch(selectedStyle) : "#E8D5C4",
          }}
        >
          {resultUrl ? (
            <img
              src={resultUrl}
              alt="AI 试戴结果"
              style={{ width: "100%", height: "100%", objectFit: "cover" }}
            />
          ) : (
            <div
              style={{
                height: "100%",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                color: "#7A7470",
                fontSize: 14,
              }}
            >
              暂无试戴结果
            </div>
          )}

          <div
            style={{
              position: "absolute",
              top: 16,
              left: 16,
              background: "rgba(255,255,255,0.92)",
              borderRadius: 100,
              padding: "6px 14px",
              fontSize: 11,
              fontWeight: 700,
              color: "#9B6FA0",
              display: "flex",
              alignItems: "center",
              gap: 6,
            }}
          >
            <Sparkles size={13} />
            AI 生成
          </div>

          <button
            type="button"
            onClick={handleDownload}
            disabled={!resultUrl}
            title="下载试戴图"
            style={{
              position: "absolute",
              bottom: 16,
              right: 16,
              width: 44,
              height: 44,
              borderRadius: "50%",
              background: "rgba(255,255,255,0.95)",
              border: "none",
              boxShadow: "0 4px 16px rgba(0,0,0,0.15)",
              cursor: resultUrl ? "pointer" : "not-allowed",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              color: "#9B6FA0",
            }}
          >
            <Download size={20} />
          </button>
        </div>

        <div style={{ display: "flex", gap: 12, marginBottom: 16 }}>
          <ComparisonCard label="你的手图" img={originalUrl} />
          <ComparisonCard label="目标款式" img={getStyleImage(selectedStyle)} />
        </div>

        {tryOnResult?.provider && (
          <Card style={{ marginBottom: 16, borderRadius: 16, padding: "12px 14px" }}>
            <p style={{ margin: "0 0 6px", fontSize: 12, fontWeight: 700, color: "#1F1F1F" }}>
              模型调试信息
            </p>
            <p style={{ margin: 0, fontSize: 12, color: "#7A7470", lineHeight: 1.6 }}>
              Provider: {tryOnResult.provider}
              <br />
              Model: {tryOnResult.model_name || "default"}
              <br />
              Segmentation: {tryOnResult.segmentation_provider || "unknown"}
            </p>
          </Card>
        )}

        <Card
          style={{
            background: "linear-gradient(135deg, #FDF5FF 0%, #F5F0FF 100%)",
            borderRadius: 20,
          }}
        >
          <div style={{ display: "flex", alignItems: "flex-start", gap: 12 }}>
            <div
              style={{
                width: 36,
                height: 36,
                background: "linear-gradient(135deg, #D4A8D4 0%, #A89CC8 100%)",
                borderRadius: 10,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                color: "#fff",
                flexShrink: 0,
              }}
            >
              <Sparkles size={17} />
            </div>
            <div>
              <p style={{ margin: "0 0 6px", fontSize: 13, fontWeight: 700, color: "#1F1F1F" }}>
                AI 建议
              </p>
              <p style={{ margin: 0, fontSize: 13, color: "#7A7470", lineHeight: 1.6 }}>
                {advice?.advice || tryOnResult?.ai_reason || "正在生成适配建议..."}
              </p>
            </div>
          </div>
        </Card>

        {error && <ErrorBlock message={`AI 建议加载失败：${error}`} />}
      </div>

      <BottomBar>
        <GhostButton onClick={() => onNavigate("library")} style={{ flex: 1 }}>
          <span style={{ display: "inline-flex", alignItems: "center", gap: 8 }}>
            <RotateCcw size={16} />
            重选
          </span>
        </GhostButton>
        <PrimaryButton
          onClick={() => {
            if (selectedStyle) recordEvent(selectedStyle.style_id, "favorite");
            onNavigate("preference");
          }}
          disabled={!tryOnResult}
          style={{ flex: 1 }}
        >
          确认款式
        </PrimaryButton>
      </BottomBar>
    </div>
  );
}

function ComparisonCard({ label, img }: { label: string; img: string }) {
  return (
    <div
      style={{
        flex: 1,
        background: "#fff",
        borderRadius: 18,
        overflow: "hidden",
        boxShadow: "0 2px 12px rgba(0,0,0,0.06)",
      }}
    >
      <div style={{ height: 96, background: "#E8D5C4" }}>
        {img ? (
          <img
            src={img}
            alt={label}
            style={{ width: "100%", height: "100%", objectFit: "cover" }}
          />
        ) : null}
      </div>
      <div style={{ padding: "8px 12px" }}>
        <p style={{ margin: 0, fontSize: 11, fontWeight: 700, color: "#7A7470" }}>{label}</p>
      </div>
    </div>
  );
}
