import { useState } from "react";
import { CheckCircle2 } from "lucide-react";
import {
  ConfirmationResponse,
  MerchantRecommendationItem,
  NailStyle,
  Screen,
  TryOnResult,
} from "../App";
import {
  createConfirmation,
  getStyleImage,
  recordEvent,
  resolveAssetUrl,
  styleSwatch,
} from "../api";
import {
  BottomBar,
  Card,
  ErrorBlock,
  PrimaryButton,
  ScreenHeader,
  StatusBar,
  Tag,
} from "./shared";

export function ConfirmationScreen({
  onNavigate,
  selectedMerchant,
  selectedStyle,
  selectedPreferences,
  handPreviewUrl,
  tryOnResult,
  onConfirmationCreated,
}: {
  onNavigate: (s: Screen) => void;
  selectedMerchant: MerchantRecommendationItem | null;
  selectedStyle: NailStyle | null;
  selectedPreferences: string[];
  handPreviewUrl: string | null;
  tryOnResult: TryOnResult | null;
  onConfirmationCreated: (confirmation: ConfirmationResponse) => void;
}) {
  const [remark, setRemark] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const submit = async () => {
    if (!selectedStyle || !selectedMerchant) {
      setError("缺少款式或商家，请返回重新选择。");
      return;
    }
    setLoading(true);
    setError("");
    try {
      const confirmation = await createConfirmation({
        styleId: selectedStyle.style_id,
        merchantId: selectedMerchant.merchant_id,
        preferences: selectedPreferences,
        tryonResultUrl: tryOnResult?.result_image_url,
      });
      recordEvent(selectedStyle.style_id, "book");
      onConfirmationCreated(confirmation);
    } catch (err) {
      setError(err instanceof Error ? err.message : "确认单创建失败");
    } finally {
      setLoading(false);
    }
  };

  const resultUrl = resolveAssetUrl(tryOnResult?.result_image_url);

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", background: "#FAF7F3" }}>
      <StatusBar />
      <ScreenHeader
        title="服务确认单"
        subtitle="确认信息会写入后端 JSON 文件，不代表真实预约"
        backLabel="商家"
        onBack={() => onNavigate("merchant")}
      />

      <div style={{ flex: 1, overflowY: "auto", padding: "12px 24px 0", scrollbarWidth: "none" }}>
        <div style={{ display: "flex", gap: 10, marginBottom: 16 }}>
          <PhotoPreview label="你的手图" img={handPreviewUrl || ""} />
          <PhotoPreview label="目标款式" img={getStyleImage(selectedStyle)} swatch={styleSwatch(selectedStyle)} />
          <PhotoPreview label="AI 试戴" img={resultUrl} />
        </div>

        {selectedMerchant && (
          <Card style={{ marginBottom: 14, padding: "14px" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <div>
                <p style={{ margin: "0 0 2px", fontSize: 11, color: "#C9A9C9", fontWeight: 700 }}>
                  已选商家
                </p>
                <p style={{ margin: "0 0 4px", fontSize: 15, fontWeight: 700, color: "#1F1F1F" }}>
                  {selectedMerchant.merchant_name}
                </p>
                <div style={{ display: "flex", gap: 10, fontSize: 12, color: "#7A7470" }}>
                  <span>评分 {selectedMerchant.rating}</span>
                  <span>{selectedMerchant.distance} km</span>
                </div>
              </div>
              <div style={{ textAlign: "right" }}>
                <p style={{ margin: "0 0 2px", fontSize: 18, fontWeight: 800, color: "#1F1F1F" }}>
                  ¥{selectedMerchant.price_range}
                </p>
                <span
                  style={{
                    fontSize: 10,
                    color: "#9B6FA0",
                    background: "rgba(155,111,160,0.1)",
                    borderRadius: 100,
                    padding: "2px 8px",
                    fontWeight: 700,
                  }}
                >
                  {selectedMerchant.match_score}% 匹配
                </span>
              </div>
            </div>
          </Card>
        )}

        <Card style={{ marginBottom: 14, padding: "14px" }}>
          <p style={{ margin: "0 0 10px", fontSize: 12, fontWeight: 700, color: "#7A7470" }}>
            用户偏好
          </p>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            {selectedPreferences.map((preference, index) => (
              <Tag key={preference} active>
                {index + 1}. {preference}
              </Tag>
            ))}
          </div>
        </Card>

        <Card style={{ marginBottom: 14, padding: "16px" }}>
          <p style={{ margin: "0 0 12px", fontSize: 13, fontWeight: 700, color: "#1F1F1F" }}>
            确认事项
          </p>
          {[
            "服务前向用户展示相似作品",
            "确认颜色、图案和质感还原预期",
            "确认价格是否包含卸甲、延长和加固",
          ].map((item) => (
            <div key={item} style={{ display: "flex", gap: 10, marginBottom: 10 }}>
              <CheckCircle2 size={18} color="#9B6FA0" />
              <span style={{ fontSize: 13, color: "#1F1F1F", lineHeight: 1.5 }}>{item}</span>
            </div>
          ))}
        </Card>

        <Card style={{ marginBottom: 14, padding: "14px" }}>
          <p style={{ margin: "0 0 8px", fontSize: 13, fontWeight: 700, color: "#1F1F1F" }}>
            特殊要求
          </p>
          <textarea
            value={remark}
            onChange={(event) => setRemark(event.target.value)}
            placeholder="例如：希望甲型略短，不做太厚封层"
            style={{
              width: "100%",
              height: 72,
              border: "1.5px solid rgba(0,0,0,0.08)",
              borderRadius: 12,
              padding: "10px 12px",
              fontSize: 13,
              color: "#1F1F1F",
              background: "#FAF7F3",
              resize: "none",
              fontFamily: "inherit",
              outline: "none",
              boxSizing: "border-box",
            }}
          />
        </Card>

        {remark && (
          <p style={{ margin: "0 0 12px", fontSize: 11, color: "#9B8E89", lineHeight: 1.5 }}>
            备注当前仅在前端展示，后端 MVP 确认单接口暂不持久化备注字段。
          </p>
        )}

        {error && <ErrorBlock message={error} />}
      </div>

      <BottomBar>
        <PrimaryButton
          onClick={submit}
          disabled={loading || !selectedStyle || !selectedMerchant}
          style={{ flex: 1, padding: "16px" }}
        >
          {loading ? "提交中" : "创建确认单"}
        </PrimaryButton>
      </BottomBar>
    </div>
  );
}

function PhotoPreview({
  label,
  img,
  swatch = "#E8D5C4",
}: {
  label: string;
  img: string;
  swatch?: string;
}) {
  return (
    <div style={{ flex: 1 }}>
      <div
        style={{
          height: 80,
          borderRadius: 14,
          overflow: "hidden",
          background: swatch,
          marginBottom: 5,
        }}
      >
        {img ? (
          <img
            src={img}
            alt={label}
            style={{ width: "100%", height: "100%", objectFit: "cover" }}
          />
        ) : null}
      </div>
      <p style={{ margin: 0, fontSize: 10, color: "#7A7470", textAlign: "center", fontWeight: 700 }}>
        {label}
      </p>
    </div>
  );
}
