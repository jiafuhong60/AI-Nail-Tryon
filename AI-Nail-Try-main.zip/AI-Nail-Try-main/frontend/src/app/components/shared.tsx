import React from "react";
import { ArrowLeft, Loader2 } from "lucide-react";

export function PrimaryButton({
  children,
  onClick,
  style,
  disabled,
  type = "button",
}: {
  children: React.ReactNode;
  onClick?: () => void;
  style?: React.CSSProperties;
  disabled?: boolean;
  type?: "button" | "submit";
}) {
  return (
    <button
      type={type}
      disabled={disabled}
      onClick={(e) => {
        e.stopPropagation();
        onClick?.();
      }}
      style={{
        background: disabled
          ? "#D8D0CB"
          : "linear-gradient(135deg, #D4A8D4 0%, #A89CC8 100%)",
        color: "#fff",
        border: "none",
        borderRadius: 100,
        padding: "14px 28px",
        fontSize: 15,
        fontWeight: 600,
        cursor: disabled ? "not-allowed" : "pointer",
        letterSpacing: "0.01em",
        boxShadow: disabled ? "none" : "0 4px 20px rgba(168,156,200,0.38)",
        transition: "opacity 0.2s",
        fontFamily: "inherit",
        ...style,
      }}
    >
      {children}
    </button>
  );
}

export function GhostButton({
  children,
  onClick,
  style,
  disabled,
}: {
  children: React.ReactNode;
  onClick?: () => void;
  style?: React.CSSProperties;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={(e) => {
        e.stopPropagation();
        onClick?.();
      }}
      style={{
        background: "transparent",
        color: disabled ? "#B9B0AA" : "#7A7470",
        border: "1.5px solid rgba(0,0,0,0.12)",
        borderRadius: 100,
        padding: "14px 28px",
        fontSize: 15,
        fontWeight: 500,
        cursor: disabled ? "not-allowed" : "pointer",
        letterSpacing: "0.01em",
        transition: "background 0.2s",
        fontFamily: "inherit",
        ...style,
      }}
    >
      {children}
    </button>
  );
}

export function Tag({
  children,
  active,
  onClick,
}: {
  children: React.ReactNode;
  active?: boolean;
  onClick?: () => void;
}) {
  return (
    <span
      onClick={(e) => {
        if (onClick) {
          e.stopPropagation();
          onClick();
        }
      }}
      style={{
        display: "inline-flex",
        alignItems: "center",
        background: active
          ? "linear-gradient(135deg, #D4A8D4 0%, #A89CC8 100%)"
          : "rgba(0,0,0,0.05)",
        color: active ? "#fff" : "#7A7470",
        borderRadius: 100,
        padding: "5px 14px",
        fontSize: 12,
        fontWeight: 500,
        cursor: onClick ? "pointer" : "default",
        whiteSpace: "nowrap",
        letterSpacing: "0.02em",
      }}
    >
      {children}
    </span>
  );
}

export function StatusBar() {
  return <div style={{ height: 64, flexShrink: 0 }} />;
}

export function ScreenHeader({
  title,
  subtitle,
  backLabel,
  onBack,
}: {
  title: string;
  subtitle?: string;
  backLabel?: string;
  onBack?: () => void;
}) {
  return (
    <div style={{ padding: "0 24px 8px", flexShrink: 0 }}>
      {onBack && (
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onBack();
          }}
          style={{
            background: "none",
            border: "none",
            color: "#7A7470",
            fontSize: 14,
            cursor: "pointer",
            padding: "0 0 8px",
            display: "flex",
            alignItems: "center",
            gap: 5,
            fontFamily: "inherit",
          }}
        >
          <ArrowLeft size={16} />
          {backLabel || "返回"}
        </button>
      )}
      <h1
        style={{
          margin: 0,
          fontSize: 26,
          fontWeight: 600,
          color: "#1F1F1F",
          lineHeight: 1.25,
          letterSpacing: 0,
          fontFamily: "'Playfair Display', serif",
        }}
      >
        {title}
      </h1>
      {subtitle && (
        <p
          style={{
            margin: "6px 0 0",
            fontSize: 14,
            color: "#7A7470",
            lineHeight: 1.5,
          }}
        >
          {subtitle}
        </p>
      )}
    </div>
  );
}

export function BottomBar({ children }: { children: React.ReactNode }) {
  return (
    <div
      style={{
        position: "sticky",
        bottom: 0,
        left: 0,
        right: 0,
        background: "linear-gradient(to top, #FAF7F3 80%, rgba(250,247,243,0))",
        padding: "16px 24px 32px",
        display: "flex",
        gap: 12,
        zIndex: 50,
        flexShrink: 0,
      }}
    >
      {children}
    </div>
  );
}

export function Card({
  children,
  style,
}: {
  children: React.ReactNode;
  style?: React.CSSProperties;
}) {
  return (
    <div
      style={{
        background: "#FFFFFF",
        borderRadius: 20,
        padding: "16px",
        boxShadow: "0 2px 16px rgba(0,0,0,0.06)",
        ...style,
      }}
    >
      {children}
    </div>
  );
}

export function ScoreBar({
  label,
  value,
  max = 100,
}: {
  label: string;
  value: number;
  max?: number;
}) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
      <span style={{ fontSize: 11, color: "#7A7470", width: 72, flexShrink: 0 }}>
        {label}
      </span>
      <div
        style={{
          flex: 1,
          height: 5,
          background: "#F0EBE6",
          borderRadius: 4,
          overflow: "hidden",
        }}
      >
        <div
          style={{
            width: `${Math.min((value / max) * 100, 100)}%`,
            height: "100%",
            background: "linear-gradient(90deg, #D4A8D4 0%, #A89CC8 100%)",
            borderRadius: 4,
          }}
        />
      </div>
      <span style={{ fontSize: 11, color: "#1F1F1F", fontWeight: 600, width: 32 }}>
        {value}
      </span>
    </div>
  );
}

export function LoadingBlock({ label = "加载中" }: { label?: string }) {
  return (
    <div
      style={{
        padding: 32,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        gap: 8,
        color: "#7A7470",
        fontSize: 13,
      }}
    >
      <Loader2 size={16} style={{ animation: "spin 1s linear infinite" }} />
      {label}
    </div>
  );
}

export function ErrorBlock({ message }: { message: string }) {
  return (
    <div
      style={{
        margin: "16px 24px",
        padding: "14px 16px",
        borderRadius: 14,
        background: "#FFF5F5",
        border: "1px solid #FFD6D6",
        color: "#A85C5C",
        fontSize: 13,
        lineHeight: 1.5,
      }}
    >
      {message}
    </div>
  );
}
