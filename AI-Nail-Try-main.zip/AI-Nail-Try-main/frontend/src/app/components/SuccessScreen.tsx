import { CheckCircle2, Home, RotateCcw } from "lucide-react";
import { ConfirmationResponse, MerchantRecommendationItem, Screen } from "../App";
import { GhostButton, PrimaryButton, StatusBar } from "./shared";

export function SuccessScreen({
  onNavigate,
  confirmation,
  selectedMerchant,
}: {
  onNavigate: (s: Screen) => void;
  confirmation: ConfirmationResponse | null;
  selectedMerchant: MerchantRecommendationItem | null;
}) {
  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        minHeight: "100%",
        background: "linear-gradient(135deg, #FAF7F3 0%, #F5F0F3 50%, #F0EBF0 100%)",
      }}
    >
      <StatusBar />
      <div style={{ padding: "32px 28px 0", width: "100%", boxSizing: "border-box", flex: 1 }}>
        <div style={{ textAlign: "center", marginBottom: 32 }}>
          <div
            style={{
              width: 96,
              height: 96,
              borderRadius: "50%",
              margin: "0 auto 22px",
              background: "linear-gradient(135deg, #D4A8D4 0%, #A89CC8 100%)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              color: "#fff",
              boxShadow: "0 12px 32px rgba(168,156,200,0.38)",
            }}
          >
            <CheckCircle2 size={46} />
          </div>
          <h1
            style={{
              margin: "0 0 10px",
              fontSize: 30,
              fontWeight: 600,
              color: "#1F1F1F",
              fontFamily: "'Playfair Display', serif",
            }}
          >
            确认单已生成
          </h1>
          <p style={{ margin: 0, fontSize: 14, color: "#7A7470", lineHeight: 1.6 }}>
            后端已返回稳定 JSON，可用于演示完整服务链路。
          </p>
        </div>

        <div
          style={{
            background: "#fff",
            borderRadius: 22,
            padding: "20px 22px",
            boxShadow: "0 2px 16px rgba(0,0,0,0.06)",
            marginBottom: 20,
          }}
        >
          <InfoRow label="确认单号" value={confirmation?.confirmation_id || "未生成"} />
          <InfoRow label="款式" value={confirmation?.style_name || "-"} />
          <InfoRow label="商家" value={confirmation?.merchant_name || selectedMerchant?.merchant_name || "-"} />
          <InfoRow label="参考价格" value={confirmation ? `¥${confirmation.expected_price}` : "-"} />
        </div>

        {confirmation?.merchant_suggestion && (
          <div
            style={{
              background: "#FDF5FF",
              borderRadius: 18,
              padding: "16px 18px",
              color: "#7A7470",
              fontSize: 13,
              lineHeight: 1.6,
              marginBottom: 20,
            }}
          >
            <strong style={{ color: "#9B6FA0" }}>给商家的建议：</strong>
            {confirmation.merchant_suggestion}
          </div>
        )}
      </div>

      <div style={{ padding: "0 24px 32px", display: "flex", gap: 12 }}>
        <GhostButton onClick={() => onNavigate("library")} style={{ flex: 1 }}>
          <span style={{ display: "inline-flex", alignItems: "center", gap: 8 }}>
            <RotateCcw size={16} />
            再试一次
          </span>
        </GhostButton>
        <PrimaryButton onClick={() => onNavigate("home")} style={{ flex: 1 }}>
          <span style={{ display: "inline-flex", alignItems: "center", gap: 8 }}>
            <Home size={16} />
            首页
          </span>
        </PrimaryButton>
      </div>
    </div>
  );
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div
      style={{
        display: "flex",
        justifyContent: "space-between",
        gap: 16,
        padding: "10px 0",
        borderBottom: label === "参考价格" ? "none" : "1px solid #F0EBE6",
        fontSize: 13,
      }}
    >
      <span style={{ color: "#7A7470" }}>{label}</span>
      <span style={{ color: "#1F1F1F", fontWeight: 700, textAlign: "right" }}>{value}</span>
    </div>
  );
}
