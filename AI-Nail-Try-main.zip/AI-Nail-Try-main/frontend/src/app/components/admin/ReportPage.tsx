import { useState } from "react";
import { FileText, Loader2 } from "lucide-react";
import type { PlatformDashboard, ReportResponse } from "../../api";
import { generateReport } from "../../api";
import { PageHeader } from "./AdminLayout";

export function ReportPage({ dashboard }: { dashboard: PlatformDashboard | null }) {
  const [isGenerating, setIsGenerating] = useState(false);
  const [report, setReport] = useState<ReportResponse | null>(null);
  const [error, setError] = useState("");

  const handleGenerate = async () => {
    setIsGenerating(true);
    setError("");
    try {
      const today = new Date().toISOString().slice(0, 10);
      const data = await generateReport(today);
      setReport(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "AI 日报生成失败");
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div>
      <PageHeader title="AI 运营日报" subtitle="调用后端 /api/ai/report 生成稳定 mock 文案" />

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(4, 1fr)",
          gap: 16,
          marginBottom: 32,
        }}
      >
        <QuickStat label="分析款式" value={(dashboard?.style_heat_ranking.length || 0).toString()} />
        <QuickStat label="偏好维度" value={(dashboard?.preference_trends.length || 0).toString()} />
        <QuickStat label="供需提醒" value={(dashboard?.supply_demand_alerts.length || 0).toString()} />
        <QuickStat label="Mock" value={dashboard?.mock ? "开启" : "未知"} />
      </div>

      <div
        style={{
          background: "#FFFFFF",
          borderRadius: 24,
          padding: "36px 40px",
          border: "1px solid #E8E3DF",
          boxShadow: "0 4px 24px rgba(0,0,0,0.04)",
        }}
      >
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            marginBottom: 32,
            paddingBottom: 24,
            borderBottom: "1px solid #E8E3DF",
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
            <div
              style={{
                width: 56,
                height: 56,
                borderRadius: 16,
                background: "linear-gradient(135deg, #E8D5E8 0%, #D4C5D4 100%)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                color: "#7A5F7C",
              }}
            >
              <FileText size={26} />
            </div>
            <div>
              <h2 style={{ margin: "0 0 4px", fontSize: 22, fontWeight: 700, color: "#1F1F1F" }}>
                AI 运营日报
              </h2>
              <p style={{ margin: 0, fontSize: 13, color: "#9B8E89" }}>
                {new Date().toLocaleDateString("zh-CN")}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={handleGenerate}
            disabled={isGenerating}
            style={{
              padding: "14px 28px",
              borderRadius: 12,
              background: isGenerating
                ? "#E8E3DF"
                : "linear-gradient(135deg, #C9A9C9 0%, #D4C5D4 100%)",
              border: "none",
              fontSize: 14,
              fontWeight: 700,
              color: isGenerating ? "#9B8E89" : "#FFFFFF",
              cursor: isGenerating ? "not-allowed" : "pointer",
              display: "inline-flex",
              alignItems: "center",
              gap: 8,
            }}
          >
            {isGenerating && <Loader2 size={16} />}
            {isGenerating ? "生成中" : "生成 AI 日报"}
          </button>
        </div>

        {error && (
          <div style={{ color: "#A85C5C", background: "#FFF5F5", borderRadius: 12, padding: 16, marginBottom: 20 }}>
            {error}
          </div>
        )}

        {report ? (
          <div style={{ display: "flex", flexDirection: "column", gap: 18 }}>
            <ReportSection title="今日总结" content={report.summary} />
            <ReportSection title="热门趋势" content={report.hot_trend} />
            <ReportSection title="风险提示" content={report.risk} />
            <ReportSection title="运营建议" content={report.suggestion} />
          </div>
        ) : (
          <div style={{ padding: "60px 40px", textAlign: "center" }}>
            <FileText size={48} color="#C9A9C9" />
            <h3 style={{ margin: "18px 0 12px", fontSize: 18, fontWeight: 700, color: "#1F1F1F" }}>
              点击上方按钮生成 AI 日报
            </h3>
            <p style={{ margin: 0, fontSize: 14, color: "#9B8E89", lineHeight: 1.6 }}>
              后端会基于当前 dashboard 数据生成 summary、hot_trend、risk 和 suggestion。
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

function QuickStat({ label, value }: { label: string; value: string }) {
  return (
    <div style={{ background: "#FFFFFF", borderRadius: 16, padding: "16px 20px", border: "1px solid #E8E3DF" }}>
      <div style={{ fontSize: 11, color: "#9B8E89", marginBottom: 4 }}>{label}</div>
      <div style={{ fontSize: 16, fontWeight: 700, color: "#1F1F1F" }}>{value}</div>
    </div>
  );
}

function ReportSection({ title, content }: { title: string; content: string }) {
  return (
    <section
      style={{
        padding: "18px 22px",
        borderRadius: 16,
        background: "linear-gradient(135deg, #FAF7F3 0%, #F5F0EC 100%)",
        border: "1px solid #E8E3DF",
      }}
    >
      <h3 style={{ margin: "0 0 10px", fontSize: 16, fontWeight: 700, color: "#1F1F1F" }}>{title}</h3>
      <p style={{ margin: 0, fontSize: 14, color: "#5A4F4B", lineHeight: 1.8 }}>{content}</p>
    </section>
  );
}
