import {
  PolarAngleAxis,
  PolarGrid,
  PolarRadiusAxis,
  Radar,
  RadarChart,
  ResponsiveContainer,
} from "recharts";
import type { MerchantCapabilityItem, PlatformDashboard } from "../../api";
import { AdminNotice, PageHeader } from "./AdminLayout";

export function MerchantsPage({
  dashboard,
  loading,
  error,
}: {
  dashboard: PlatformDashboard | null;
  loading: boolean;
  error: string;
}) {
  const merchants = dashboard?.merchant_capabilities || [];

  return (
    <div>
      <PageHeader title="商家能力画像" subtitle="基于后端 mock 商家能力数据进行展示" />
      <AdminNotice loading={loading} error={error} />

      <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
        {merchants.map((merchant) => (
          <MerchantPanel key={merchant.merchant_id} merchant={merchant} />
        ))}
      </div>
    </div>
  );
}

function MerchantPanel({ merchant }: { merchant: MerchantCapabilityItem }) {
  const abilities = [
    { skill: "还原度", value: merchant.restore_score },
    { skill: "创意", value: merchant.creative_score },
    { skill: "速度", value: merchant.speed_score },
    { skill: "性价比", value: merchant.cost_score },
    { skill: "环境", value: merchant.environment_score },
    { skill: "相似作品", value: Math.min(merchant.similar_work_count * 3, 100) },
  ];

  return (
    <div
      style={{
        background: "#FFFFFF",
        borderRadius: 20,
        padding: "28px 32px",
        border: "1px solid #E8E3DF",
        boxShadow: "0 2px 12px rgba(0,0,0,0.03)",
      }}
    >
      <div style={{ display: "flex", gap: 32 }}>
        <div style={{ flex: 1 }}>
          <div style={{ marginBottom: 20 }}>
            <h3 style={{ margin: "0 0 8px", fontSize: 18, fontWeight: 700, color: "#1F1F1F" }}>
              {merchant.merchant_name}
            </h3>
            <p style={{ margin: 0, fontSize: 13, color: "#7A7470" }}>
              {merchant.similar_work_count} 个相似作品案例
            </p>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "12px 20px" }}>
            {abilities.map((ability) => (
              <div key={ability.skill}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6, fontSize: 12 }}>
                  <span style={{ color: "#7A7470" }}>{ability.skill}</span>
                  <span style={{ fontWeight: 800, color: ability.value >= 90 ? "#7B9F7B" : "#C9A9C9" }}>
                    {ability.value}
                  </span>
                </div>
                <div style={{ height: 6, borderRadius: 3, background: "#F0EBE6", overflow: "hidden" }}>
                  <div
                    style={{
                      height: "100%",
                      width: `${ability.value}%`,
                      background:
                        ability.value >= 90
                          ? "linear-gradient(90deg, #7B9F7B 0%, #9BC59B 100%)"
                          : "linear-gradient(90deg, #C9A9C9 0%, #D4C5D4 100%)",
                      borderRadius: 3,
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        <div style={{ width: 280, flexShrink: 0 }}>
          <ResponsiveContainer width="100%" height={260}>
            <RadarChart data={abilities}>
              <PolarGrid stroke="#E8E3DF" />
              <PolarAngleAxis dataKey="skill" tick={{ fontSize: 11, fill: "#7A7470" }} />
              <PolarRadiusAxis angle={90} domain={[0, 100]} tick={false} />
              <Radar
                name="能力分"
                dataKey="value"
                stroke="#C9A9C9"
                fill="#C9A9C9"
                fillOpacity={0.3}
                strokeWidth={2}
              />
            </RadarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
