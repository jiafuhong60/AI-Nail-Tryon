import { ReactNode } from "react";

export type AdminPage =
  | "overview"
  | "styles"
  | "preferences"
  | "merchants"
  | "alerts"
  | "report";

interface AdminLayoutProps {
  children: ReactNode;
  currentPage: AdminPage;
  onNavigate: (page: AdminPage) => void;
}

const NAV_ITEMS: { id: AdminPage; label: string }[] = [
  { id: "overview", label: "运营总览" },
  { id: "styles", label: "款式热度" },
  { id: "preferences", label: "用户偏好" },
  { id: "merchants", label: "商家能力" },
  { id: "alerts", label: "供需提醒" },
  { id: "report", label: "AI 日报" },
];

export function AdminLayout({
  children,
  currentPage,
  onNavigate,
}: AdminLayoutProps) {
  return (
    <div style={{ display: "flex", height: "100%", background: "#F8F6F4" }}>
      <aside
        style={{
          width: 240,
          background: "#FFFFFF",
          borderRight: "1px solid #E8E3DF",
          display: "flex",
          flexDirection: "column",
          flexShrink: 0,
        }}
      >
        <div style={{ padding: "32px 24px", borderBottom: "1px solid #E8E3DF" }}>
          <h2
            style={{
              margin: 0,
              fontSize: 18,
              fontWeight: 600,
              color: "#1F1F1F",
              fontFamily: "'Playfair Display', serif",
            }}
          >
            美甲运营平台
          </h2>
          <p style={{ margin: "4px 0 0", fontSize: 11, color: "#9B8E89" }}>
            ADMIN DASHBOARD
          </p>
        </div>

        <nav style={{ flex: 1, padding: "24px 12px" }}>
          {NAV_ITEMS.map((item) => {
            const isActive = currentPage === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onNavigate(item.id)}
                style={{
                  width: "100%",
                  padding: "12px 16px",
                  margin: "0 0 4px",
                  background: isActive
                    ? "linear-gradient(135deg, #E8D5E8 0%, #D4C5D4 100%)"
                    : "transparent",
                  border: "none",
                  borderRadius: 12,
                  fontSize: 14,
                  fontWeight: isActive ? 700 : 500,
                  color: isActive ? "#5A3F5C" : "#7A7470",
                  textAlign: "left",
                  cursor: "pointer",
                  fontFamily: "inherit",
                }}
              >
                {item.label}
              </button>
            );
          })}
        </nav>

        <div style={{ padding: "20px 24px", borderTop: "1px solid #E8E3DF", fontSize: 12, color: "#9B8E89" }}>
          2026 AI Nail MVP
        </div>
      </aside>

      <main style={{ flex: 1, overflowY: "auto", padding: "32px 40px" }}>{children}</main>
    </div>
  );
}

export function PageHeader({
  title,
  subtitle,
}: {
  title: string;
  subtitle?: string;
}) {
  return (
    <div style={{ marginBottom: 32 }}>
      <h1 style={{ margin: 0, fontSize: 28, fontWeight: 700, color: "#1F1F1F" }}>{title}</h1>
      {subtitle && (
        <p style={{ margin: "8px 0 0", fontSize: 14, color: "#7A7470", lineHeight: 1.5 }}>
          {subtitle}
        </p>
      )}
    </div>
  );
}

export function StatCard({
  label,
  value,
  helper,
}: {
  label: string;
  value: string;
  helper?: string;
}) {
  return (
    <div
      style={{
        background: "#FFFFFF",
        borderRadius: 20,
        padding: "24px 28px",
        border: "1px solid #E8E3DF",
        boxShadow: "0 2px 12px rgba(0,0,0,0.03)",
      }}
    >
      <p style={{ margin: "0 0 8px", fontSize: 13, color: "#9B8E89", fontWeight: 600 }}>
        {label}
      </p>
      <p style={{ margin: "0 0 8px", fontSize: 32, fontWeight: 700, color: "#1F1F1F" }}>
        {value}
      </p>
      {helper && <span style={{ fontSize: 12, color: "#9B8E89" }}>{helper}</span>}
    </div>
  );
}

export function AdminNotice({
  loading,
  error,
}: {
  loading: boolean;
  error: string;
}) {
  if (loading) return <div style={noticeStyle}>正在加载运营数据...</div>;
  if (error) return <div style={{ ...noticeStyle, color: "#A85C5C" }}>数据加载失败：{error}</div>;
  return null;
}

const noticeStyle = {
  background: "#FFFFFF",
  border: "1px solid #E8E3DF",
  borderRadius: 16,
  padding: 20,
  color: "#7A7470",
  marginBottom: 24,
};
