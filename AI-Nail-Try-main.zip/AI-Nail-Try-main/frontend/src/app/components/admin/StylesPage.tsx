import { resolveAssetUrl, type PlatformDashboard, type StyleHeatItem } from "../../api";
import { AdminNotice, PageHeader } from "./AdminLayout";

export function StylesPage({
  dashboard,
  loading,
  error,
}: {
  dashboard: PlatformDashboard | null;
  loading: boolean;
  error: string;
}) {
  const styles = dashboard?.style_heat_ranking || [];

  return (
    <div>
      <PageHeader title="款式热度" subtitle="根据曝光、试戴、收藏和预约计算热度排名" />
      <AdminNotice loading={loading} error={error} />

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(3, 1fr)",
          gap: 20,
          marginBottom: 32,
        }}
      >
        {styles.slice(0, 3).map((style, index) => (
          <TopStyleCard key={style.style_id} style={style} rank={index + 1} />
        ))}
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
        {styles.slice(3).map((style, index) => (
          <RankingRow key={style.style_id} style={style} rank={index + 4} />
        ))}
      </div>
    </div>
  );
}

function TopStyleCard({ style, rank }: { style: StyleHeatItem; rank: number }) {
  const imageUrl = resolveAssetUrl(style.image_url);

  return (
    <div
      style={{
        background: "#FFFFFF",
        borderRadius: 20,
        overflow: "hidden",
        border: "2px solid #E8E3DF",
        boxShadow: "0 4px 20px rgba(0,0,0,0.06)",
      }}
    >
      <div
        style={{
          height: 120,
          background: imageUrl
            ? `linear-gradient(rgba(0,0,0,0.18), rgba(0,0,0,0.18)), url(${imageUrl}) center/cover`
            : rank === 1
              ? "linear-gradient(135deg, #F6D7B0 0%, #D4A8D4 100%)"
              : rank === 2
                ? "linear-gradient(135deg, #D8DEE9 0%, #D4C5D4 100%)"
                : "linear-gradient(135deg, #E8D5C4 0%, #C9A9C9 100%)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          color: "#fff",
          fontSize: 34,
          fontWeight: 800,
        }}
      >
        #{rank}
      </div>
      <div style={{ padding: "20px 20px 24px" }}>
        <h3 style={{ margin: "0 0 4px", fontSize: 18, fontWeight: 700, color: "#1F1F1F" }}>
          {style.style_name}
        </h3>
        <Metric label="热度分" value={style.heat_score.toString()} strong />
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "8px 12px", fontSize: 12 }}>
          <Metric label="曝光" value={style.exposure.toLocaleString()} />
          <Metric label="试戴" value={style.tryon_count.toLocaleString()} />
          <Metric label="收藏" value={style.favorite_count.toLocaleString()} />
          <Metric label="预约" value={style.appointment_count.toLocaleString()} />
        </div>
        <Metric label="转化率" value={`${(style.conversion_rate * 100).toFixed(1)}%`} />
      </div>
    </div>
  );
}

function RankingRow({ style, rank }: { style: StyleHeatItem; rank: number }) {
  return (
    <div
      style={{
        background: "#FFFFFF",
        borderRadius: 16,
        padding: "20px 24px",
        border: "1px solid #E8E3DF",
        boxShadow: "0 2px 12px rgba(0,0,0,0.03)",
        display: "flex",
        alignItems: "center",
        gap: 20,
      }}
    >
      <div
        style={{
          width: 32,
          height: 32,
          borderRadius: 10,
          background: "#F5F0EC",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontSize: 14,
          fontWeight: 800,
          color: "#7A7470",
          flexShrink: 0,
        }}
      >
        {rank}
      </div>
      <div style={{ flex: 1 }}>
        <h4 style={{ margin: "0 0 2px", fontSize: 15, fontWeight: 700, color: "#1F1F1F" }}>
          {style.style_name}
        </h4>
        <p style={{ margin: 0, fontSize: 12, color: "#9B8E89" }}>{style.style_id}</p>
      </div>
      <Metric label="曝光" value={style.exposure.toLocaleString()} />
      <Metric label="试戴" value={style.tryon_count.toLocaleString()} />
      <Metric label="热度" value={style.heat_score.toString()} strong />
      <Metric label="转化" value={`${(style.conversion_rate * 100).toFixed(1)}%`} />
    </div>
  );
}

function Metric({ label, value, strong }: { label: string; value: string; strong?: boolean }) {
  return (
    <div style={{ marginBottom: 10 }}>
      <div style={{ color: "#9B8E89", fontSize: 11, marginBottom: 2 }}>{label}</div>
      <div style={{ color: strong ? "#D4696B" : "#1F1F1F", fontWeight: 700, fontSize: strong ? 18 : 13 }}>
        {value}
      </div>
    </div>
  );
}
