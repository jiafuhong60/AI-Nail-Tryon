import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import type { PlatformDashboard } from "../../api";
import { AdminNotice, PageHeader } from "./AdminLayout";

const COLORS = ["#C9A9C9", "#D4C5D4", "#E8D5E8", "#B8A8B8", "#CFC0CF", "#DDD0DD"];

export function PreferencesPage({
  dashboard,
  loading,
  error,
}: {
  dashboard: PlatformDashboard | null;
  loading: boolean;
  error: string;
}) {
  const data = (dashboard?.preference_trends || []).map((item, index) => ({
    name: item.preference,
    value: Number((item.ratio * 100).toFixed(1)),
    count: item.count,
    color: COLORS[index % COLORS.length],
  }));

  return (
    <div>
      <PageHeader title="用户偏好趋势" subtitle="来自商家推荐请求中记录的偏好选择" />
      <AdminNotice loading={loading} error={error} />

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1.2fr", gap: 28 }}>
        <div
          style={{
            background: "#FFFFFF",
            borderRadius: 20,
            padding: "28px 32px",
            border: "1px solid #E8E3DF",
            boxShadow: "0 2px 12px rgba(0,0,0,0.03)",
          }}
        >
          <h3 style={{ margin: "0 0 8px", fontSize: 16, fontWeight: 700, color: "#1F1F1F" }}>
            偏好分布
          </h3>
          <p style={{ margin: "0 0 24px", fontSize: 13, color: "#9B8E89" }}>
            ratio 字段已转换为百分比
          </p>

          <ResponsiveContainer width="100%" height={360}>
            <BarChart data={data} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke="#E8E3DF" />
              <XAxis type="number" tick={{ fontSize: 12, fill: "#9B8E89" }} stroke="#E8E3DF" />
              <YAxis
                type="category"
                dataKey="name"
                tick={{ fontSize: 13, fill: "#1F1F1F" }}
                stroke="#E8E3DF"
                width={90}
              />
              <Tooltip formatter={(value: number) => `${value}%`} />
              <Bar dataKey="value" radius={[0, 8, 8, 0]}>
                {data.map((entry, index) => (
                  <Cell key={`${entry.name}-${index}`} fill={entry.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          {data.map((item, index) => (
            <div
              key={item.name}
              style={{
                background: "#FFFFFF",
                borderRadius: 16,
                padding: "20px 24px",
                border: "1px solid #E8E3DF",
                boxShadow: "0 2px 12px rgba(0,0,0,0.03)",
                display: "flex",
                alignItems: "center",
                gap: 16,
              }}
            >
              <div
                style={{
                  width: 40,
                  height: 40,
                  borderRadius: 12,
                  background: item.color,
                  color: "#fff",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontWeight: 800,
                }}
              >
                {index + 1}
              </div>
              <div style={{ flex: 1 }}>
                <h4 style={{ margin: "0 0 4px", fontSize: 15, fontWeight: 700, color: "#1F1F1F" }}>
                  {item.name}
                </h4>
                <p style={{ margin: 0, fontSize: 13, color: "#7A7470" }}>
                  {item.count} 次选择，占比 {item.value}%
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
