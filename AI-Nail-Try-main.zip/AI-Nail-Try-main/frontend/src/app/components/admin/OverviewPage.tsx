import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import type { PlatformDashboard } from "../../api";
import { AdminNotice, PageHeader, StatCard } from "./AdminLayout";

export function OverviewPage({
  dashboard,
  loading,
  error,
}: {
  dashboard: PlatformDashboard | null;
  loading: boolean;
  error: string;
}) {
  const styles = dashboard?.style_heat_ranking || [];
  const overview = dashboard?.overview;
  const totalExposure = overview?.total_exposure ?? styles.reduce((sum, item) => sum + item.exposure, 0);
  const totalTryons = overview?.total_tryon_count ?? styles.reduce((sum, item) => sum + item.tryon_count, 0);
  const totalFavorites = overview?.total_favorite_count ?? styles.reduce((sum, item) => sum + item.favorite_count, 0);
  const totalAppointments =
    overview?.total_appointment_count ?? styles.reduce((sum, item) => sum + item.appointment_count, 0);
  const conversion = overview
    ? (overview.overall_conversion_rate * 100).toFixed(1)
    : totalTryons
      ? ((totalAppointments / totalTryons) * 100).toFixed(1)
      : "0.0";

  const chartData = styles.slice(0, 8).map((item) => ({
    name: item.style_name,
    tryon: item.tryon_count,
    favorite: item.favorite_count,
    appointment: item.appointment_count,
  }));

  return (
    <div>
      <PageHeader title="运营总览" subtitle="来自 FastAPI 平台运营看板接口的实时 mock 数据" />
      <AdminNotice loading={loading} error={error} />

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
          gap: 16,
          marginBottom: 32,
        }}
      >
        <StatCard label="总曝光" value={totalExposure.toLocaleString()} helper="style_heat_ranking.exposure" />
        <StatCard label="AI 试戴" value={totalTryons.toLocaleString()} helper="tryon_count" />
        <StatCard label="收藏" value={totalFavorites.toLocaleString()} helper="favorite_count" />
        <StatCard label="预约点击" value={totalAppointments.toLocaleString()} helper="appointment_count" />
        <StatCard label="转化率" value={`${conversion}%`} helper="预约点击 / 试戴" />
      </div>

      <div
        style={{
          background: "#FFFFFF",
          borderRadius: 20,
          padding: "28px 32px",
          border: "1px solid #E8E3DF",
          boxShadow: "0 2px 12px rgba(0,0,0,0.03)",
          marginBottom: 32,
        }}
      >
        <h3 style={{ margin: "0 0 20px", fontSize: 16, fontWeight: 700, color: "#1F1F1F" }}>
          款式转化表现
        </h3>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#E8E3DF" />
            <XAxis dataKey="name" tick={{ fontSize: 11, fill: "#9B8E89" }} stroke="#E8E3DF" />
            <YAxis tick={{ fontSize: 12, fill: "#9B8E89" }} stroke="#E8E3DF" />
            <Tooltip />
            <Bar dataKey="tryon" name="试戴" fill="#C9A9C9" radius={[8, 8, 0, 0]} />
            <Bar dataKey="favorite" name="收藏" fill="#D4C5D4" radius={[8, 8, 0, 0]} />
            <Bar dataKey="appointment" name="预约" fill="#A89CC8" radius={[8, 8, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div
        style={{
          background: "linear-gradient(135deg, #FAF7F3 0%, #F5F0EC 100%)",
          borderRadius: 20,
          padding: "28px 32px",
          border: "1px solid #E8E3DF",
        }}
      >
        <h3 style={{ margin: "0 0 12px", fontSize: 16, fontWeight: 700, color: "#1F1F1F" }}>
          AI 运营建议
        </h3>
        <p style={{ margin: 0, fontSize: 14, color: "#5A4F4B", lineHeight: 1.7 }}>
          {dashboard?.ai_suggestion || "暂无建议"}
        </p>
      </div>
    </div>
  );
}
