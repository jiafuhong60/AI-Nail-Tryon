import { useEffect, useState } from "react";
import { fetchPlatformDashboard, PlatformDashboard } from "../../api";
import { AdminLayout, AdminPage } from "./AdminLayout";
import { OverviewPage } from "./OverviewPage";
import { StylesPage } from "./StylesPage";
import { PreferencesPage } from "./PreferencesPage";
import { MerchantsPage } from "./MerchantsPage";
import { AlertsPage } from "./AlertsPage";
import { ReportPage } from "./ReportPage";

interface AdminDashboardProps {
  onExitAdmin: () => void;
}

export function AdminDashboard({ onExitAdmin }: AdminDashboardProps) {
  const [currentPage, setCurrentPage] = useState<AdminPage>("overview");
  const [dashboard, setDashboard] = useState<PlatformDashboard | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let active = true;
    setLoading(true);
    fetchPlatformDashboard()
      .then((data) => active && setDashboard(data))
      .catch((err: Error) => active && setError(err.message))
      .finally(() => active && setLoading(false));
    return () => {
      active = false;
    };
  }, []);

  return (
    <div
      style={{
        width: "100vw",
        height: "100vh",
        background: "#F8F6F4",
        position: "relative",
        overflow: "hidden",
        fontFamily: "'DM Sans', sans-serif",
      }}
    >
      <button
        onClick={onExitAdmin}
        style={{
          position: "absolute",
          top: 20,
          right: 20,
          padding: "10px 20px",
          borderRadius: 10,
          background: "#FFFFFF",
          border: "1px solid #E8E3DF",
          fontSize: 13,
          fontWeight: 600,
          color: "#7A7470",
          cursor: "pointer",
          zIndex: 1000,
          boxShadow: "0 2px 8px rgba(0,0,0,0.05)",
        }}
      >
        返回用户端
      </button>

      <AdminLayout currentPage={currentPage} onNavigate={setCurrentPage}>
        {currentPage === "overview" && (
          <OverviewPage dashboard={dashboard} loading={loading} error={error} />
        )}
        {currentPage === "styles" && (
          <StylesPage dashboard={dashboard} loading={loading} error={error} />
        )}
        {currentPage === "preferences" && (
          <PreferencesPage dashboard={dashboard} loading={loading} error={error} />
        )}
        {currentPage === "merchants" && (
          <MerchantsPage dashboard={dashboard} loading={loading} error={error} />
        )}
        {currentPage === "alerts" && (
          <AlertsPage dashboard={dashboard} loading={loading} error={error} />
        )}
        {currentPage === "report" && <ReportPage dashboard={dashboard} />}
      </AdminLayout>
    </div>
  );
}
