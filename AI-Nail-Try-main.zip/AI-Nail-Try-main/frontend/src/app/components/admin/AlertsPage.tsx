import type { PlatformDashboard, SupplyDemandAlert } from "../../api";
import { AdminNotice, PageHeader } from "./AdminLayout";

export function AlertsPage({
  dashboard,
  loading,
  error,
}: {
  dashboard: PlatformDashboard | null;
  loading: boolean;
  error: string;
}) {
  const alerts = dashboard?.supply_demand_alerts || [];

  return (
    <div>
      <PageHeader title="供需匹配提醒" subtitle="后端根据热度、偏好和商家能力生成的运营提醒" />
      <AdminNotice loading={loading} error={error} />

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(3, 1fr)",
          gap: 16,
          marginBottom: 32,
        }}
      >
        <SummaryCard label="提醒数量" value={alerts.length.toString()} tone="#D4696B" />
        <SummaryCard label="Mock 模式" value={dashboard?.mock ? "开启" : "关闭"} tone="#D4A640" />
        <SummaryCard label="建议来源" value="platform-dashboard" tone="#7B9F7B" />
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
        {alerts.map((alert, index) => (
          <AlertCard key={`${alert.style_tag}-${index}`} alert={alert} index={index} />
        ))}
      </div>
    </div>
  );
}

function SummaryCard({ label, value, tone }: { label: string; value: string; tone: string }) {
  return (
    <div
      style={{
        background: "#FFFFFF",
        borderRadius: 16,
        padding: "20px 24px",
        border: "1px solid #E8E3DF",
      }}
    >
      <div style={{ fontSize: 12, color: "#9B8E89", marginBottom: 6 }}>{label}</div>
      <div style={{ fontSize: 28, fontWeight: 800, color: tone }}>{value}</div>
    </div>
  );
}

function AlertCard({ alert, index }: { alert: SupplyDemandAlert; index: number }) {
  const highPriority = alert.priority === "high" || (!alert.priority && index === 0);
  return (
    <div
      style={{
        background: "#FFFFFF",
        borderRadius: 20,
        padding: "24px 28px",
        border: highPriority ? "2px solid #FFD6D6" : "1px solid #E8E3DF",
        boxShadow: highPriority ? "0 4px 20px rgba(212, 105, 107, 0.12)" : "0 2px 12px rgba(0,0,0,0.03)",
      }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 10 }}>
        <span
          style={{
            padding: "5px 12px",
            borderRadius: 8,
            background: highPriority ? "#FFF5F5" : "#FAF7F3",
            color: highPriority ? "#D4696B" : "#7A7470",
            fontSize: 11,
            fontWeight: 800,
          }}
        >
          {highPriority ? "高优先级" : "关注"}
        </span>
        <h3 style={{ margin: 0, fontSize: 16, fontWeight: 700, color: "#1F1F1F" }}>
          {alert.style_tag}
        </h3>
      </div>
      <p style={{ margin: 0, fontSize: 14, color: "#5A4F4B", lineHeight: 1.7 }}>{alert.alert}</p>
    </div>
  );
}
