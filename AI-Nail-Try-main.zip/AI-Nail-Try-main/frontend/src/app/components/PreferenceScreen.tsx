import { useState } from "react";
import { Screen } from "../App";
import {
  BottomBar,
  Card,
  GhostButton,
  PrimaryButton,
  ScreenHeader,
  StatusBar,
  Tag,
} from "./shared";

const PREFERENCES = [
  { label: "还原度", desc: "优先匹配擅长复刻目标款式的商家" },
  { label: "性价比", desc: "优先推荐价格友好、评分稳定的商家" },
  { label: "创意", desc: "适合希望在原款基础上做个性调整" },
  { label: "距离", desc: "优先推荐距离更近的服务供给" },
  { label: "服务速度", desc: "优先匹配更快可约、更高效率的商家" },
  { label: "环境", desc: "关注门店环境和整体体验" },
  { label: "价格透明", desc: "关注最终价格是否稳定清晰" },
];

export function PreferenceScreen({
  onNavigate,
  onSelectPreferences,
}: {
  onNavigate: (s: Screen) => void;
  onSelectPreferences: (prefs: string[]) => void;
}) {
  const [ranked, setRanked] = useState<string[]>([]);

  const toggle = (pref: string) => {
    if (ranked.includes(pref)) {
      setRanked(ranked.filter((item) => item !== pref));
      return;
    }
    setRanked([...ranked, pref]);
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", background: "#FAF7F3" }}>
      <StatusBar />
      <ScreenHeader
        title="选择服务偏好"
        subtitle="点击排序，商家推荐会按你的优先级进行匹配"
        backLabel="结果"
        onBack={() => onNavigate("result")}
      />

      <div style={{ flex: 1, overflowY: "auto", padding: "12px 24px 0", scrollbarWidth: "none" }}>
        <Card style={{ marginBottom: 18, background: "#FFF9E6", border: "1px solid #FFE6C0" }}>
          <p style={{ margin: "0 0 6px", fontSize: 13, fontWeight: 700, color: "#9B7A2F" }}>
            排序规则
          </p>
          <p style={{ margin: 0, fontSize: 12, color: "#7A7470", lineHeight: 1.6 }}>
            先点击的偏好权重更高，至少选择 3 项后继续。
          </p>
        </Card>

        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          {PREFERENCES.map((pref) => {
            const rank = ranked.indexOf(pref.label) + 1;
            const selected = rank > 0;
            return (
              <button
                key={pref.label}
                type="button"
                onClick={() => toggle(pref.label)}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 12,
                  textAlign: "left",
                  background: selected ? "#FDF5FF" : "#fff",
                  border: selected ? "1.5px solid #D4A8D4" : "1px solid #EFE7E0",
                  borderRadius: 18,
                  padding: 14,
                  boxShadow: "0 2px 12px rgba(0,0,0,0.04)",
                  cursor: "pointer",
                  fontFamily: "inherit",
                }}
              >
                <div
                  style={{
                    width: 34,
                    height: 34,
                    borderRadius: "50%",
                    background: selected
                      ? "linear-gradient(135deg, #D4A8D4 0%, #A89CC8 100%)"
                      : "#F5F0EC",
                    color: selected ? "#fff" : "#9B8E89",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontWeight: 800,
                    flexShrink: 0,
                  }}
                >
                  {selected ? rank : "+"}
                </div>
                <div style={{ flex: 1 }}>
                  <p style={{ margin: "0 0 4px", fontSize: 15, fontWeight: 700, color: "#1F1F1F" }}>
                    {pref.label}
                  </p>
                  <p style={{ margin: 0, fontSize: 12, color: "#7A7470", lineHeight: 1.5 }}>
                    {pref.desc}
                  </p>
                </div>
              </button>
            );
          })}
        </div>

        <Card style={{ marginTop: 18, marginBottom: 20 }}>
          <p style={{ margin: "0 0 10px", fontSize: 13, fontWeight: 700, color: "#1F1F1F" }}>
            已选优先级
          </p>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            {ranked.length ? (
              ranked.map((pref, index) => (
                <Tag key={pref} active>
                  {index + 1}. {pref}
                </Tag>
              ))
            ) : (
              <span style={{ fontSize: 12, color: "#9B8E89" }}>尚未选择</span>
            )}
          </div>
        </Card>
      </div>

      <BottomBar>
        <GhostButton onClick={() => setRanked([])} style={{ flex: 1 }}>
          重置
        </GhostButton>
        <PrimaryButton
          disabled={ranked.length < 3}
          onClick={() => ranked.length >= 3 && onSelectPreferences(ranked)}
          style={{ flex: 1 }}
        >
          推荐商家
        </PrimaryButton>
      </BottomBar>
    </div>
  );
}
