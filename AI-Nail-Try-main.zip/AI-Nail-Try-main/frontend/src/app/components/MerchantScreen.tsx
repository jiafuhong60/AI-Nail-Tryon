import { useEffect, useState } from "react";
import { MapPin, Star, Store } from "lucide-react";
import { MerchantRecommendationItem, NailStyle, Screen } from "../App";
import { getStyleImage, recommendMerchants, styleSwatch } from "../api";
import {
  Card,
  ErrorBlock,
  LoadingBlock,
  PrimaryButton,
  ScoreBar,
  ScreenHeader,
  StatusBar,
  Tag,
} from "./shared";

export function MerchantScreen({
  onNavigate,
  selectedStyle,
  selectedPreferences,
  onSelectMerchant,
}: {
  onNavigate: (s: Screen) => void;
  selectedStyle: NailStyle | null;
  selectedPreferences: string[];
  onSelectMerchant: (merchant: MerchantRecommendationItem) => void;
}) {
  const [items, setItems] = useState<MerchantRecommendationItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!selectedStyle) return;
    let active = true;
    setLoading(true);
    setError("");
    recommendMerchants(selectedStyle.style_id, selectedPreferences)
      .then((data) => active && setItems(data.items))
      .catch((err: Error) => active && setError(err.message))
      .finally(() => active && setLoading(false));
    return () => {
      active = false;
    };
  }, [selectedPreferences, selectedStyle]);

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", background: "#FAF7F3" }}>
      <StatusBar />
      <ScreenHeader
        title="推荐商家"
        subtitle="根据款式和偏好，从后端 mock 能力画像中推荐"
        backLabel="偏好"
        onBack={() => onNavigate("preference")}
      />

      <div style={{ flex: 1, overflowY: "auto", padding: "12px 24px 0", scrollbarWidth: "none" }}>
        {selectedStyle ? (
          <Card style={{ marginBottom: 20, padding: "14px" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
              <div
                style={{
                  width: 52,
                  height: 52,
                  borderRadius: 14,
                  overflow: "hidden",
                  background: styleSwatch(selectedStyle),
                  flexShrink: 0,
                }}
              >
                <img
                  src={getStyleImage(selectedStyle)}
                  alt={selectedStyle.name}
                  style={{ width: "100%", height: "100%", objectFit: "cover" }}
                />
              </div>
              <div style={{ flex: 1 }}>
                <p style={{ margin: "0 0 2px", fontSize: 11, color: "#C9A9C9", fontWeight: 700 }}>
                  当前选择
                </p>
                <p style={{ margin: "0 0 6px", fontSize: 14, fontWeight: 700, color: "#1F1F1F" }}>
                  {selectedStyle.name}
                </p>
                <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                  {selectedPreferences.slice(0, 3).map((preference) => (
                    <Tag key={preference}>{preference}</Tag>
                  ))}
                </div>
              </div>
            </div>
          </Card>
        ) : (
          <ErrorBlock message="请先选择款式。" />
        )}

        {loading && <LoadingBlock label="正在匹配商家" />}
        {error && <ErrorBlock message={`商家推荐失败：${error}`} />}

        <div style={{ display: "flex", flexDirection: "column", gap: 14, paddingBottom: 80 }}>
          {items.map((merchant, index) => (
            <MerchantCard
              key={merchant.merchant_id}
              merchant={merchant}
              rank={index + 1}
              onSelect={() => onSelectMerchant(merchant)}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

function MerchantCard({
  merchant,
  rank,
  onSelect,
}: {
  merchant: MerchantRecommendationItem;
  rank: number;
  onSelect: () => void;
}) {
  return (
    <Card style={{ padding: "16px" }}>
      <div style={{ display: "flex", gap: 12, marginBottom: 12 }}>
        <div
          style={{
            width: 56,
            height: 56,
            borderRadius: 14,
            background: "linear-gradient(135deg, #E8D5C4 0%, #D4C5D4 100%)",
            flexShrink: 0,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            color: "#7A5F7C",
          }}
        >
          <Store size={24} />
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 3 }}>
            <span
              style={{
                fontSize: 10,
                fontWeight: 800,
                color: "#fff",
                background: "linear-gradient(135deg, #D4A8D4 0%, #A89CC8 100%)",
                borderRadius: 100,
                padding: "2px 8px",
              }}
            >
              #{rank} 匹配
            </span>
            <span style={{ fontSize: 13, fontWeight: 800, color: "#9B6FA0" }}>
              {merchant.match_score}%
            </span>
          </div>
          <p style={{ margin: "0 0 4px", fontSize: 15, fontWeight: 700, color: "#1F1F1F" }}>
            {merchant.merchant_name}
          </p>
          <div style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 12, color: "#7A7470" }}>
            <span style={{ display: "inline-flex", alignItems: "center", gap: 3 }}>
              <Star size={13} fill="#D4A640" color="#D4A640" />
              {merchant.rating}
            </span>
            <span style={{ display: "inline-flex", alignItems: "center", gap: 3 }}>
              <MapPin size={13} />
              {merchant.distance} km
            </span>
          </div>
        </div>
        <div style={{ textAlign: "right" }}>
          <p style={{ margin: "0 0 2px", fontSize: 14, fontWeight: 800, color: "#1F1F1F" }}>
            ¥{merchant.price_range}
          </p>
          <p style={{ margin: 0, fontSize: 11, color: "#7A7470" }}>{merchant.available_time}</p>
        </div>
      </div>

      <div style={{ display: "flex", gap: 6, marginBottom: 12, flexWrap: "wrap" }}>
        <Tag>相似作品 {merchant.similar_work_count}</Tag>
        <Tag>稳定 JSON</Tag>
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 6, marginBottom: 12 }}>
        <ScoreBar label="匹配度" value={merchant.match_score} />
        <ScoreBar label="评分" value={Math.round(merchant.rating * 20)} />
      </div>

      <p
        style={{
          margin: "0 0 14px",
          fontSize: 12,
          color: "#7A7470",
          lineHeight: 1.6,
          background: "#F5F0EC",
          borderRadius: 10,
          padding: "8px 10px",
        }}
      >
        {merchant.match_reason}
      </p>

      <PrimaryButton onClick={onSelect} style={{ width: "100%", padding: "12px" }}>
        选择商家
      </PrimaryButton>
    </Card>
  );
}
