import { useEffect, useMemo, useState, type ReactNode } from "react";
import { Search, Sparkles } from "lucide-react";
import { Screen, NailStyle } from "../App";
import {
  fetchStyles,
  getStyleImage,
  recordEvent,
  styleSwatch,
} from "../api";
import { ErrorBlock, LoadingBlock, ScreenHeader, StatusBar, Tag } from "./shared";

export function StyleLibraryScreen({
  onNavigate,
  onSelectStyle,
}: {
  onNavigate: (s: Screen) => void;
  onSelectStyle: (style: NailStyle) => void;
}) {
  const [styles, setStyles] = useState<NailStyle[]>([]);
  const [selectedTag, setSelectedTag] = useState("全部");
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let active = true;
    setLoading(true);
    fetchStyles()
      .then((items) => {
        if (!active) return;
        setStyles(items);
        items.slice(0, 8).forEach((style) => recordEvent(style.style_id, "view_style"));
      })
      .catch((err: Error) => active && setError(err.message))
      .finally(() => active && setLoading(false));
    return () => {
      active = false;
    };
  }, []);

  const tags = useMemo(() => {
    const all = styles.flatMap((style) => style.tags || []);
    return ["全部", ...Array.from(new Set(all)).slice(0, 8)];
  }, [styles]);

  const filteredStyles = useMemo(() => {
    const keyword = query.trim();
    return styles.filter((style) => {
      const tagMatched = selectedTag === "全部" || style.tags.includes(selectedTag);
      const queryMatched =
        !keyword ||
        `${style.name}${style.scene}${style.color}${style.tags.join("")}`.includes(keyword);
      return tagMatched && queryMatched;
    });
  }, [query, selectedTag, styles]);

  const trending = filteredStyles.slice(0, 4);
  const recommended = filteredStyles.slice(4);

  const selectStyle = (style: NailStyle) => {
    recordEvent(style.style_id, "select_style");
    onSelectStyle(style);
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", background: "#FAF7F3" }}>
      <StatusBar />
      <ScreenHeader
        title="选择美甲款式"
        subtitle="从后端款式库加载，选择后进入试戴流程"
        backLabel="首页"
        onBack={() => onNavigate("home")}
      />

      <div style={{ flex: 1, overflowY: "auto", scrollbarWidth: "none" }}>
        <div style={{ padding: "16px 24px 0" }}>
          <div
            style={{
              display: "flex",
              alignItems: "center",
              background: "#fff",
              borderRadius: 14,
              padding: "12px 16px",
              gap: 10,
              boxShadow: "0 2px 12px rgba(0,0,0,0.05)",
              marginBottom: 14,
            }}
          >
            <Search size={17} color="#C9A9C9" />
            <input
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="搜索款式、颜色、场景"
              style={{
                border: "none",
                outline: "none",
                background: "transparent",
                flex: 1,
                fontSize: 14,
                color: "#1F1F1F",
                fontFamily: "inherit",
              }}
            />
          </div>

          <div style={{ display: "flex", gap: 8, overflowX: "auto", paddingBottom: 16 }}>
            {tags.map((tag) => (
              <Tag key={tag} active={selectedTag === tag} onClick={() => setSelectedTag(tag)}>
                {tag}
              </Tag>
            ))}
          </div>
        </div>

        {loading && <LoadingBlock label="正在加载款式库" />}
        {error && <ErrorBlock message={`款式加载失败：${error}`} />}

        {!loading && !error && (
          <>
            <SectionTitle icon={<Sparkles size={14} />} label="热门款式" />
            <div
              style={{
                display: "flex",
                gap: 12,
                overflowX: "auto",
                scrollbarWidth: "none",
                padding: "0 24px 24px",
              }}
            >
              {trending.map((style, index) => (
                <TrendingCard
                  key={style.style_id}
                  style={style}
                  index={index}
                  onSelect={() => selectStyle(style)}
                />
              ))}
            </div>

            <SectionTitle label="猜你喜欢" />
            <div style={{ padding: "0 24px 32px", display: "flex", flexDirection: "column", gap: 14 }}>
              {(recommended.length ? recommended : trending).map((style, index) => (
                <RecommendedCard
                  key={style.style_id}
                  style={style}
                  index={index}
                  onSelect={() => selectStyle(style)}
                />
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}

function SectionTitle({ label, icon }: { label: string; icon?: ReactNode }) {
  return (
    <p
      style={{
        margin: "0 0 12px 24px",
        fontSize: 12,
        fontWeight: 700,
        color: "#C9A9C9",
        letterSpacing: "0.08em",
        textTransform: "uppercase",
        display: "flex",
        alignItems: "center",
        gap: 6,
      }}
    >
      {icon}
      {label}
    </p>
  );
}

function TrendingCard({
  style,
  index,
  onSelect,
}: {
  style: NailStyle;
  index: number;
  onSelect: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onSelect}
      style={{
        background: "#fff",
        border: "none",
        borderRadius: 20,
        overflow: "hidden",
        boxShadow: "0 2px 12px rgba(0,0,0,0.06)",
        cursor: "pointer",
        minWidth: 160,
        flexShrink: 0,
        padding: 0,
        textAlign: "left",
        fontFamily: "inherit",
      }}
    >
      <div
        style={{
          height: 180,
          background: styleSwatch(style, index),
          position: "relative",
          overflow: "hidden",
        }}
      >
        <img
          src={getStyleImage(style)}
          alt={style.name}
          style={{ width: "100%", height: "100%", objectFit: "cover" }}
        />
        {style.is_new && (
          <span
            style={{
              position: "absolute",
              top: 8,
              left: 8,
              background: "#FF6B9D",
              borderRadius: 8,
              padding: "4px 10px",
              fontSize: 10,
              fontWeight: 700,
              color: "#fff",
            }}
          >
            NEW
          </span>
        )}
      </div>
      <StyleTextBlock style={style} />
    </button>
  );
}

function RecommendedCard({
  style,
  index,
  onSelect,
}: {
  style: NailStyle;
  index: number;
  onSelect: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onSelect}
      style={{
        background: "#fff",
        border: "none",
        borderRadius: 20,
        overflow: "hidden",
        boxShadow: "0 2px 12px rgba(0,0,0,0.06)",
        cursor: "pointer",
        display: "flex",
        gap: 12,
        padding: 0,
        textAlign: "left",
        fontFamily: "inherit",
      }}
    >
      <div
        style={{
          width: 120,
          height: 124,
          background: styleSwatch(style, index),
          overflow: "hidden",
          flexShrink: 0,
        }}
      >
        <img
          src={getStyleImage(style)}
          alt={style.name}
          style={{ width: "100%", height: "100%", objectFit: "cover" }}
        />
      </div>
      <div style={{ flex: 1, padding: "12px 12px 12px 0" }}>
        <StyleTextBlock style={style} compact />
        <p style={{ margin: "8px 0 0", fontSize: 11, color: "#9B8E89", lineHeight: 1.5 }}>
          {style.reason}
        </p>
      </div>
    </button>
  );
}

function StyleTextBlock({ style, compact }: { style: NailStyle; compact?: boolean }) {
  return (
    <div style={{ padding: compact ? 0 : "10px 12px 12px" }}>
      <p
        style={{
          margin: "0 0 6px",
          fontSize: compact ? 14 : 13,
          fontWeight: 600,
          color: "#1F1F1F",
        }}
      >
        {style.name}
      </p>
      <div style={{ display: "flex", gap: 4, flexWrap: "wrap" }}>
        {style.tags.slice(0, 3).map((tag) => (
          <span
            key={tag}
            style={{
              fontSize: 10,
              color: "#7A7470",
              background: "#F5F0EC",
              borderRadius: 100,
              padding: "2px 8px",
            }}
          >
            {tag}
          </span>
        ))}
      </div>
    </div>
  );
}
