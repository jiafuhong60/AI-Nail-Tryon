import { useRef, useState } from "react";
import { Camera, UploadCloud } from "lucide-react";
import { Screen, NailStyle, TryOnResult } from "../App";
import {
  createNailTryOn,
  getStyleImage,
  IMAGE_MODEL_OPTIONS,
  styleSwatch,
  type ImageModelOption,
} from "../api";
import {
  BottomBar,
  Card,
  ErrorBlock,
  GhostButton,
  PrimaryButton,
  ScreenHeader,
  StatusBar,
} from "./shared";

export function HandSelectionScreen({
  onNavigate,
  selectedStyle,
  onTryOnComplete,
}: {
  onNavigate: (s: Screen) => void;
  selectedStyle: NailStyle | null;
  onTryOnComplete: (file: File, result: TryOnResult) => void;
}) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [file, setFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState("");
  const [selectedModel, setSelectedModel] = useState<ImageModelOption>(
    IMAGE_MODEL_OPTIONS[0],
  );
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const selectFile = (nextFile: File | null) => {
    setError("");
    setFile(nextFile);
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    setPreviewUrl(nextFile ? URL.createObjectURL(nextFile) : "");
  };

  const submitTryOn = async () => {
    if (!selectedStyle) {
      setError("请先选择一个美甲款式。");
      return;
    }
    if (!file) {
      fileInputRef.current?.click();
      return;
    }

    setLoading(true);
    setError("");
    try {
      const result = await createNailTryOn(
        file,
        selectedStyle.style_id,
        selectedModel.provider,
        selectedModel.modelName,
      );
      onTryOnComplete(file, result);
    } catch (err) {
      setError(err instanceof Error ? err.message : "试戴接口调用失败");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", background: "#FAF7F3" }}>
      <StatusBar />
      <ScreenHeader
        title="上传手部照片"
        subtitle="选择清晰手图，后端会生成稳定 mock 试戴结果"
        backLabel="款式"
        onBack={() => onNavigate("library")}
      />

      <div style={{ flex: 1, overflowY: "auto", padding: "20px 24px 0", scrollbarWidth: "none" }}>
        {selectedStyle && (
          <Card style={{ marginBottom: 20, display: "flex", alignItems: "center", gap: 14 }}>
            <div
              style={{
                width: 64,
                height: 64,
                borderRadius: 14,
                overflow: "hidden",
                flexShrink: 0,
                background: styleSwatch(selectedStyle),
              }}
            >
              <img
                src={getStyleImage(selectedStyle)}
                alt={selectedStyle.name}
                style={{ width: "100%", height: "100%", objectFit: "cover" }}
              />
            </div>
            <div>
              <p style={{ margin: 0, fontSize: 11, color: "#C9A9C9", fontWeight: 700 }}>
                已选款式
              </p>
              <p style={{ margin: "2px 0 4px", fontSize: 15, fontWeight: 600, color: "#1F1F1F" }}>
                {selectedStyle.name}
              </p>
              <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                {selectedStyle.tags.slice(0, 3).map((tag) => (
                  <span
                    key={tag}
                    style={{
                      fontSize: 10,
                      color: "#7A7470",
                      background: "#F5F0EC",
                      borderRadius: 100,
                      padding: "2px 8px",
                    }}
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          </Card>
        )}

        <input
          ref={fileInputRef}
          type="file"
          accept="image/png,image/jpeg,image/webp"
          style={{ display: "none" }}
          onChange={(event) => selectFile(event.target.files?.[0] || null)}
        />

        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          style={{
            border: "2px dashed #D4A8D4",
            borderRadius: 24,
            padding: previewUrl ? 0 : "36px 20px",
            textAlign: "center",
            cursor: "pointer",
            marginBottom: 20,
            background: "rgba(212,168,212,0.04)",
            width: "100%",
            minHeight: 220,
            overflow: "hidden",
            fontFamily: "inherit",
          }}
        >
          {previewUrl ? (
            <img
              src={previewUrl}
              alt="手部照片预览"
              style={{ width: "100%", height: 260, objectFit: "cover", display: "block" }}
            />
          ) : (
            <>
              <div
                style={{
                  width: 56,
                  height: 56,
                  background: "linear-gradient(135deg, #D4A8D4 0%, #A89CC8 100%)",
                  borderRadius: "50%",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  margin: "0 auto 14px",
                  color: "#fff",
                }}
              >
                <UploadCloud size={24} />
              </div>
              <p style={{ margin: "0 0 6px", fontSize: 16, fontWeight: 600, color: "#1F1F1F" }}>
                上传手部照片
              </p>
              <p style={{ margin: 0, fontSize: 13, color: "#7A7470" }}>
                支持 JPG、PNG、WEBP，建议光线均匀
              </p>
            </>
          )}
        </button>

        <Card style={{ background: "#FDF5FF", borderRadius: 16, padding: "14px 16px" }}>
          <p style={{ margin: "0 0 6px", fontSize: 12, fontWeight: 700, color: "#9B6FA0" }}>
            拍摄建议
          </p>
          <ul style={{ margin: 0, paddingLeft: 16, fontSize: 12, color: "#7A7470", lineHeight: 1.7 }}>
            <li>平放手掌，手指自然张开</li>
            <li>保持画面明亮，避免强阴影</li>
            <li>当前后端 mock 会复制上传图作为结果图</li>
          </ul>
        </Card>

        <Card style={{ marginTop: 16, borderRadius: 16, padding: "14px 16px" }}>
          <p style={{ margin: "0 0 10px", fontSize: 12, fontWeight: 700, color: "#1F1F1F" }}>
            AI 鍥惧儚妯″瀷
          </p>
          <div style={{ display: "grid", gap: 8 }}>
            {IMAGE_MODEL_OPTIONS.map((option) => {
              const active = selectedModel.provider === option.provider;
              return (
                <button
                  key={option.provider}
                  type="button"
                  onClick={() => setSelectedModel(option)}
                  disabled={loading}
                  style={{
                    width: "100%",
                    border: active ? "1.5px solid #D4A8D4" : "1px solid #E6DED8",
                    borderRadius: 14,
                    padding: "10px 12px",
                    textAlign: "left",
                    background: active ? "#FDF5FF" : "#fff",
                    color: "#1F1F1F",
                    cursor: loading ? "not-allowed" : "pointer",
                    fontFamily: "inherit",
                  }}
                >
                  <span style={{ display: "block", fontSize: 13, fontWeight: 700 }}>
                    {option.label}
                  </span>
                  <span style={{ display: "block", fontSize: 11, color: "#7A7470", marginTop: 2 }}>
                    {option.modelName}
                  </span>
                </button>
              );
            })}
          </div>
        </Card>

        {error && <ErrorBlock message={error} />}
      </div>

      <BottomBar>
        <GhostButton onClick={() => onNavigate("library")} disabled={loading} style={{ flex: 1 }}>
          返回款式
        </GhostButton>
        <PrimaryButton onClick={submitTryOn} disabled={loading || !selectedStyle} style={{ flex: 1 }}>
          <span style={{ display: "inline-flex", alignItems: "center", gap: 8 }}>
            <Camera size={17} />
            {loading ? "生成中" : file ? "开始试戴" : "选择照片"}
          </span>
        </PrimaryButton>
      </BottomBar>
    </div>
  );
}
