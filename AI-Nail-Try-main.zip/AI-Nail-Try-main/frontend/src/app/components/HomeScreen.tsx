import { Sparkles, Store } from "lucide-react";
import { Screen } from "../App";
import { GhostButton, PrimaryButton, StatusBar } from "./shared";
import logoNoBg from "../../imports/logo_no_bg.png";

export function HomeScreen({ onNavigate }: { onNavigate: (s: Screen) => void }) {
  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        height: "100%",
        background: "linear-gradient(135deg, #FAF7F3 0%, #F5F0F3 50%, #F0EBF0 100%)",
      }}
    >
      <StatusBar />

      <div
        style={{
          margin: "8px 20px 0",
          borderRadius: 28,
          overflow: "hidden",
          height: 340,
          position: "relative",
          flexShrink: 0,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <img
          src={logoNoBg}
          alt="AI Nail Assistant"
          style={{
            maxWidth: "80%",
            maxHeight: "80%",
            objectFit: "contain",
          }}
        />
      </div>

      <div style={{ padding: "24px 28px 0", flex: 1 }}>
        <h1
          style={{
            margin: "0 0 16px",
            fontSize: 32,
            fontWeight: 500,
            color: "#1F1F1F",
            lineHeight: 1.18,
            letterSpacing: 0,
            fontFamily: "'Playfair Display', serif",
          }}
        >
          AI 美甲助手
        </h1>
        <p
          style={{
            margin: "0 0 48px",
            fontSize: 17,
            color: "#9B6FA0",
            lineHeight: 1.5,
            fontFamily: "'Playfair Display', serif",
            fontStyle: "italic",
          }}
        >
          选择款式，上传手图，获取试戴结果和门店建议。
        </p>

        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          <PrimaryButton
            onClick={() => onNavigate("library")}
            style={{ width: "100%", padding: "16px", display: "flex", justifyContent: "center", gap: 8 }}
          >
            <Sparkles size={18} />
            用户端入口
          </PrimaryButton>
          <GhostButton
            onClick={() => onNavigate("admin")}
            style={{ width: "100%", padding: "16px", display: "flex", justifyContent: "center", gap: 8 }}
          >
            <Store size={18} />
            运营端入口
          </GhostButton>
        </div>
      </div>

      <div style={{ height: 40 }} />
    </div>
  );
}
