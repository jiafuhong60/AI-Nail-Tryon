﻿# API 鎺ュ彛濂戠害

## 1. 鍋ュ悍妫€鏌?
### GET `/health`

鍝嶅簲锛?
```json
{
  "status": "ok",
  "service": "nail-ai-backend"
}
```

## 2. 鑾峰彇娆惧紡鍒楄〃

### GET `/api/styles`

鍝嶅簲锛?
```json
{
  "items": [
    {
      "id": "style_001",
      "name": "濂惰尪瑁歌壊閫氬嫟娆?,
      "image_url": "/static/styles/style_001.png",
      "style_id": "style_001",
      "style_name": "濂惰尪瑁歌壊閫氬嫟娆?,
      "original_url": "/static/styles/style_001_original.png",
      "enhanced_url": "/static/styles/style_001.png",
      "image_path": "/static/styles/style_001.png",
      "tags": ["閫氬嫟", "鏄剧櫧", "浣庤皟"],
      "scene": "鏃ュ父鍔炲叕",
      "color": "濂惰尪鑹?,
      "reason": "閫傚悎閫氬嫟鍦烘櫙锛岄鏍艰嚜鐒讹紝鏄炬墜骞插噣",
      "is_new": true
    }
  ]
}
```

## 3. 鑾峰彇鍗曚釜娆惧紡

### GET `/api/styles/{style_id}`

鍝嶅簲锛?
```json
{
  "id": "style_001",
  "name": "濂惰尪瑁歌壊閫氬嫟娆?,
  "image_url": "/static/styles/style_001.png",
  "style_id": "style_001",
  "style_name": "濂惰尪瑁歌壊閫氬嫟娆?,
  "original_url": "/static/styles/style_001_original.png",
  "enhanced_url": "/static/styles/style_001.png",
  "image_path": "/static/styles/style_001.png",
  "tags": ["閫氬嫟", "鏄剧櫧", "浣庤皟"],
  "scene": "鏃ュ父鍔炲叕",
  "color": "濂惰尪鑹?,
  "reason": "閫傚悎閫氬嫟鍦烘櫙锛岄鏍艰嚜鐒讹紝鏄炬墜骞插噣",
  "is_new": true
}
```

璇存槑锛歚style_id/style_name/image_path` 鏄吋瀹瑰悎浣滄柟瑙勫垝鐨勫埆鍚嶅瓧娈碉紝鏃у瓧娈?`id/name/image_url` 淇濈暀銆俙original_url/enhanced_url` 鍒嗗埆鐢ㄤ簬淇濈暀瀹樻柟鍘熷娆惧紡鍥惧拰澧炲己鍚庢寮忓浘銆?
## 4. AI 璇曟埓

### POST `/api/tryon`

璇锋眰绫诲瀷锛?
```text
multipart/form-data
```

瀛楁锛?
```text
hand_image: file
style_id: string
user_id: string锛屽彲閫夛紝榛樿 demo_user
```

鍝嶅簲锛?
```json
{
  "task_id": "tryon_20250101_001",
  "status": "success",
  "style_id": "style_001",
  "original_image_url": "/uploads/hand_001.png",
  "result_image_url": "/outputs/result_001.png",
  "ai_reason": "璇ユ寮忛鑹叉煍鍜岋紝閫傚悎鏃ュ父閫氬嫟锛岃兘鎻愬崌鎵嬮儴骞插噣鎰?,
  "mock": true
}
```

## 5. 璁板綍鐢ㄦ埛琛屼负

### POST `/api/events`

璇锋眰锛?
```json
{
  "user_id": "demo_user",
  "style_id": "style_001",
  "event_type": "tryon"
}
```

鍝嶅簲锛?
```json
{
  "success": true,
  "event_id": "event_001"
}
```

## 6. 鑾峰彇琛屼负鍒楄〃

### GET `/api/events`

鍝嶅簲锛?
```json
{
  "items": [
    {
      "id": "event_001",
      "user_id": "demo_user",
      "style_id": "style_001",
      "event_type": "tryon",
      "created_at": "2025-01-01T10:00:00"
    }
  ]
}
```

## 7. 杩愯惀鐪嬫澘鏁版嵁

### GET `/api/analytics/dashboard`

鍝嶅簲锛?
```json
{
  "today_tryon_count": 128,
  "today_user_count": 46,
  "top_styles": [
    {
      "style_id": "style_001",
      "name": "濂惰尪瑁歌壊閫氬嫟娆?,
      "tryon_count": 32,
      "favorite_count": 14,
      "book_count": 5,
      "hot_score": 22.6
    }
  ],
  "hot_tags": [
    {
      "tag": "鏄剧櫧",
      "count": 58
    }
  ],
  "cold_styles": [
    {
      "style_id": "style_007",
      "name": "娣辫壊鐚溂娆?,
      "reason": "鏇濆厜杈冮珮浣嗚瘯鎴寸巼杈冧綆"
    }
  ],
  "recommendation": {
    "main_style_id": "style_001",
    "main_style_name": "濂惰尪瑁歌壊閫氬嫟娆?,
    "reason": "璇曟埓閲忓拰鏀惰棌鐜囧潎杈冮珮锛岄€傚悎鏄庢棩棣栭〉涓绘帹"
  }
}
```

## 8. 鐢熸垚杩愯惀鏃ユ姤

### POST `/api/ai/report`

璇锋眰锛?
```json
{
  "date": "2025-01-01"
}
```

鍝嶅簲锛?
```json
{
  "summary": "浠婃棩鎬昏瘯鎴存鏁颁负 128 娆★紝濂惰尪瑁歌壊銆佹硶寮忕櫧杈广€佹柊涓紡鏅曟煋娆捐〃鐜扮獊鍑恒€?,
  "hot_trend": "鏄剧櫧銆侀€氬嫟銆佽８鑹叉爣绛惧闀挎槑鏄撅紝寤鸿鏄庢棩缁х画鎻愬崌鏇濆厜銆?,
  "risk": "娣辫壊鐚溂娆剧偣鍑荤巼杈冧綆锛屽缓璁洿鎹㈠皝闈㈠浘鎴栭檷浣庢帹鑽愭潈閲嶃€?,
  "suggestion": "鏄庢棩棣栭〉涓绘帹濂惰尪瑁歌壊閫氬嫟娆撅紝骞堕厤鍚堢敓鎴愬皬绾功鎺ㄥ箍鏂囨銆?,
  "mock": true
}
```

## 9. 鐢熸垚鎺ㄥ箍鏂囨

### POST `/api/ai/promotion`

璇锋眰锛?
```json
{
  "style_id": "style_001",
  "channel": "xiaohongshu"
}
```

鍝嶅簲锛?
```json
{
  "title": "閫氬嫟濂崇敓闂溂鍏ョ殑濂惰尪瑁歌壊缇庣敳",
  "content": "浣庤皟鍙堢簿鑷寸殑濂惰尪瑁歌壊锛屾棩甯镐笂鐝笉绐佸厐锛岀害浼氭媿鐓т篃寰堟樉鎵嬪共鍑€銆?,
  "hashtags": ["缇庣敳", "閫氬嫟缇庣敳", "鏄剧櫧缇庣敳", "濂惰尪鑹茬編鐢?],
  "mock": true
}
```

## 10. 鐢熸垚鐢ㄦ埛閫傞厤寤鸿

### POST `/api/ai/advice`

璇锋眰锛?
```json
{
  "style_id": "style_001"
}
```

鍝嶅簲锛?
```json
{
  "advice": "杩欐濂惰尪瑁歌壊椋庢牸鑷劧锛岄€傚悎閫氬嫟鍜屾棩甯稿満鏅紝棰滆壊鏌斿拰锛岃兘璁╂墜閮ㄧ湅璧锋潵鏇村共鍑€銆?,
  "mock": true
}
```

## 11. 鑾峰彇瀹樻柟鎵嬪浘鍒楄〃

### GET `/api/hands`

鍝嶅簲锛?
```json
{
  "items": [
    {
      "hand_id": "hand_001",
      "hand_url": "http://example.com/hand_001.png",
      "local_path": "http://example.com/hand_001.png",
      "skin_tone": "鑷劧鑲よ壊",
      "hand_shape": "甯歌鎵嬪瀷"
    }
  ]
}
```

## 12. 鑾峰彇鍗曚釜瀹樻柟鎵嬪浘

### GET `/api/hands/{hand_id}`

鍝嶅簲涓哄崟涓墜鍥惧璞★紝涓嶅瓨鍦ㄨ繑鍥?`404`銆?
## 13. 鑾峰彇鍟嗗鑳藉姏鍒楄〃

### GET `/api/merchants`

鍝嶅簲锛?
```json
{
  "items": [
    {
      "merchant_id": "merchant_001",
      "merchant_name": "鍩庡競缇庣敳鐮旂┒鎵€",
      "distance": 1.2,
      "price_min": 128,
      "price_max": 268,
      "rating": 4.8,
      "available_time": "浠婂ぉ 18:30",
      "restore_score": 92,
      "creative_score": 84,
      "speed_score": 86,
      "cost_score": 88,
      "environment_score": 90,
      "price_stability_score": 87,
      "similar_work_count": 26,
      "skill_tags": ["濂惰尪鑹?, "娉曞紡", "閫氬嫟", "瑁歌壊"]
    }
  ]
}
```

## 14. 鑾峰彇鍟嗗璇︽儏

### GET `/api/merchants/{merchant_id}`

鍝嶅簲涓哄崟涓晢瀹跺璞★紝涓嶅瓨鍦ㄨ繑鍥?`404`銆?
## 15. 鎺ㄨ崘鍟嗗

### POST `/api/recommend/merchants`

璇锋眰锛?
```json
{
  "user_id": "demo_user",
  "hand_id": "hand_001",
  "style_id": "style_001",
  "preferences": ["杩樺師搴?, "鎬т环姣?]
}
```

鍝嶅簲锛?
```json
{
  "style_id": "style_001",
  "style_name": "娆惧紡 001",
  "hand_id": "hand_001",
  "preferences": ["杩樺師搴?, "鎬т环姣?],
  "items": [
    {
      "merchant_id": "merchant_001",
      "merchant_name": "鍩庡競缇庣敳鐮旂┒鎵€",
      "distance": 1.2,
      "price_range": "128-268",
      "rating": 4.8,
      "available_time": "浠婂ぉ 18:30",
      "similar_work_count": 26,
      "match_score": 91.5,
      "match_reason": "璇ュ晢瀹舵搮闀垮ザ鑼惰壊銆佹硶寮忓拰閫氬嫟娆撅紝鐩镐技浣滃搧杈冨锛岃繕鍘熷害鍜屾€т环姣旇瘎鍒嗚緝楂樸€?
    }
  ],
  "mock": true
}
```

## 16. 鍒涘缓鏈嶅姟闇€姹傜‘璁ゅ崟

### POST `/api/confirmation`

璇锋眰锛?
```json
{
  "user_id": "demo_user",
  "hand_id": "hand_001",
  "style_id": "style_001",
  "merchant_id": "merchant_001",
  "preferences": ["杩樺師搴?, "鎬т环姣?],
  "tryon_result_url": "/outputs/result_001.png"
}
```

鍝嶅簲锛?
```json
{
  "confirmation_id": "confirm_001",
  "style_id": "style_001",
  "style_name": "娆惧紡 001",
  "merchant_id": "merchant_001",
  "merchant_name": "鍩庡競缇庣敳鐮旂┒鎵€",
  "tryon_result_url": "/outputs/result_001.png",
  "expected_price": "128-268",
  "user_preferences": ["杩樺師搴?, "鎬т环姣?],
  "key_points": [
    "閲嶇偣纭棰滆壊鍜屽浘妗堣繕鍘熷害",
    "纭鏈€缁堜环鏍兼槸鍚﹀寘鍚嵏鐢层€佸欢闀垮拰鍔犲浐"
  ],
  "merchant_suggestion": "寤鸿鍟嗗浼樺厛灞曠ず鐩镐技濂惰尪鑹叉硶寮忎綔鍝侊紝骞跺湪鏈嶅姟鍓嶇‘璁ょ敤鎴峰棰滆壊娣辨祬鍜屾寮忓鏉傚害鐨勬帴鍙楄寖鍥淬€?,
  "mock": true
}
```

## 17. 鑾峰彇鏈嶅姟闇€姹傜‘璁ゅ崟

### GET `/api/confirmation/{confirmation_id}`

鍝嶅簲涓哄崟涓‘璁ゅ崟瀵硅薄锛屼笉瀛樺湪杩斿洖 `404`銆?
## 18. 骞冲彴杩愯惀鐪嬫澘

### GET `/api/analytics/platform-dashboard`

鍝嶅簲锛?
```json

{
  "style_heat_ranking": [
    {
      "style_id": "style_001",
      "style_name": "娆惧紡 001",
      "exposure": 1200,
      "tryon_count": 320,
      "favorite_count": 96,
      "appointment_count": 42,
      "conversion_rate": 0.131,
      "heat_score": 248.4
    }
  ],
  "preference_trends": [
    {
      "preference": "杩樺師搴?,
      "count": 86,
      "ratio": 0.34
    }
  ],
  "merchant_capabilities": [
    {
      "merchant_id": "merchant_001",
      "merchant_name": "鍩庡競缇庣敳鐮旂┒鎵€",
      "restore_score": 92,
      "creative_score": 84,
      "speed_score": 86,
      "cost_score": 88,
      "environment_score": 90,
      "similar_work_count": 26
    }
  ],
  "supply_demand_alerts": [
    {
      "style_tag": "濂惰尪鑹叉硶寮?,
      "alert": "璇ョ被娆惧紡璇曟埓閲忎笂鍗囷紝浣嗛珮杩樺師搴﹀晢瀹舵暟閲忎笉瓒筹紝寤鸿鎻愬崌鐩稿叧鍟嗗鏇濆厜銆?
    }
  ],
  "ai_suggestion": "浠婃棩鐭敳閫氬嫟娆剧儹搴︿笂鍗囷紝鐢ㄦ埛鏈€鍏虫敞杩樺師搴﹀拰鎬т环姣斻€?,
  "mock": true
}
```
### Platform dashboard Demo 数据补充

`GET /api/analytics/platform-dashboard` 当前优先读取 `backend/app/data/` 下的 Demo JSON 数据：

- `behavior_metrics.json`：按 `style_id` 聚合生成 `overview` 和 `style_heat_ranking`。
- `preference_events.json`：按每条记录的 `preferences` 数组统计 `preference_trends`，兼容旧的 `{preference,count}` 格式。
- `merchants.json`：生成 `merchant_capabilities`，包含商家距离、价格、评分、可用时间、能力分、价格稳定性和技能标签。
- `events.json`：保留为用户行为链路 Demo 数据源。

新增兼容字段：`overview`、`style_heat_ranking[].image_url`、`style_heat_ranking[].tags`、`merchant_capabilities[].skill_tags`、`supply_demand_alerts[].priority`、`supply_demand_alerts[].capable_merchant_count`、`supply_demand_alerts[].high_restore_merchant_count`。
