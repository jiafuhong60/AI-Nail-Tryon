# 08_OFFICIAL_DATA_ALIGNMENT_TASKS.md

## 1. 本文件目标

本文件用于让 Codex 在现有 FastAPI 后端基础上补齐前后端对齐所需能力。

当前项目后端已经完成基础接口，包括：

```text
GET  /health
GET  /api/styles
GET  /api/styles/{style_id}
POST /api/tryon
POST /api/events
GET  /api/events
GET  /api/analytics/dashboard
POST /api/ai/report
POST /api/ai/promotion
POST /api/ai/advice
```

本次任务不要推翻已有后端，不要改接口路径，不要删除已有 mock/real AI 适配层。

目标是在已有能力上补齐：

```text
1. 官方手图数据接口
2. 官方款式图字段兼容
3. 商家能力 mock 数据
4. 用户偏好驱动的商家推荐
5. 服务需求确认单
6. 平台运营看板 platform-dashboard
7. 测试和 README 对齐
```

---

## 2. Codex 开始前必须阅读的文件

请 Codex 在执行本文件任务前先阅读：

```text
AGENTS.md
docs/03_API_CONTRACT.md
docs/05_AI_PROMPTS.md
docs/06_CODEX_TASKS.md
docs/08_OFFICIAL_DATA_ALIGNMENT_TASKS.md
```

如果 `docs/03_API_CONTRACT.md` 中尚未包含本文件新增接口，请在完成对应接口后同步补充 API 契约。

---

## 3. 官方数据范围说明

当前官方只提供 `data.xlsx`，包含两个 Sheet：

```text
Sheet 1：手图
字段：手图URL、款式图URL

Sheet 2：款式图
字段：序号、原始款式图URL、增强后款式图URL
```

重要约束：

```text
1. 官方真实数据只包含手图 URL 和款式图 URL。
2. 官方没有提供商家数据。
3. 官方没有提供用户行为数据。
4. 官方没有提供用户偏好数据。
5. 官方没有提供真实预约、转化、商家能力数据。
```

因此：

```text
hands.json 和 styles.json 来源于官方 data.xlsx。
merchants.json、behavior_metrics.json、preference_events.json、tryon_records.json 均为 Demo mock 数据。
```

不要把 mock 数据伪装成官方真实数据。

---

## 4. 总体开发要求

1. 保留所有已有接口。
2. 不允许删除或重命名已有字段。
3. 新增字段必须向前兼容。
4. 所有新增数据都允许使用 mock。
5. 不做登录。
6. 不做支付。
7. 不做真实地图。
8. 不做真实预约。
9. 不做复杂推荐算法。
10. 不训练模型。
11. AI 失败时继续使用 mock 兜底。
12. 新增接口必须补测试。
13. README 必须补充前端联调说明。

---

## 5. 新增目录和数据文件建议

在 `backend/app/data` 下新增或补齐：

```text
hands.json
merchants.json
behavior_metrics.json
preference_events.json
tryon_records.json
```

如需要处理官方 Excel，可新增脚本：

```text
backend/scripts/import_official_data.py
```

脚本职责：

```text
1. 从 data.xlsx 读取手图 Sheet，生成 hands.json。
2. 从 data.xlsx 读取款式图 Sheet，生成或扩展 styles.json。
3. styles.json 中 image_url 默认使用 enhanced_url。
4. 保留 original_url 和 enhanced_url。
5. 如果无法读取 Excel，则允许 Codex 先使用手动 mock JSON 保证后端可运行。
```

注意：如果项目环境没有 Excel 解析依赖，不要为了这个任务引入复杂依赖。可以先手动生成 JSON 样例。

---

# 6. Step 11：补齐官方手图接口

## 状态

DONE

## 任务

新增 hands 模块：

```text
GET /api/hands
GET /api/hands/{hand_id}
```

新增数据文件：

```text
backend/app/data/hands.json
```

每条数据字段：

```json
{
  "hand_id": "hand_001",
  "hand_url": "官方手图URL",
  "local_path": "/static/hands/hand_001.png",
  "skin_tone": "自然肤色",
  "hand_shape": "常规手型"
}
```

## 要求

1. 至少提供 6 条手图数据。
2. `hand_url` 使用官方 URL。
3. `skin_tone` 和 `hand_shape` 可以使用 mock 标签。
4. 若图片没有下载到本地，`local_path` 可以等于 `hand_url` 或为空。
5. 查询不存在的 `hand_id` 返回 404。
6. 保证接口返回稳定 JSON。

## 响应示例

### GET `/api/hands`

```json
{
  "items": [
    {
      "hand_id": "hand_001",
      "hand_url": "http://example.com/hand_001.png",
      "local_path": "http://example.com/hand_001.png",
      "skin_tone": "自然肤色",
      "hand_shape": "常规手型"
    }
  ]
}
```

---

# 7. Step 12：扩展款式数据字段

## 状态

DONE

## 任务

扩展现有 `styles.json`，使其同时兼容现有后端字段和前端规划字段。

每条款式数据必须包含：

```json
{
  "id": "style_001",
  "style_id": "style_001",
  "name": "款式 001",
  "style_name": "款式 001",
  "original_url": "官方原始款式图URL",
  "enhanced_url": "官方增强后款式图URL",
  "image_url": "官方增强后款式图URL",
  "image_path": "官方增强后款式图URL",
  "tags": ["通勤", "显白"],
  "style_tag": "通勤",
  "color": "奶茶色",
  "element": "法式",
  "complexity": "中",
  "scene": "日常通勤",
  "reason": "风格自然，适合日常场景",
  "is_new": true
}
```

## 要求

1. 保持 `GET /api/styles` 原有返回结构可用。
2. 保持 `GET /api/styles/{style_id}` 原有查询逻辑可用。
3. `image_url` 默认使用 `enhanced_url`。
4. 保留 `original_url` 供展示“原始款式图”。
5. 保留 `enhanced_url` 供展示“增强款式图”。
6. 不要删除原来的 `id/name/image_url/tags/scene/color/reason/is_new` 字段。
7. 至少 12 个款式；如果官方 Excel 中有 25 个款式，优先保留 25 个。

---

# 8. Step 13：新增商家能力数据接口

## 状态

DONE

## 任务

新增 merchants 模块：

```text
GET /api/merchants
GET /api/merchants/{merchant_id}
```

新增数据文件：

```text
backend/app/data/merchants.json
```

每条商家数据字段：

```json
{
  "merchant_id": "merchant_001",
  "merchant_name": "城市美甲研究所",
  "distance": 1.2,
  "price_min": 128,
  "price_max": 268,
  "rating": 4.8,
  "available_time": "今天 18:30",
  "restore_score": 92,
  "creative_score": 84,
  "speed_score": 86,
  "cost_score": 88,
  "environment_score": 90,
  "price_stability_score": 87,
  "similar_work_count": 26,
  "skill_tags": ["奶茶色", "法式", "通勤", "裸色"]
}
```

## 要求

1. 至少模拟 6 个商家。
2. 商家能力数据明确为 Demo mock 数据。
3. skill_tags 需要能和 styles.tags/color/element/scene 做匹配。
4. 查询不存在的 `merchant_id` 返回 404。

---

# 9. Step 14：新增商家推荐接口

## 状态

DONE

## 接口

```text
POST /api/recommend/merchants
```

## 请求体

```json
{
  "user_id": "demo_user",
  "hand_id": "hand_001",
  "style_id": "style_001",
  "preferences": ["还原度", "性价比"]
}
```

## 响应体

```json
{
  "style_id": "style_001",
  "style_name": "款式 001",
  "hand_id": "hand_001",
  "preferences": ["还原度", "性价比"],
  "items": [
    {
      "merchant_id": "merchant_001",
      "merchant_name": "城市美甲研究所",
      "distance": 1.2,
      "price_range": "128-268",
      "rating": 4.8,
      "available_time": "今天 18:30",
      "similar_work_count": 26,
      "match_score": 91.5,
      "match_reason": "该商家擅长奶茶色、法式和通勤款，相似作品较多，还原度和性价比评分较高。"
    }
  ],
  "mock": true
}
```

## 推荐规则

基础分：

```text
base_score = 商家 skill_tags 与款式标签/颜色/元素/场景的匹配程度
```

偏好权重：

```text
如果 preferences 包含“还原度”：提高 restore_score 权重
如果 preferences 包含“性价比”：提高 cost_score 和 price_stability_score 权重
如果 preferences 包含“创意”：提高 creative_score 权重
如果 preferences 包含“距离”：距离越近得分越高
如果 preferences 包含“服务速度”：提高 speed_score 权重
如果 preferences 包含“环境”：提高 environment_score 权重
如果 preferences 包含“价格透明”：提高 price_stability_score 权重
```

建议公式可先简单实现：

```text
match_score = tag_match_score * 0.25
            + restore_score_weighted
            + creative_score_weighted
            + speed_score_weighted
            + cost_score_weighted
            + environment_score_weighted
            + distance_score * 0.10
            + similar_work_score * 0.10
```

不要求复杂机器学习，只要排序合理、理由可解释。

## 其他要求

1. `style_id` 不存在返回 404。
2. `hand_id` 不存在返回 404；如果请求没有 hand_id，可允许为空。
3. 每次推荐后可以写入 `preference_events.json`，用于运营端统计偏好趋势。
4. 返回推荐商家最多 5 个。

---

# 10. Step 15：新增服务需求确认单接口

## 状态

DONE

## 接口

```text
POST /api/confirmation
```

## 请求体

```json
{
  "user_id": "demo_user",
  "hand_id": "hand_001",
  "style_id": "style_001",
  "merchant_id": "merchant_001",
  "preferences": ["还原度", "性价比"],
  "tryon_result_url": "/outputs/result_001.png"
}
```

## 响应体

```json
{
  "confirmation_id": "confirm_001",
  "style_id": "style_001",
  "style_name": "款式 001",
  "merchant_id": "merchant_001",
  "merchant_name": "城市美甲研究所",
  "tryon_result_url": "/outputs/result_001.png",
  "expected_price": "128-268",
  "user_preferences": ["还原度", "性价比"],
  "key_points": [
    "重点确认颜色和图案还原度",
    "确认最终价格是否包含卸甲、延长和加固",
    "服务前建议展示相似作品给用户确认"
  ],
  "merchant_suggestion": "建议商家优先展示相似奶茶色法式作品，并在服务前确认用户对颜色深浅和款式复杂度的接受范围。",
  "mock": true
}
```

## 要求

1. `style_id` 不存在返回 404。
2. `merchant_id` 不存在返回 404。
3. confirmation_id 自动生成。
4. 重点确认事项根据 preferences 生成，不需要真实 LLM。
5. 如已有 LLM adapter，可在 real 模式下生成更自然文案，但必须保留 mock 兜底。

---

# 11. Step 16：新增平台运营看板接口

## 状态

DONE

## 接口

```text
GET /api/analytics/platform-dashboard
```

## 响应体

```json
{
  "style_heat_ranking": [
    {
      "style_id": "style_001",
      "style_name": "款式 001",
      "exposure": 1200,
      "tryon_count": 320,
      "favorite_count": 96,
      "appointment_count": 42,
      "conversion_rate": 0.131,
      "heat_score": 248.4
    }
  ],
  "preference_trends": [
    {
      "preference": "还原度",
      "count": 86,
      "ratio": 0.34
    }
  ],
  "merchant_capabilities": [
    {
      "merchant_id": "merchant_001",
      "merchant_name": "城市美甲研究所",
      "restore_score": 92,
      "creative_score": 84,
      "speed_score": 86,
      "cost_score": 88,
      "environment_score": 90,
      "similar_work_count": 26
    }
  ],
  "supply_demand_alerts": [
    {
      "style_tag": "奶茶色法式",
      "alert": "该类款式试戴量上升，但高还原度商家数量不足，建议提升相关商家曝光。"
    }
  ],
  "ai_suggestion": "今日短甲通勤款热度上升，用户最关注还原度和性价比。建议首页提升奶茶色、法式、裸粉类款式曝光，并优先推荐相似作品多、价格稳定的商家。",
  "mock": true
}
```

## 数据来源

```text
style_heat_ranking：优先读取 behavior_metrics.json；没有则从 events.json 生成简化统计。
preference_trends：优先读取 preference_events.json；没有则返回 mock。
merchant_capabilities：读取 merchants.json。
supply_demand_alerts：基于热门款式标签和高匹配商家数量生成 mock 提醒。
ai_suggestion：可由 mock 文案生成；有 LLM adapter 时可调用 LLM，但必须兜底。
```

## 要求

1. 即使数据为空，也返回稳定结构。
2. `style_heat_ranking` 最多返回 10 个。
3. `merchant_capabilities` 最多返回 10 个。
4. `supply_demand_alerts` 至少返回 1 条 mock 提醒。
5. 不依赖真实地图和真实预约。

---

# 12. Step 17：补充测试

## 状态

DONE

请新增或补充 pytest 测试：

```text
1. GET /api/hands
2. GET /api/hands/{hand_id}
3. GET /api/merchants
4. GET /api/merchants/{merchant_id}
5. POST /api/recommend/merchants
6. POST /api/confirmation
7. GET /api/analytics/platform-dashboard
8. GET /api/styles 确认包含兼容字段 style_id/style_name/original_url/enhanced_url/image_path
```

测试要求：

```text
1. 不依赖真实 AI API。
2. 不依赖外部网络图片可访问。
3. 不破坏原有测试。
4. mock 数据为空时也至少有稳定响应测试。
```

---

# 13. Step 18：更新文档和前端联调说明

## 状态

DONE

请更新：

```text
backend/README.md
docs/03_API_CONTRACT.md
```

需要补充：

```text
1. 官方数据只包含手图 URL 和款式图 URL。
2. 商家、行为、偏好、运营指标均为 Demo mock 数据。
3. 新增 API 列表。
4. 前端用户端调用顺序。
5. 前端运营端调用顺序。
6. 推荐接口请求示例。
7. 确认单接口请求示例。
8. platform-dashboard 返回示例。
9. 常见问题：图片无法访问、mock 模式、字段兼容说明。
```

---

# 14. 前端用户端推荐调用顺序

```text
1. GET /api/hands
2. GET /api/styles
3. POST /api/tryon
4. POST /api/ai/advice
5. POST /api/recommend/merchants
6. POST /api/confirmation
7. POST /api/events，可记录 favorite、appointment_click 等行为
```

---

# 15. 前端运营端推荐调用顺序

```text
1. GET /api/analytics/platform-dashboard
2. POST /api/ai/report
3. POST /api/ai/promotion，可为某个热门款式生成推广文案
```

---

# 16. 最小验收标准

完成本文件任务后，至少能跑通：

```text
用户端：
选择手图 → 选择款式 → AI 试戴 → 选择偏好 → 推荐商家 → 生成确认单

运营端：
查看热度榜 → 查看偏好趋势 → 查看商家能力 → 查看供需提醒 → 查看 AI 运营建议
```

后端验收：

```text
1. docker compose up --build 可以启动。
2. 原有接口全部继续可用。
3. 新增接口全部可用。
4. pytest 通过。
5. README 中有前端联调说明。
6. 所有真实 AI/图片失败时系统仍能 mock 演示。
```

---

# 17. 推荐给 Codex 的执行方式

不要一次性完成全部任务。请按下面顺序执行：

```text
Step 11：hands 接口
Step 12：styles 字段兼容
Step 13：merchants 接口
Step 14：recommend/merchants 推荐接口
Step 15：confirmation 确认单接口
Step 16：platform-dashboard 平台看板接口
Step 17：测试
Step 18：README 和 API 契约
```

每完成一步，请输出：

```text
已完成：
- ...

修改文件：
- ...

本地验证：
- ...

下一步建议：
- ...
```
