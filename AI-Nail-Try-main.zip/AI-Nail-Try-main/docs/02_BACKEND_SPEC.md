# 后端功能说明

## 后端核心模块

### 1. Health 模块

用于检查服务是否正常。

接口：

```text
GET /health
```

### 2. Styles 模块

用于提供美甲款式库。

款式库由两部分组成：

1. `app/data/styles.json`：保存款式元数据，用于接口返回、运营统计和 AI 文案生成。
2. `/static/styles` 款式图片：保存款式参考图，`styles.json` 中的 `image_url` 指向对应图片。

已有美甲图片数据集可以先作为款式参考图导入，不进行模型训练。

接口：

```text
GET /api/styles
GET /api/styles/{style_id}
```

### 3. Try-on 模块

用于上传手部图片并生成 AI 美甲试戴结果。

接口：

```text
POST /api/tryon
```

要求：

1. 支持 `multipart/form-data`
2. 接收 `hand_image` 文件
3. 接收 `style_id`
4. 保存原图到 `uploads`
5. 生成结果图到 `outputs`
6. 返回 `original_image_url` 和 `result_image_url`
7. 记录 `tryon` 行为
8. AI 不可用时返回 mock 结果

真实 AI 试戴必须通过 `image_ai_service.py` 封装，不允许在 router 中直接写具体图像模型调用逻辑。真实调用输入应包括用户手部图片、`style_id`、款式参考图片和款式元数据。当前 MVP 不训练模型、不做精细指甲分割，真实图像生成失败时必须自动降级 mock。

### 4. Events 模块

用于记录用户行为。

接口：

```text
POST /api/events
GET /api/events
```

行为类型：

```text
view_style
select_style
tryon
favorite
save_result
book
```

### 5. Analytics 模块

用于运营端数据看板。

接口：

```text
GET /api/analytics/dashboard
```

返回内容：

1. 今日试戴次数
2. 今日用户数
3. 热门款式 TOP5
4. 热门标签
5. 冷门款式
6. 推荐主推款式

### 6. AI 文本模块

用于文本生成。

文本 LLM 只负责运营日报、推广文案、用户适配建议等文本任务，不负责把美甲款式添加到图片上。

接口：

```text
POST /api/ai/report
POST /api/ai/promotion
POST /api/ai/advice
```

要求：

1. 默认支持 mock 模式。
2. 真实接入必须通过 `llm_service.py` 中的 LLM provider adapter / 多模型适配层。
3. 预留 GPT、Gemini、Qwen、DeepSeek 等模型供应商，不允许 router 或业务逻辑直接依赖任一具体模型。
4. 模型供应商、模型名和 API Key 从环境变量读取。
5. 不允许因为 AI 调用失败导致接口 500。
6. AI 失败、配置缺失、Key 缺失或供应商不可用时返回兜底文案。

### 7. AI 图像模块

用于 AI 美甲试戴图片生成。

AI 图像模块负责图像生成或图像编辑能力，即基于用户手部图片和款式参考图生成试戴结果。普通文本 LLM 不承担该职责。

要求：

1. 默认支持 mock 模式。
2. 真实图像生成通过 `image_ai_service.py` 适配层封装。
3. API Key 从环境变量读取。
4. 真实调用失败时自动降级 mock。
5. 不允许把真实 API Key 写死在代码中。
