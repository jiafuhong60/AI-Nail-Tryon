# Codex 分步任务清单

## 执行规则

1. 每次只完成一个 Step。
2. 每个 Step 完成后，更新状态为 DONE。
3. 每个 Step 完成后，运行测试或启动检查。
4. 不要跳步。
5. 不要实现文档中明确不需要的功能。
6. 遇到不确定的问题，优先选择更简单、更稳定的实现。
7. LLM 真实接入必须通过 `llm_service.py` 的 LLM provider adapter / 多模型适配层完成。
8. 不允许 router 直接调用 GPT、Gemini、Qwen、DeepSeek 等任一具体模型 SDK 或 API。

---

## Step 0：读取文档并输出实现计划

状态：DONE

任务：

```text
请读取 AGENTS.md 和 docs 下所有文档。
不要写代码。
请输出：
1. 你理解的项目目标
2. 后端模块拆分
3. 计划创建的文件结构
4. 每个接口的实现方式
5. 可能的风险和降级方案
```

验收标准：

1. 输出实现计划
2. 不修改代码
3. 不新增无关技术栈

## Step 1：初始化 FastAPI 后端项目

状态：DONE

任务：

```text
请根据文档创建 backend 后端项目骨架。
需要包含：
1. FastAPI app
2. /health 接口
3. CORS 配置
4. requirements.txt
5. Dockerfile
6. docker-compose.yml
7. .env.example
8. README.md 本地启动说明
```

验收标准：

1. `docker compose up` 可以启动
2. `GET /health` 返回 `status ok`
3. FastAPI 文档页面可访问
4. 目录结构符合 `AGENTS.md`

## Step 2：实现款式库接口

状态：DONE

任务：

```text
请实现美甲款式库接口：
1. 创建 app/data/styles.json
2. 至少内置 12 个美甲款式
3. 实现 GET /api/styles
4. 实现 GET /api/styles/{style_id}
5. 使用 Pydantic schema 返回稳定结构
6. 款式图片可来自现有美甲图片数据集
7. `styles.json.image_url` 指向款式图片路径，作为前端展示图和 AI 试戴参考图
```

验收标准：

1. `GET /api/styles` 返回 `items` 数组
2. 每个款式包含 `id`、`name`、`image_url`、`tags`、`scene`、`color`、`reason`、`is_new`
3. 查询不存在的 `style_id` 返回 404
4. 不依赖数据库

## Step 3：实现用户行为记录接口

状态：DONE

任务：

```text
请实现用户行为记录模块：
1. 创建 app/data/events.json
2. 实现 POST /api/events
3. 实现 GET /api/events
4. 支持 event_type 校验
5. 每条事件自动生成 id 和 created_at
```

验收标准：

1. `POST /api/events` 可以写入 JSON 文件
2. `GET /api/events` 可以读取记录
3. 非法 `event_type` 返回 422 或 400
4. 文件不存在时自动创建

## Step 4：实现运营数据统计接口

状态：DONE

任务：

```text
请实现 GET /api/analytics/dashboard。

统计逻辑：
1. 今日试戴次数 = event_type 为 tryon 的数量
2. 今日用户数 = user_id 去重数量
3. 热门款式 = 根据 hot_score 排序
4. 热门标签 = 根据热门款式关联 tags 统计
5. 冷门款式 = view 多但 tryon 少，或 tryon 为 0
6. 推荐主推款式 = hot_score 最高的款式
```

验收标准：

1. 返回结构符合 `docs/03_API_CONTRACT.md`
2. 即使 `events.json` 为空，也返回稳定结构
3. `top_styles` 至多返回 5 个
4. `cold_styles` 至多返回 5 个

## Step 5：实现 AI 试戴接口 mock 版本

状态：DONE

任务：

```text
请实现 POST /api/tryon。
先实现 mock 版本，不接真实 AI。
mock 阶段只复制原图作为结果图，用于保证演示链路，不代表真实试戴能力。

要求：
1. 接收 hand_image 文件
2. 接收 style_id
3. 保存上传图片到 app/uploads
4. 生成 result_image_url
5. 如果没有真实结果图，则复制原图到 outputs 作为 mock 结果
6. 自动记录一条 tryon 事件
7. 返回 ai_reason 和 mock=true
```

验收标准：

1. 可以通过 `multipart/form-data` 上传图片
2. 上传文件被保存
3. `outputs` 中有结果文件
4. 返回 `original_image_url` 和 `result_image_url`
5. 选择不存在的 `style_id` 返回 404
6. AI 不可用时接口不报错

## Step 6：封装真实 AI 图像生成适配层

状态：DONE

任务：

```text
请创建 image_ai_service.py，用 adapter 方式封装图像生成逻辑。
real 模式应预留图像编辑/图像生成模型能力，不通过 `llm_service.py` 实现图片处理。

要求：
1. 支持 IMAGE_AI_MODE=mock
2. 支持 IMAGE_AI_MODE=real 的占位实现
3. 真实 API Key 从环境变量读取
4. 真实调用失败时自动降级 mock
5. 不要把 API Key 写死在代码中
```

验收标准：

1. mock 模式可稳定运行
2. real 模式没有 key 时不崩溃
3. 调用失败会降级
4. `tryon` router 不直接写具体 AI API 逻辑

## Step 7：实现 AI 文本接口 mock 版本

状态：DONE

任务：

```text
请实现：
1. POST /api/ai/report
2. POST /api/ai/promotion
3. POST /api/ai/advice

先使用 mock 文案。
report 需要读取 dashboard 数据。
promotion 和 advice 需要读取 style_id 对应款式。
```

验收标准：

1. 三个接口结构符合 API 契约
2. `style_id` 不存在时返回 404
3. `report` 可以基于当前 dashboard 数据生成内容
4. 返回字段包含 `mock=true`

## Step 8：封装真实 LLM 多模型适配层

状态：DONE

任务：

```text
请创建 llm_service.py，用 LLM provider adapter / 多模型适配层封装文本大模型调用。

要求：
1. 支持 LLM_MODE=mock
2. 支持 LLM_MODE=real 的占位实现
3. 支持通过 LLM_PROVIDER 选择 openai、gemini、qwen、deepseek 等供应商
4. 支持通过 LLM_MODEL 指定模型名
5. API Key 从 OPENAI_API_KEY、GEMINI_API_KEY、QWEN_API_KEY、DEEPSEEK_API_KEY 等环境变量读取
6. 配置缺失、Key 缺失、供应商不可用或调用失败时降级 mock 文案
7. Prompt 模板参考 docs/05_AI_PROMPTS.md
8. 不允许 ai router 直接依赖任一供应商 SDK 或 API
```

验收标准：

1. mock 模式可稳定运行
2. real 模式无 key 时不崩溃
3. `ai` router 不直接写具体模型调用逻辑
4. 所有失败都有兜底文案
5. 文档和 `.env.example` 明确预留 GPT、Gemini、Qwen、DeepSeek 等模型接入

## Step 9：补充测试

状态：DONE

任务：

```text
请添加 pytest 测试。

至少测试：
1. GET /health
2. GET /api/styles
3. GET /api/styles/{style_id}
4. POST /api/events
5. GET /api/analytics/dashboard
6. POST /api/ai/report
```

验收标准：

1. `pytest` 可以运行
2. 核心接口测试通过
3. 不依赖真实 AI API

## Step 10：完善 README 和前端联调说明

状态：DONE

任务：

```text
请完善 backend/README.md。

需要包含：
1. 本地启动方式
2. Docker 启动方式
3. 环境变量说明
4. API 列表
5. 前端联调地址
6. mock 模式说明
7. 常见问题
8. LLM 多模型适配说明，包括 GPT、Gemini、Qwen、DeepSeek 等供应商预留
```

验收标准：

1. 新成员按 README 可以启动项目
2. 前端同学知道如何调用接口
3. 文档中不要出现真实 API Key
4. LLM 供应商配置缺失时系统仍可通过 mock 模式演示

## Alignment：合作规划能力对齐

状态：DONE

任务：

```text
新增 hands、merchants、recommendation、confirmation 模块。
扩展 analytics，新增 platform-dashboard 接口。
扩展 styles 字段兼容 id/name/image_url 和 style_id/style_name/image_path。
所有新增接口支持 mock 数据。
不接真实地图、不做登录、不做支付、不做真实预约。
补充测试和 README。
```

验收标准：

1. 保留现有接口。
2. 新增接口返回稳定 JSON。
3. pytest 通过。
4. README 已补充说明。

## 前后端融合

状态：DONE

任务：
```text
将 frontend 中的 Vite + React 前端与现有 FastAPI 后端合并为完整 MVP 项目。
前端通过统一 API client 调用 /api/styles、/api/tryon、/api/ai/advice、
/api/recommend/merchants、/api/confirmation、/api/analytics/platform-dashboard
和 /api/ai/report。
```

完成说明：
1. 前端新增 API 适配层和 `.env.example`。
2. 用户端流程已接入后端款式、试戴、AI 建议、商家推荐和确认单接口。
3. 运营端已接入平台看板和 AI 日报接口。
4. 后端新增 `pytest.ini`，默认测试收集范围固定为 `tests`。

## Git 初始化与首次发布

状态：DONE

任务：
```text
初始化本地 git 仓库，新增 .gitignore，提交当前 MVP 版本并推送到 GitHub 仓库 nanxin-49/AI-Nail-Try。
```

完成说明：
1. 首次提交范围限定为后端代码、项目文档、README、.env.example 和必要 .gitkeep。
2. .gitignore 已忽略本地环境、Python 缓存、运行时上传/输出文件、测试临时数据、下载素材、根目录样图、Qwen 实验产物和独立测试脚本。
3. try_qwen_models.py 不纳入提交，避免硬编码 API Key 进入公开仓库。
4. 本次任务完成后运行 pytest 或启动检查，并完成 git commit 与 push。

## Extension：双图分割美甲试戴

状态：DONE

已新增 `POST /api/nail-tryon`、Roboflow/mock 指甲分割、双图 mask 构建、款式指甲提取、统一图像编辑入口、命令行 demo、测试和说明文档。
## 运营端 Demo mock 数据接入
状态：DONE

完成说明：
1. `GET /api/analytics/platform-dashboard` 已读取并聚合 `behavior_metrics.json`、`preference_events.json`、`merchants.json`。
2. 接口新增 `overview`、扩展款式热度、商家能力和供需提醒字段，并保留 `mock: true`。
3. 前端运营端类型已同步，运营总览优先使用后端 `overview`。
4. 已补充接口测试，验证聚合、排序、偏好占比、商家字段和高优先级提醒数量。
