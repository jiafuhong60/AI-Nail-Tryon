# 数据结构设计

## 1. NailStyle

```ts
type NailStyle = {
  id: string;
  name: string;
  image_url: string;
  tags: string[];
  scene: string;
  color: string;
  reason: string;
  is_new: boolean;
};
```

说明：

1. `image_url` 指向款式图片资源。
2. 该图片既用于前端款式展示，也作为 AI 试戴的款式参考图。
3. 当前不新增字段，避免影响前端联调和 `docs/03_API_CONTRACT.md` 中的接口契约。

## 2. UserEvent

```ts
type UserEvent = {
  id: string;
  user_id: string;
  style_id: string;
  event_type: "view_style" | "select_style" | "tryon" | "favorite" | "save_result" | "book";
  created_at: string;
};
```

## 3. TryOnResult

```ts
type TryOnResult = {
  task_id: string;
  status: "success" | "failed";
  style_id: string;
  original_image_url: string;
  result_image_url: string;
  ai_reason: string;
  mock: boolean;
};
```

## 4. DashboardData

```ts
type DashboardData = {
  today_tryon_count: number;
  today_user_count: number;
  top_styles: TopStyle[];
  hot_tags: HotTag[];
  cold_styles: ColdStyle[];
  recommendation: Recommendation;
};
```

## 5. 热门分规则

```text
hot_score = tryon_count * 0.5 + favorite_count * 0.3 + book_count * 0.2
```

## 6. 冷门规则

符合以下任一条件，标记为冷门：

1. `view_style` 数量较高，但 `tryon` 数量较低
2. `tryon` 数量为 0
3. `favorite` 数量明显低于平均值
4. `book` 数量为 0
