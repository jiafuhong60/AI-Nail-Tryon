# 双图分割美甲试戴 Pipeline

## 功能目标

新增 `POST /api/nail-tryon` 和命令行 demo，用两张图片完成美甲试戴：

1. `target_hand_image`：最终要保留的用户手部照片。
2. `style_hand_image`：带有美甲款式的参考手部照片。
3. 后端分别分割两张图的指甲区域。
4. 从第二张图提取 `style_nails_only.png`，作为美甲款式参考。
5. 只用第一张图的 `target_nail_mask.png` 限定最终编辑区域。

## 配置

`.env.example` 和 `backend/.env.example` 已预留：

```text
ROBOFLOW_API_KEY=
ROBOFLOW_API_URL=https://serverless.roboflow.com
ROBOFLOW_MODEL_ID=fingernail-segmentation-yy1l7/3
NAIL_TRYON_SEGMENTATION_PROVIDER=roboflow
NAIL_TRYON_DEFAULT_EDIT_PROVIDER=openai
NAIL_TRYON_MASK_DILATE_PX=2
NAIL_TRYON_MASK_FEATHER_PX=1
NAIL_TRYON_DEBUG_OUTPUT=true
```

未配置 `ROBOFLOW_API_KEY` 时，服务会自动使用本地 mock 分割，保证 API 和 demo 链路可运行。配置真实 Key 后使用 Roboflow `fingernail-segmentation-yy1l7/3`。

## API

```http
POST /api/nail-tryon
```

`multipart/form-data` 字段：

```text
target_hand_image: file
style_hand_image: file
provider: string，可选，默认 openai
model_name: string，可选
```

响应：

```json
{
  "success": true,
  "message": "nail try-on generated successfully",
  "data": {
    "session_id": "nail_tryon_xxx",
    "result_image_url": "/uploads/nail_tryon/nail_tryon_xxx/final_tryon_result.png",
    "target_mask_url": "/uploads/nail_tryon/nail_tryon_xxx/target_nail_mask.png",
    "style_mask_url": "/uploads/nail_tryon/nail_tryon_xxx/style_nail_mask.png",
    "style_reference_url": "/uploads/nail_tryon/nail_tryon_xxx/style_nails_only.png",
    "provider": "openai",
    "model_name": null,
    "segmentation_provider": "mock"
  }
}
```

## Demo

```bash
python backend/scripts/run_nail_tryon_demo.py \
  --target ./hand.png \
  --style ./style.png \
  --provider openai \
  --output backend/app/outputs/nail_tryon_demo/final_tryon_result.png
```

输出产物：

```text
target_nail_mask.png
style_nail_mask.png
style_nails_only.png
final_tryon_result.png
```

## 调试说明

- `target_nail_mask.png`：第一张图的可编辑指甲区域。
- `style_nail_mask.png`：第二张图的指甲区域。
- `style_nails_only.png`：从第二张图提取出的透明背景美甲参考。
- `final_tryon_result.png`：最终试戴结果。

当前真实图像编辑 provider 仍复用 `image_ai_service.py` 的统一入口；`IMAGE_AI_MODE=mock` 时会基于 mask 在目标指甲区域生成可见 mock 效果，真实 provider 后续只需替换 `edit_image(...)` 内部实现。
