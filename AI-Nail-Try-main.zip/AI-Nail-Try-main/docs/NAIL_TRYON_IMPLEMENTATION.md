# 美甲试戴功能文件级实施清单：双图指甲分割 + 款式迁移

## 0. 执行前要求

请先阅读当前项目目录结构，不要直接创建一套孤立的新架构。

优先检查以下位置是否已存在：

```bash
find . -maxdepth 4 -type f | sort
```

重点查找：

```text
backend/
app/
src/
services/
providers/
routers/
api/
config/
schemas/
tests/
docs/
```

如果当前项目已有类似模块，请复用现有命名与目录；如果没有，再按下面清单新增。

---

# 1. 配置层修改

## 1.1 `.env.example`

新增：

```env
# Roboflow Fingernail Segmentation
ROBOFLOW_API_KEY=
ROBOFLOW_API_URL=https://serverless.roboflow.com
ROBOFLOW_MODEL_ID=fingernail-segmentation-yy1l7/3

# Nail Try-On
NAIL_TRYON_SEGMENTATION_PROVIDER=roboflow
NAIL_TRYON_DEFAULT_EDIT_PROVIDER=openai
NAIL_TRYON_MASK_DILATE_PX=2
NAIL_TRYON_MASK_FEATHER_PX=1
NAIL_TRYON_DEBUG_OUTPUT=true
```

如果已有 OpenAI / Qwen / Doubao 的 key，不要重复新增，只复用现有配置。

---

## 1.2 `backend/app/core/config.py` 或 `backend/app/config.py`

如果项目已有 settings/config 文件，在其中新增：

```python
ROBOFLOW_API_KEY: str | None
ROBOFLOW_API_URL: str = "https://serverless.roboflow.com"
ROBOFLOW_MODEL_ID: str = "fingernail-segmentation-yy1l7/3"

NAIL_TRYON_SEGMENTATION_PROVIDER: str = "roboflow"
NAIL_TRYON_DEFAULT_EDIT_PROVIDER: str = "openai"
NAIL_TRYON_MASK_DILATE_PX: int = 2
NAIL_TRYON_MASK_FEATHER_PX: int = 1
NAIL_TRYON_DEBUG_OUTPUT: bool = True
```

要求：

* 不要硬编码 API Key
* 所有 provider/model_id 从配置读取
* 保持与当前项目配置方式一致

---

# 2. 依赖文件修改

## 2.1 `requirements.txt` 或 `pyproject.toml`

新增依赖：

```txt
inference-sdk
pillow
opencv-python
numpy
```

如果项目已有图片处理依赖，不重复添加。

---

# 3. 新增 Roboflow 指甲分割模块

## 3.1 新增文件

优先路径：

```text
backend/app/services/segmentation/roboflow_fingernail.py
```

如果当前项目使用 `src/`，则改为：

```text
backend/src/services/segmentation/roboflow_fingernail.py
```

## 3.2 文件职责

该文件只负责调用 Roboflow Fingernail Segmentation。

实现类：

```python
class RoboflowFingernailSegmenter:
    def __init__(self, api_key: str, model_id: str, api_url: str):
        ...

    def infer(self, image_path: str) -> dict:
        ...
```

要求：

* 使用 `InferenceHTTPClient`
* 默认模型：`fingernail-segmentation-yy1l7/3`
* 输入：图片路径
* 输出：Roboflow 原始 JSON
* 失败时抛出清晰异常
* 日志中不要输出 API Key

---

# 4. 新增 mask 构建模块

## 4.1 新增文件

```text
backend/app/services/mask/nail_mask_builder.py
```

如果项目已有 image/mask 工具目录，也可以放到：

```text
backend/app/utils/image_mask.py
```

但优先独立成服务模块。

## 4.2 文件职责

将 Roboflow 返回的指甲 polygon 转换为黑白 PNG mask。

实现函数：

```python
def build_nail_mask(
    image_path: str,
    segmentation_result: dict,
    output_mask_path: str,
    dilate_px: int = 2,
    feather_px: int = 1,
) -> str:
    ...
```

要求：

* 黑色区域：不可编辑
* 白色区域：指甲可编辑区域
* 合并所有 `Fingernail` predictions
* 支持 polygon points
* 支持轻微膨胀
* 支持轻微羽化
* 如果没有检测到指甲，抛出明确异常

---

# 5. 新增第二张图款式提取模块

## 5.1 新增文件

```text
backend/app/services/style/style_nail_extractor.py
```

## 5.2 文件职责

第二张图不是普通款式图，而是“戴有美甲的手部照片”，所以也必须提取指甲区域。

实现类：

```python
class StyleNailExtractor:
    def extract_nails_only(
        self,
        style_image_path: str,
        style_mask_path: str,
        output_path: str,
    ) -> str:
        ...

    def build_style_reference_composite(
        self,
        style_image_path: str,
        segmentation_result: dict,
        output_path: str,
    ) -> str:
        ...
```

要求：

* `style_nails_only.png`：透明背景，只保留第二张图的指甲区域
* 可选生成 `style_reference_composite.png`：把多个指甲 crop 排成拼图
* 不要把第二张图的手、皮肤、背景作为主要风格参考
* 后续图像编辑模型应优先参考提取后的美甲区域

---

# 6. 新增美甲试戴主流程服务

## 6.1 新增文件

```text
backend/app/services/tryon/nail_tryon_service.py
```

## 6.2 文件职责

串联完整 pipeline：

```text
target hand image
style hand image
→ target 指甲分割
→ target mask
→ style 指甲分割
→ style mask
→ style nails only
→ image edit provider
→ final result
```

实现类：

```python
class NailTryOnService:
    def run_tryon(
        self,
        target_hand_image_path: str,
        style_hand_image_path: str,
        output_path: str,
        model_provider: str = "openai",
        model_name: str | None = None,
    ) -> dict:
        ...
```

返回结构：

```python
{
    "success": True,
    "target_hand_image_path": "...",
    "style_hand_image_path": "...",
    "target_mask_path": "...",
    "style_mask_path": "...",
    "style_reference_path": "...",
    "result_image_path": "...",
    "provider": "openai",
    "model_name": "gpt-image-2"
}
```

---

# 7. 图像编辑 Provider 层适配

## 7.1 优先修改已有 provider

请先查找当前项目是否已有类似文件：

```text
backend/app/services/providers/
backend/app/providers/
backend/app/services/image_edit/
backend/app/services/generation/
```

可能存在：

```text
openai_provider.py
qwen_provider.py
doubao_provider.py
model_provider.py
image_edit_provider.py
```

不要重复创建平行 provider。

---

## 7.2 如果已有统一图像编辑接口

请扩展其入参，支持：

```python
edit_image(
    target_image_path: str,
    mask_path: str,
    reference_image_paths: list[str],
    prompt: str,
    output_path: str,
    model_name: str | None = None,
) -> str
```

其中 `reference_image_paths` 至少包含：

```text
style_hand_image
style_nails_only.png
```

优先使用：

```text
style_nails_only.png
```

作为真正的美甲款式参考。

---

## 7.3 如果没有统一接口

新增文件：

```text
backend/app/services/image_edit/base.py
backend/app/services/image_edit/openai_image_edit.py
backend/app/services/image_edit/qwen_image_edit.py
backend/app/services/image_edit/doubao_image_edit.py
backend/app/services/image_edit/factory.py
```

但只有在项目确实没有现成 provider 体系时才新增。

---

# 8. 新增默认提示词文件

## 8.1 新增文件

```text
backend/app/prompts/nail_tryon_prompts.py
```

## 8.2 内容

新增常量：

```python
NAIL_TRYON_PROMPT_CN = """
请基于 Image A（目标手部照片）和 Image B（款式手部照片）完成一次高质量美甲试戴编辑。

其中：
- Image A 是最终需要被编辑的主体图。
- Image B 是带有美甲款式的手部参考图，但请只提取和参考其中“指甲区域”的美甲设计，不要迁移其手型、肤色、背景或其他非指甲内容。
- 如果提供了额外的 style nail reference 图（从 Image B 提取出的指甲区域），请优先参考该图中的美甲细节。

编辑要求：
1. 保留 Image A 的手部姿态、手型、手指结构、肤色、背景、光照和整体构图。
2. 仅修改 Image A 的指甲区域。
3. 从 Image B 的指甲区域提取颜色、纹理、图案、光泽、材质、渐变、法式边、猫眼、闪片、描边、贴纸和整体美甲风格。
4. 不要复制或迁移 Image B 的手部皮肤、手指形状、背景、桌面、首饰、拍摄角度等非美甲信息。
5. 美甲效果必须真实自然，准确贴合 Image A 每个甲面边缘，符合透视、光照和阴影关系。
6. 不要改变手指数量、手型、皮肤纹理、首饰、背景以及其他无关元素。
7. 输出结果应像真实拍摄的试戴图，而不是简单贴图。

最终目标：
将第二张图中的美甲款式，仅指甲设计部分，自然逼真地应用到第一张图的指甲区域，只改变第一张图的指甲，不改变其他内容。
"""
```

---

# 9. API 路由层新增/修改

## 9.1 查找已有路由目录

优先查找：

```text
backend/app/api/
backend/app/api/routes/
backend/app/routers/
backend/src/routes/
```

## 9.2 新增文件

推荐：

```text
backend/app/api/routes/nail_tryon.py
```

如果项目已有统一图像生成路由，也可以追加到现有文件，例如：

```text
backend/app/api/routes/generation.py
```

## 9.3 新增接口

```http
POST /api/nail-tryon
```

请求：

```text
multipart/form-data
- target_hand_image
- style_hand_image
- provider
- model_name
```

返回：

```json
{
  "success": true,
  "message": "nail try-on generated successfully",
  "data": {
    "result_image_url": "...",
    "target_mask_url": "...",
    "style_mask_url": "...",
    "style_reference_url": "...",
    "provider": "openai",
    "model_name": "gpt-image-2"
  }
}
```

---

# 10. 路由注册文件修改

根据当前项目实际入口修改其一：

```text
backend/app/main.py
backend/main.py
backend/src/main.py
```

加入：

```python
app.include_router(nail_tryon_router, prefix="/api", tags=["nail-tryon"])
```

如果项目已有统一 router registry，请在 registry 中注册，不要直接绕过现有结构。

---

# 11. Schema 文件新增

## 11.1 新增文件

```text
backend/app/schemas/nail_tryon.py
```

## 11.2 内容

定义：

```python
class NailTryOnResponse(BaseModel):
    success: bool
    message: str
    data: dict | None = None
```

如果项目已有统一 response schema，请复用，不要重复造。

---

# 12. 文件存储工具修改

## 12.1 查找已有上传/静态文件工具

可能存在：

```text
backend/app/utils/file_utils.py
backend/app/utils/storage.py
backend/app/services/storage.py
```

## 12.2 需要支持

* 保存上传的 `target_hand_image`
* 保存上传的 `style_hand_image`
* 创建 session 目录
* 保存中间产物
* 返回可访问 URL

推荐目录：

```text
backend/uploads/nail_tryon/{session_id}/
  target_hand.jpg
  style_hand.jpg
  target_segmentation_result.json
  target_nail_mask.png
  style_segmentation_result.json
  style_nail_mask.png
  style_nails_only.png
  style_reference_composite.png
  final_tryon_result.png
```

---

# 13. 测试文件新增

## 13.1 单元测试

新增：

```text
backend/tests/test_nail_mask_builder.py
backend/tests/test_style_nail_extractor.py
backend/tests/test_roboflow_fingernail_segmenter.py
```

测试内容：

```text
- polygon 能正确转 mask
- 空 predictions 会报错
- style_nails_only 能生成透明背景图
- mask 膨胀/羽化不报错
```

## 13.2 集成测试

新增：

```text
backend/tests/test_nail_tryon_service.py
```

测试内容：

```text
- mock Roboflow 返回值
- mock image edit provider
- 验证 pipeline 能完整输出 target_mask/style_mask/style_reference/result
```

---

# 14. 示例脚本新增

## 14.1 新增文件

```text
backend/scripts/run_nail_tryon_demo.py
```

## 14.2 功能

支持命令行运行：

```bash
python backend/scripts/run_nail_tryon_demo.py \
  --target ./examples/target_hand.jpg \
  --style ./examples/style_hand.jpg \
  --provider openai \
  --output ./outputs/final_tryon_result.png
```

要求：

* 可以单独跑通完整流程
* 打印所有中间文件路径
* 失败时显示明确原因

---

# 15. 文档新增/修改

## 15.1 新增文档

```text
docs/NAIL_TRYON_PIPELINE.md
```

内容包括：

```text
- 功能目标
- 双图分割流程
- Roboflow 配置方式
- OpenAI / Qwen / Doubao provider 选择方式
- API 调用示例
- 调试产物说明
- 常见错误
```

## 15.2 修改 README

如果项目 README 有功能说明，追加：

```text
Nail Try-On 美甲试戴
- target hand image
- style hand image
- Roboflow fingernail segmentation
- image edit provider
```

---

# 16. 最终文件变更清单

Codex 最终应该新增或修改以下文件：

```text
.env.example
requirements.txt / pyproject.toml

backend/app/core/config.py
backend/app/services/segmentation/roboflow_fingernail.py
backend/app/services/mask/nail_mask_builder.py
backend/app/services/style/style_nail_extractor.py
backend/app/services/tryon/nail_tryon_service.py
backend/app/prompts/nail_tryon_prompts.py

backend/app/api/routes/nail_tryon.py
backend/app/main.py
backend/app/schemas/nail_tryon.py

backend/app/services/image_edit/base.py                # 仅在没有现有 provider 时新增
backend/app/services/image_edit/openai_image_edit.py   # 仅在没有现有 provider 时新增
backend/app/services/image_edit/qwen_image_edit.py     # 仅在没有现有 provider 时新增
backend/app/services/image_edit/doubao_image_edit.py   # 仅在没有现有 provider 时新增
backend/app/services/image_edit/factory.py             # 仅在没有现有 provider 时新增

backend/tests/test_nail_mask_builder.py
backend/tests/test_style_nail_extractor.py
backend/tests/test_nail_tryon_service.py

backend/scripts/run_nail_tryon_demo.py
docs/NAIL_TRYON_PIPELINE.md
README.md
```

---

# 17. 关键实现原则

1. 不要只分割第一张图，第二张图也必须分割。
2. 第二张图只提供“指甲款式”，不要迁移手型、肤色、背景。
3. 第一张图是最终主体，必须尽量保持不变。
4. mask 只允许覆盖第一张图的指甲区域。
5. 图像编辑阶段优先使用 `style_nails_only.png` 作为美甲参考。
6. 保留所有中间产物，方便实测和排查。
7. 不要绕过现有 provider 体系。
8. 不要硬编码 API Key、模型名和输出目录。
9. 所有新增功能必须能通过脚本或 API 跑通。
10. 完成后请说明修改了哪些文件、每个文件的作用、如何运行、如何测试。

---

# 18. 最小验收标准

完成后必须支持：

```bash
python backend/scripts/run_nail_tryon_demo.py \
  --target ./examples/target_hand.jpg \
  --style ./examples/style_hand.jpg \
  --provider openai \
  --output ./outputs/final_tryon_result.png
```

并输出：

```text
target_nail_mask.png
style_nail_mask.png
style_nails_only.png
final_tryon_result.png
```

API 层也必须支持：

```http
POST /api/nail-tryon
```

输入两张图片后返回最终美甲试戴图 URL。
