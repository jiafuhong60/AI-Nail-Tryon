# 09_QWEN_MODEL_INTEGRATION_AND_EVALUATION.md

## 1. 文件目标

本文件用于让 Codex 在现有 FastAPI 后端基础上，接入并实测两个指定模型：

```text
图像编辑模型：qwen-image-edit-plus
文本大模型：qwen3.7-plus
```

本阶段目标不是新增业务模块，而是完成：

```text
1. AI 美甲试戴真实模型接入
2. AI 文案能力真实模型接入
3. 模型失败时 mock 兜底
4. 图像生成效果实测
5. 文本输出稳定性实测
6. 用户端和运营端完整接口冒烟测试
```

不要推翻已有后端，不要重命名已有接口，不要删除 mock 模式。

---

## 2. Codex 开始前必须阅读的文件

执行本文件前，请先阅读：

```text
AGENTS.md
backend/README.md
docs/03_API_CONTRACT.md
docs/05_AI_PROMPTS.md
docs/06_CODEX_TASKS.md
docs/08_ALIGNMENT_TASKS.md
docs/09_QWEN_MODEL_INTEGRATION_AND_EVALUATION.md
```

同时检查现有代码：

```text
backend/app/services/image_ai_service.py
backend/app/services/llm_service.py
backend/app/routers/tryon.py
backend/app/routers/ai.py
backend/app/routers/confirmation.py
backend/app/data/hands.json
backend/app/data/styles.json
backend/app/data/merchants.json
```

---

## 3. 模型选择

### 3.1 图像编辑模型

```text
IMAGE_AI_PROVIDER=qwen
IMAGE_AI_MODEL=qwen-image-edit-plus
```

用途：

```text
手图 + 款式图 + Prompt → 美甲试戴结果图
```

输入：

```text
1. 用户手部图片 hand_image
2. 款式参考图 style.image_url / style.enhanced_url
3. 美甲试戴 Prompt
```

输出：

```text
1. result_image_url
2. provider
3. model
4. latency_ms
5. mock
6. error_message
```

### 3.2 文本大模型

```text
LLM_PROVIDER=qwen
LLM_MODEL=qwen3.7-plus
```

用途：

```text
1. AI 适配建议
2. 运营日报
3. 推广文案
4. 商家匹配理由
5. 服务需求确认单建议
```

---

## 4. 环境变量要求

请更新 `.env.example` 和 README。

```env
# AI image edit
IMAGE_AI_MODE=mock
IMAGE_AI_PROVIDER=qwen
IMAGE_AI_MODEL=qwen-image-edit-plus
IMAGE_AI_TIMEOUT_SECONDS=120
IMAGE_AI_MAX_RETRY=1

# Qwen / Alibaba Cloud Model Studio
DASHSCOPE_API_KEY=your_dashscope_api_key_here
DASHSCOPE_BASE_URL=https://dashscope.aliyuncs.com/compatible-mode/v1
DASHSCOPE_REGION=cn-beijing

# LLM
LLM_MODE=mock
LLM_PROVIDER=qwen
LLM_MODEL=qwen3.7-plus
LLM_TIMEOUT_SECONDS=60
LLM_MAX_RETRY=1

# Fallback
ENABLE_AI_FALLBACK=true
SAVE_AI_RAW_RESPONSE=false
```

说明：

```text
1. 不允许把 API Key 写死在代码中。
2. 如果 IMAGE_AI_MODE=mock，必须完全不调用真实图像模型。
3. 如果 LLM_MODE=mock，必须完全不调用真实文本模型。
4. 如果 real 模式缺少 DASHSCOPE_API_KEY，必须自动降级 mock。
5. 如果模型调用失败，接口不能 500，必须返回 mock=true 或 error_message。
```

---

## 5. Step 19：接入 qwen-image-edit-plus

## 状态

TODO

## 任务

完善 `backend/app/services/image_ai_service.py`。

要求：

```text
1. 保留现有 mock 模式。
2. 新增 qwen provider。
3. 使用 IMAGE_AI_PROVIDER=qwen 选择千问图像编辑模型。
4. 使用 IMAGE_AI_MODEL=qwen-image-edit-plus 作为默认真实图像模型。
5. 支持 hand_image + style_image 两图输入。
6. style_image 优先使用 styles.json 中 enhanced_url，其次 image_url，再其次 original_url。
7. 真实调用失败时降级 mock。
8. 不允许 tryon router 直接调用具体模型 API。
9. 结果图片保存到 backend/app/outputs。
10. 返回结果字段保持 POST /api/tryon 兼容。
```

建议返回字段扩展：

```json
{
  "task_id": "tryon_xxx",
  "status": "success",
  "style_id": "style_001",
  "original_image_url": "/uploads/hand_xxx.png",
  "result_image_url": "/outputs/result_xxx.png",
  "ai_reason": "该款式颜色柔和，适合日常通勤。",
  "mock": false,
  "provider": "qwen",
  "model": "qwen-image-edit-plus",
  "latency_ms": 35200,
  "error_message": null
}
```

## 验收标准

```text
1. IMAGE_AI_MODE=mock 时，POST /api/tryon 稳定可用。
2. IMAGE_AI_MODE=real 且 Key 存在时，会调用 qwen-image-edit-plus。
3. IMAGE_AI_MODE=real 但 Key 缺失时，不崩溃，降级 mock。
4. 模型调用失败时，不崩溃，降级 mock。
5. POST /api/tryon 返回 result_image_url。
6. 原有字段不丢失。
7. pytest 通过。
```

---

## 6. qwen-image-edit-plus 美甲试戴 Prompt

请在 image_ai_service 或 prompt 模板中使用以下 Prompt：

```text
请基于第一张手部照片，将第二张美甲款式参考图自然应用到第一张图中用户的指甲区域。

严格要求：
1. 只修改指甲区域，不改变手部姿态、手型、肤色、背景和光影。
2. 不要改变手指数量，不要生成多余手指，不要改变手部轮廓。
3. 尽量还原款式参考图中的颜色、图案、质感和整体风格。
4. 生成结果要像真实拍摄照片，不要像贴纸、滤镜或拼贴。
5. 如果款式细节较复杂，优先保证颜色、甲面质感和整体风格自然。
6. 不要添加文字、水印、饰品或额外背景元素。

款式信息：
- 款式名称：{{style_name}}
- 款式颜色：{{color}}
- 款式标签：{{tags}}
- 款式元素：{{element}}
- 适合场景：{{scene}}
```

---

## 7. Step 20：接入 qwen3.7-plus 文本模型

## 状态

TODO

## 任务

完善 `backend/app/services/llm_service.py`。

要求：

```text
1. 保留现有 mock 模式。
2. 新增或完善 qwen provider。
3. 使用 LLM_PROVIDER=qwen 选择千问文本模型。
4. 使用 LLM_MODEL=qwen3.7-plus 作为默认真实文本模型。
5. 通过 OpenAI-compatible Chat Completions 风格进行封装，或使用项目已有 provider adapter。
6. router 不允许直接调用具体模型 API。
7. 所有失败必须降级 mock。
8. 所有 AI 文案接口返回稳定 JSON。
```

涉及接口：

```text
POST /api/ai/advice
POST /api/ai/report
POST /api/ai/promotion
POST /api/confirmation
POST /api/recommend/merchants，如当前匹配理由需要 LLM 润色，可选接入
```

## 验收标准

```text
1. LLM_MODE=mock 时，所有 AI 文案接口稳定可用。
2. LLM_MODE=real 且 Key 存在时，调用 qwen3.7-plus。
3. LLM_MODE=real 但 Key 缺失时，自动降级 mock。
4. 模型输出不是合法 JSON 时，能做兜底解析或返回 mock 文案。
5. POST /api/ai/advice、/api/ai/report、/api/ai/promotion 均可用。
6. POST /api/confirmation 不因 LLM 失败而报错。
7. pytest 通过。
```

---

## 8. qwen3.7-plus 文本输出要求

文本模型必须遵守：

```text
1. 输出中文。
2. 不要输出 Markdown 代码块。
3. 尽量输出 JSON 对象。
4. 字段名必须和 API 契约一致。
5. 不要编造官方数据来源。
6. 商家、偏好、行为、运营指标都是 Demo mock 数据。
7. 建议必须具体、可执行，不要空泛。
```

### 8.1 AI 适配建议 Prompt

```text
你是一个专业美甲顾问。

请根据以下款式信息生成用户可理解的适配建议。

款式名称：{{style_name}}
颜色：{{color}}
标签：{{tags}}
元素：{{element}}
场景：{{scene}}
推荐理由：{{reason}}

请只输出 JSON：
{
  "advice": "80字以内的中文建议",
  "mock": false
}

要求：
1. 说明适合什么场景。
2. 说明视觉风格特点。
3. 不要过度夸张。
4. 不要输出 Markdown。
```

### 8.2 AI 运营日报 Prompt

```text
你是美甲平台的智能运营助手。

请根据以下数据生成运营日报：

款式热度榜：{{style_heat_ranking}}
用户偏好趋势：{{preference_trends}}
商家能力画像：{{merchant_capabilities}}
供需提醒：{{supply_demand_alerts}}

请只输出 JSON：
{
  "summary": "今日数据概览",
  "hot_trend": "热门趋势分析",
  "risk": "问题或风险提醒",
  "suggestion": "明日运营建议",
  "mock": false
}

要求：
1. 结论明确。
2. 适合平台运营人员阅读。
3. 建议必须可执行。
4. 不要声称 mock 数据为官方真实数据。
5. 不要输出 Markdown。
```

### 8.3 推广文案 Prompt

```text
你是美甲店的新媒体运营。

请为以下款式生成小红书风格推广文案：

款式名称：{{style_name}}
颜色：{{color}}
标签：{{tags}}
场景：{{scene}}
推荐理由：{{reason}}

请只输出 JSON：
{
  "title": "标题",
  "content": "150字以内正文",
  "hashtags": ["话题1", "话题2", "话题3"],
  "mock": false
}

要求：
1. 适合年轻女性用户。
2. 突出显白、精致、日常适配等卖点。
3. 不要输出 Markdown。
```

### 8.4 服务需求确认单建议 Prompt

```text
你是美甲平台的服务确认助手。

请根据以下信息生成预约前服务确认内容：

用户偏好：{{preferences}}
款式信息：{{style}}
商家信息：{{merchant}}
试戴结果图：{{tryon_result_url}}

请只输出 JSON：
{
  "key_points": ["确认事项1", "确认事项2", "确认事项3"],
  "merchant_suggestion": "给商家的服务建议",
  "mock": false
}

要求：
1. 重点减少沟通成本和预期偏差。
2. 根据用户偏好生成确认重点。
3. 不要输出 Markdown。
```

---

## 9. Step 21：新增图像模型评测脚本

## 状态

TODO

## 任务

新增：

```text
backend/scripts/evaluate_qwen_image_edit.py
```

要求：

```text
1. 从 hands.json 选择 3 张手图。
2. 从 styles.json 选择 5 个款式。
3. 组合成 15 个测试样例。
4. 调用 image_ai_service 或 POST /api/tryon 生成结果。
5. 每个样例记录 hand_id、style_id、provider、model、success、latency_ms、result_image_url、mock、error_message。
6. 输出 backend/evaluation/qwen_image_edit_results.json。
7. 输出 backend/evaluation/qwen_image_edit_report.md。
8. 单个样例失败不能中断全部评测。
```

## 主观评分字段

在结果 JSON 中预留人工评分字段：

```json
{
  "nail_area_accuracy": null,
  "color_similarity": null,
  "pattern_similarity": null,
  "hand_preservation": null,
  "artifact_control": null,
  "overall_score": null,
  "human_comment": ""
}
```

## 评分标准

```text
每项 1-5 分：
1. 指甲区域准确度
2. 颜色还原度
3. 图案/风格还原度
4. 手部姿态、肤色、背景保持
5. 畸形、脏图、多手指等问题控制
```

---

## 10. Step 22：新增文本模型评测脚本

## 状态

TODO

## 任务

新增：

```text
backend/scripts/evaluate_qwen_llm.py
```

要求：

```text
1. 测试 POST /api/ai/advice。
2. 测试 POST /api/ai/report。
3. 测试 POST /api/ai/promotion。
4. 测试 POST /api/confirmation。
5. 检查返回字段是否完整。
6. 检查是否为中文。
7. 检查是否没有 Markdown 代码块。
8. 输出 backend/evaluation/qwen_llm_results.json。
9. 输出 backend/evaluation/qwen_llm_report.md。
```

## 验收标准

```text
1. mock 模式可运行。
2. real 模式可运行。
3. 单个接口失败不影响其他接口评测。
4. 报告中明确指出失败接口、错误字段和原始返回。
```

---

## 11. Step 23：完整接口冒烟测试

## 状态

TODO

## 任务

新增：

```text
backend/scripts/smoke_test_demo_flow.py
```

测试用户端流程：

```text
1. GET /api/hands
2. GET /api/styles
3. POST /api/tryon
4. POST /api/ai/advice
5. POST /api/recommend/merchants
6. POST /api/confirmation
7. POST /api/events
```

测试运营端流程：

```text
1. GET /api/analytics/platform-dashboard
2. POST /api/ai/report
3. POST /api/ai/promotion
```

输出：

```text
backend/evaluation/demo_flow_smoke_test_report.md
backend/evaluation/demo_flow_smoke_test_results.json
```

验收标准：

```text
1. 所有接口返回 2xx。
2. 所有核心字段存在。
3. tryon 返回 result_image_url。
4. recommend 返回至少 1 个商家。
5. confirmation 返回 key_points。
6. platform-dashboard 返回 style_heat_ranking、preference_trends、merchant_capabilities、supply_demand_alerts。
```

---

## 12. Step 24：更新 README 和 API 契约

## 状态

TODO

## 任务

更新：

```text
backend/README.md
docs/03_API_CONTRACT.md
.env.example
```

补充内容：

```text
1. qwen-image-edit-plus 接入说明。
2. qwen3.7-plus 接入说明。
3. 环境变量说明。
4. mock 模式与 real 模式区别。
5. 图像模型评测脚本运行方式。
6. 文本模型评测脚本运行方式。
7. Demo 冒烟测试脚本运行方式。
8. 常见问题：Key 缺失、模型调用失败、图片 URL 不可访问、返回不是 JSON。
```

---

## 13. 推荐执行顺序

```text
Step 19：接入 qwen-image-edit-plus
Step 20：接入 qwen3.7-plus
Step 21：新增图像模型评测脚本
Step 22：新增文本模型评测脚本
Step 23：完整接口冒烟测试
Step 24：更新 README 和 API 契约
```

每完成一步，请输出：

```text
已完成：
- ...

修改文件：
- ...

本地验证：
- ...

下一步建议：
- ...
```

---

## 14. 最终验收标准

完成本文件后，至少满足：

```text
1. IMAGE_AI_MODE=mock 时完整 Demo 可跑。
2. IMAGE_AI_MODE=real 时可调用 qwen-image-edit-plus。
3. LLM_MODE=mock 时完整 Demo 可跑。
4. LLM_MODE=real 时可调用 qwen3.7-plus。
5. 模型失败时自动降级，不影响 Demo 演示。
6. 生成 15 组图像模型测试结果。
7. 生成文本模型评测报告。
8. 生成完整 Demo 冒烟测试报告。
9. README 中写清楚如何配置和运行。
10. 不提交真实 API Key。
```
