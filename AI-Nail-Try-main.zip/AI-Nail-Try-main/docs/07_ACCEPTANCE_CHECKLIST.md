# 后端验收清单

## 基础运行

- [ ] `docker compose up --build` 可以启动
- [ ] `GET /health` 返回正常
- [ ] Swagger 文档可访问
- [ ] CORS 已允许前端访问

## 款式库

- [ ] `GET /api/styles` 返回至少 12 个款式
- [ ] `GET /api/styles/{style_id}` 可查询单个款式
- [ ] 不存在的款式返回 404

## 用户行为

- [ ] `POST /api/events` 可以写入行为
- [ ] `GET /api/events` 可以查看行为
- [ ] `event_type` 有校验

## AI 试戴

- [ ] `POST /api/tryon` 支持图片上传
- [ ] 上传图片会保存到 `uploads`
- [ ] 结果图片会保存到 `outputs`
- [ ] 返回 `original_image_url`
- [ ] 返回 `result_image_url`
- [ ] AI 不可用时 mock 模式可用

## 运营数据

- [ ] `GET /api/analytics/dashboard` 返回今日试戴次数
- [ ] 返回热门款式 TOP
- [ ] 返回热门标签
- [ ] 返回冷门款式
- [ ] 返回推荐主推款式

## AI 文本

- [ ] `POST /api/ai/report` 可生成运营日报
- [ ] `POST /api/ai/promotion` 可生成推广文案
- [ ] `POST /api/ai/advice` 可生成用户适配建议
- [ ] LLM 不可用时 mock 模式可用
- [ ] GPT、Gemini、Qwen、DeepSeek 等供应商通过多模型适配层预留
- [ ] `ai` router 不直接绑定任一具体 LLM 供应商
- [ ] LLM 配置缺失、Key 缺失或调用失败时自动降级 mock

## 文档与密钥

- [ ] README 完整
- [ ] `.env.example` 完整
- [ ] API 契约和实际返回一致
- [ ] 没有提交真实 API Key
- [ ] `.env.example` 只包含空值或 mock 默认值
- [ ] `docs/05_AI_PROMPTS.md` 只维护业务 Prompt，不写死供应商请求格式
